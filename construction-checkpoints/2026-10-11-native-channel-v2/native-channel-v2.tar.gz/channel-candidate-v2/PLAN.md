# Bounded execution plan and rounds

Existing work item/owners remain original-record-attachment.json. Stage Test; status candidate awaiting independent review. Handbook v1.0 sections1–5,7,8.3–8.4,9,12 and payment applicability apply.

1. Read ACT rules/skill/memory/current sole handoff, terminal v1 review and exact original Maker source graph. Pin original461 baseline files and review SHA. COMPLETE.
2. Compare snapshot, producer-importing-Channel and optional generic producer authority designs. Correct sameSource-module premise explicitly. Implement only candidate Channel/Maker extension/optional adapter. COMPLETE; no actual source changes.
3. Build independent production roots; retain original Maker49, original Channel36 plus2 stale regressions and15 real Maker adapter tests. COMPLETE.
4. Ten precise foreign refusals and snapshot-downgrade mutation control. COMPLETE; mutation15 has6 expected negative-control failures (undesired successes), including exact R1/R2.
5. Retain exact source/ABI/bytecode/dependency pins, before-images, public allowlist, report, recovery and handoff. Root schedules a fresh independent read-only review before any activation.

Corrective rounds: round1 resolved contained dependency/default implicit MoveStdlib and first compiler diagnostics; round2 fixed test-context sender setup (VM TxContext native state) and completed actual producer15; round3 corrected foreign-private-call primary expectation EC04001 and completed mutation semantics. No economic rule or budget/permission policy changed. Storage exhaustion was an environment failure, not counted as a semantic result. Only this candidate's disposable compiler install outputs were reclaimed; all successful module bytes were deterministically reconstructed and matched every prior SHA/length before retained ZIPs were created. Exact deleted paths/receipts: scratch-recovery.json and recovery/artifact-bytes/*.json.

Exit: terminal implementation candidate with reproducible evidence and independent review pending. Full157/30/1528/15 and original four journeys remain active.
