# Channel producer closure candidate v2 report

Implementation and scoped verification complete; independent acceptance and source activation remain pending. Both reviewed stale-source blockers are corrected in a genuine producer-backed candidate without adopting Channel economics or narrowing required current-source checks. Full original157/30/1528/15 remains ACTIVE.

## Change and authority

The optional adapter is independently maintained and imports Maker+Channel. Maker imports neither Channel nor Standard/Soul/Core/Application/Animacraft. It adds a generic optional managed authority dynamic-field interface, required because original Product had no authority generation and public Control transfers cannot be observed universally. Original Product/Control layouts and all old Maker source bodies remain exact; only optional generic API/state is appended. Original freely transferable Control is untouched outside explicit enrollment. Principal voluntarily seals exact real Control in key-only Authority, and consent commits exact Source/Coin/adapter-role defining types and Control type/ID. Maker stores exact authority instance/type, Control ID, principal, roles and monotonic generation. No ID or old creator address alone grants authority.

V1 same-module(Source,A/R) was structurally incompatible with a separate adapter. V2 checks selected A/R belong to the same independently owned nonprimitive module and differ; actual private witness constructors and genuine live producer calls establish reviewed implementation semantics. Public SourceState/Completion constructors/types are removed. No production API returns private A/R, Authorization, Work, Session or completion. Work is declared public because Move2024 requires public struct declarations, but fields are private, abilities empty and construction/finalizer private. Foreign forgery/extraction/finalizer attempts refuse precisely.

`manufacture` encloses real source authority check, funded Channel authorization, immediate producer reread, canonical factory request/begin, live authority before select, actual Model materialization and supply accounting, live authority before factory finish, origin completion consumption, producer reread at Channel terminal closure and exact beneficiary delivery. Test-only split wrappers permit adversarial rotation between boundaries; none are in the production function allowlist/bytecode ABI. Source/version checks compare actual Product/Control and registered producer state; no transportable proof is treated as live authority.

## Verified evidence

| Gate | Actual result |
| --- | --- |
| Independent production roots | Channel, candidate Maker and optional adapter build PASS; exact module bytes/SHA retained in recovery/artifact-bytes |
| Original Maker regressions |49/49 PASS; all original bodies/assertions unchanged |
| Original Channel regressions + review blockers |36 original +2 exact R1/R2 regressions =38/38 PASS |
| Actual producer adapter |15/15 PASS, genuine factory/Walrus/publication/Config/Coin/Model/origin execution |
| Foreign boundary |10/10 exact intended first diagnostics PASS, source/log SHA and first positions retained |
| Snapshot mutation negative control |15 executed;9 PASS and6 intentionally FAIL because bad stale paths succeed without abort, including real R1/R2. Confirms tests distinguish live guarded behavior from v1-style snapshot downgrade |

Real producer cases include paid delivery to committed beneficiary; actual Source and Free Item, authored supply, wallet completion, primary factory revenue and Config fee; stale accept/authorize/fulfillment/final-close with exact Maker11; controlled A→B→A; release/free transfer/return/reenroll generation; replay on a later Scenario transaction; canonical remainder underpayment; producer/service paused exits; unauthorized handover; and exact late Channel revoke/pause abort after real payment/supply mutations.

Paid data verifies1118=Channel111+Maker900+Config107 with1000 producer base,100 producer fee,7 fixed original fee. Producer quote is metadata; actual Coin is consumed by Channel and actual remainder by original factory. V1 fixed price/FLOOR/BPS/epoch choices stay unactivated recommendations, not a new fee policy. Original terms/royalty/secondary/ceil-vs-floor/caps/rights and exits remain unchanged.

Sui CLI SHA `1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3`; framework2a0becb2fcc6989e492981104af67f62f2c9511a. Offline contained graph, explicit fresh HOME/[] empty.keystore/testnet loopback:9/active_address null, existing deny-network invocation and default budgets. No key initialization, wallet/key read, network/chain transaction, signature, DB/actual repository/other-chat or runtime-permission mutation. One CLI-internal denied Git dependency fetch is explicitly disclosed in ATTEMPTS.md/result.json; no direct Git/repository operation occurred. Initial implicit dependency fetch was denied and recorded as environment failure; adding a contained root MoveStdlib override made reproduction offline.

Disk exhaustion was separately observed while producing mutation scratch. It was not counted as a passing control. Only candidate-created compiler install paths were reclaimed. Successful original module bytes were reproduced from unchanged inputs and every previous SHA/length matched, then exact module bytes were retained in verified ZIPs before final scratch deletion. Deletion receipts and logs are in scratch-recovery.json/recovery/artifact-bytes; source/frozen inputs/before-images/journals/earlier candidates/user files remain.

## Boundaries and recovery

Generic Goods manufacture proves a real production Maker consumer, not original Soul/Native Character admission or the four original direct/selected issuance/trade journeys. Market integration remains missing. Standard-dependent Admission remains HOLD and no current Standard source or historical graph was overwritten. Actual package publishing/upgrades/type origins/old callable rejection, real PTB rollback readback, SDK/UI, qualified independent review/external audit and full157/30 acceptance remain open.

Unit late-abort cases prove the intended VM abort after actual mutations. They do not independently read post-abort retained-chain wallet balances. No activation PASS is inferred from disclaimers or test totals. Necessary Maker API changes are candidate-only, for Root/owning-maintainer inspection. Source/control permission domain is explicit managed enrollment; public transfers outside it retain original semantics with no universal revocation claim. There is no new permanent Vault, economic policy or roadmap commitment.

Recovery is to leave candidate unactivated. maker-source-delta.json and recovery/before-source contain exact two-path candidate delta and before-images; original catalog is an exact prefix of candidate source. Source/dependency/ABI/bytecode pins and public allowlist identify this review input. Root schedules a fresh bounded read-only verifier; fresh implementation and review should not modify frozen v1 or reawaken its completed reviewer. Current continuation remains owned by Root.
