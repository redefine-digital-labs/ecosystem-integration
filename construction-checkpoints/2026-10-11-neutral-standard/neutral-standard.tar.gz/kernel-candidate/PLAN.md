1. Copy exact current Standard and only pinned local Sui/Std dependency source into a new isolated tree.
2. Add neutral private metadata hooks/getters and separate focused history tests; preserve original tests.
3. Run fresh keyless/offline production and original+focused tests with default budgets; retain diagnostics and exact artifacts.
4. Freeze exact inputs/evidence and provide an immutable proposal to the construction executor. Actual kernel remains unchanged.
