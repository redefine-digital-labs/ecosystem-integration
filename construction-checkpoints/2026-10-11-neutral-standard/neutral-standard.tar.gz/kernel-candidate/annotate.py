from pathlib import Path
O=Path(__file__).resolve().parent
p=O/'closure/move/soulidity_standard/sources/soul.move'
s=p.read_text()
anchor='public struct NestingVersionKey has copy, drop, store {}'
assert s.count(anchor)==1 and 'ModuleAnnotationKey' not in s
s=s.replace(anchor,anchor+'''
/// Optional immutable source-owned bytes. The kernel assigns no business
/// meaning: consumers must agree on an annotation format and its obligations.
public struct ModuleAnnotationKey has copy, drop, store { namespace: TypeName, name: vector<u8> }
''')
anchor='fun removed(s: &mut Soul, d: &Descriptor) {'
s=s.replace(anchor,'''fun annotation_key(d: &Descriptor): ModuleAnnotationKey {
    ModuleAnnotationKey { namespace: d.namespace, name: d.name }
}
fun annotated(s: &mut Soul, d: &Descriptor, bytes: Option<vector<u8>>) {
    if (bytes.is_some()) {
        let data = bytes.destroy_some();
        assert!(data.length() <= MAX_CHILD_BYTES, ECapacity);
        df::add(&mut s.id, annotation_key(d), data)
    }
}
'''+anchor)
anchor='    let key = version_key(d);\n    if (df::exists<ModuleVersionKey>(&s.id, key)) {'
assert s.count(anchor)==1
s=s.replace(anchor,'''    let a = annotation_key(d);
    if (df::exists<ModuleAnnotationKey>(&s.id, a)) {
        let _: vector<u8> = df::remove(&mut s.id, a);
    }
'''+anchor)
anchor='public fun installed_revision(v: &ModuleVersion): u64 { v.installed }'
s=s.replace(anchor,'''/// Absent and empty annotations are distinct. Bytes are immutable for this
/// installation and cannot be changed through ordinary module edits.
public fun module_annotation(s: &Soul, d: &Descriptor): Option<vector<u8>> {
    ready(s); assert!(s.modules.any!(|current| *current == *d), EIdentity);
    let key = annotation_key(d);
    if (df::exists<ModuleAnnotationKey>(&s.id, key)) option::some(*df::borrow(&s.id, key))
    else option::none()
}
'''+anchor)
old='''public fun install<W: drop, T: key + store>(
    s: &mut Soul, witness: W, name: vector<u8>, value: T,
    schema: u16, removable: bool, semantic_hash: vector<u8>, expected: u64,
) {
    ready(s);'''
assert s.count(old)==1
new='''public fun install<W: drop, T: key + store>(
    s: &mut Soul, witness: W, name: vector<u8>, value: T,
    schema: u16, removable: bool, semantic_hash: vector<u8>, expected: u64,
) {
    install_declared(s, witness, name, value, schema, removable, semantic_hash, expected, option::none())
}

/// Source-owned generic declaration, atomically bound to the actual module
/// installation. It adds no module and uses the same single CAS revision step.
public fun install_annotated<W: drop, T: key + store>(
    s: &mut Soul, witness: W, name: vector<u8>, value: T,
    schema: u16, removable: bool, semantic_hash: vector<u8>, expected: u64,
    annotation: vector<u8>,
) {
    install_declared(s, witness, name, value, schema, removable, semantic_hash, expected, option::some(annotation))
}

fun install_declared<W: drop, T: key + store>(
    s: &mut Soul, witness: W, name: vector<u8>, value: T,
    schema: u16, removable: bool, semantic_hash: vector<u8>, expected: u64,
    annotation: Option<vector<u8>>,
) {
    ready(s);'''
s=s.replace(old,new)
s=s.replace('    installed(s, &d); topology_changed(s, &d);','    installed(s, &d); annotated(s, &d, annotation); topology_changed(s, &d);')
p.write_text(s)
with (O/'SPEC.md').open('a') as f:
 f.write('''\n## Classification information-loss correction\n\nThe constructor executor also reproduced original passive pose handover failure because blanket permanence classification is wrong. Add optional immutable, opaque source-owned annotation bytes at the generic install operation, bound by the existing namespace/type witness and current real module. No business meaning or mutable setter is defined in Standard. Generic install remains unannotated; annotated install uses the same one revision step and no extra module. Removal deletes the annotation, while same-ID reinstall has a new installed version. Consumer handover declarations must be independently specified and interpreted in lifecycle; this primitive alone does not complete them. Existing Manifest/Descriptor formats do not serialize annotation/history bytes; read-only getters plus exact current version must be included in any consumer commitment. Old callable kernels can bypass new metadata hooks, so effective-version/lineage gates remain unproven. No claim of upgrade compatibility from unchanged root layout.\n''')
