from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,sys
O=Path(__file__).resolve().parent;ACT=O.parents[4];CLI=ACT/'output/contract-rebuild/local-ptb-2026-10-08/tooling/sui'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(root):return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
assert sha(CLI)=='1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3'
label,mode,package=sys.argv[1:4];assert mode in ['build','test']
run=O/'runs'/label;run.mkdir(parents=True,exist_ok=False);inputs=run/'inputs';variant=O/'variants'/label
origin=variant/'closure' if variant.exists() else O/'closure'
manifest=variant/'closure-manifest.json' if variant.exists() else O/'closure-manifest.json'
shutil.copytree(origin,inputs)
assert inventory(inputs)==json.loads(manifest.read_text())
home=run/'private-home';home.mkdir();config=home/'.sui/sui_config';config.mkdir(parents=True)
key=config/'empty.keystore';key.write_text('[]\n');key.chmod(0o600)
(config/'client.yaml').write_text('keystore:\n  File: '+str(key)+'\nenvs:\n  - alias: testnet\n    rpc: http://127.0.0.1:9\n    ws: null\n    basic_auth: null\nactive_env: testnet\nactive_address: null\n')
cache=run/'move-home';cache.mkdir();tmp=run/'tmp';tmp.mkdir()
command=[str(CLI),'move',mode,'--path',str(inputs/'move'/package),'--install-dir',str(run/'build')]
policy='(version 1)(allow default)(deny network*)(deny file-write*)(allow file-write* (subpath '+json.dumps(str(run))+') (literal "/dev/null"))'
(run/'sandbox.sb').write_text(policy+'\n');env=dict(os.environ,HOME=str(home),MOVE_HOME=str(cache),TMPDIR=str(tmp)+'/',TMP=str(tmp),TEMP=str(tmp))
before=inventory(inputs);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (run/'private-raw.log').open('w') as f:r=subprocess.run(['/usr/bin/sandbox-exec','-f',str(run/'sandbox.sb')]+command,cwd=run,env=env,stdout=f,stderr=subprocess.STDOUT)
raw=re.sub(r'\x1b\[[0-9;]*m','',(run/'private-raw.log').read_text());after=inventory(inputs)
identities={i:s for s,i in re.findall(r'\[\s*(PASS|FAIL|TIMEOUT)\s*\]\s+(\S+)',raw)}
# Deliberate allowlist: public compiler diagnostics/test outcomes only, never raw initialization.
lines=[x for x in raw.splitlines() if re.match(r'^\s*(\[\s*(PASS|FAIL|TIMEOUT)\s*\]|Test result:|error\[|error:|BUILDING |INCLUDING DEPENDENCY )',x)]
(run/'public.log').write_text('\n'.join(lines)+'\n')
data={'command':command,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'tool_sha256':sha(CLI),'network_denied':True,'keyless_runtime':{'empty_keystore':json.loads(key.read_text())==[],'active_address':None,'testnet_alias':True,'rpc':'http://127.0.0.1:9','recovery_phrase_generated':bool(re.search(r'recovery phrase|Secret Recovery Phrase|mnemonic',raw,re.I))},'default_budget':True,'budget_overrides':[],'closure_manifest_sha256':sha(manifest),'input_before':before,'input_after':after,'source_drift':{p:[before.get(p),after.get(p)] for p in before.keys()|after.keys() if before.get(p)!=after.get(p)},'summaries':re.findall(r'Test result[^\n]*',raw),'identities':identities,'first_errors':re.findall(r'error\[[^\n]*|error:[^\n]*',raw)[:8],'compiled_artifacts':inventory(run/'build'),'public_log_sha256':sha(run/'public.log'),'source_activation':False,'standard_input_scope':'unactivated neutral history extension; actual0574 kernel untouched','published':False,'chain_transactions':0,'full_goal_complete':False}
assert not data['keyless_runtime']['recovery_phrase_generated'] and data['keyless_runtime']['empty_keystore']
(run/'result.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');print(json.dumps({k:data[k] for k in ['exit_code','summaries','first_errors','source_drift','keyless_runtime']}));sys.exit(r.returncode)
