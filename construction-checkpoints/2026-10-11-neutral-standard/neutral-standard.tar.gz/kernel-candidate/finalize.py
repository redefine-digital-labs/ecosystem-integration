from pathlib import Path
import hashlib,json,re,stat,zipfile
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
actual=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-standard/move/soulidity_standard')
before=json.loads((O/'actual-before.json').read_text())
assert all(sha(actual/name)==digest for name,digest in before.items())
source=O/'closure/move/soulidity_standard/sources/soul.move'
old=(O/'before/soul.move').read_text();new=source.read_text()
layouts={}
for name in ('Soul','Origin','Descriptor','ModuleKey','NestedSoulWitness','Edit','Changed','Manifest'):
 pattern=r'public struct '+name+r'\b[^\{]*\{[^\}]*\}'
 a=re.search(pattern,old).group();b=re.search(pattern,new).group()
 assert a==b,name
 layouts[name]=hashlib.sha256(a.encode()).hexdigest()
for name,digest in before.items():
 if name.startswith('tests/'):assert sha(O/'closure/move/soulidity_standard'/name)==digest
rows={}
results={}
for run in sorted((O/'runs').iterdir()):
 if not (run/'result.json').exists():continue
 result=json.loads((run/'result.json').read_text())
 assert not result['source_drift'] and result['network_denied'] and result['default_budget']
 assert result['keyless_runtime']['empty_keystore'] and not result['keyless_runtime']['recovery_phrase_generated']
 results[run.name]={'exit_code':result['exit_code'],'summaries':result['summaries'],
                   'failed':[name for name,state in result['identities'].items() if state!='PASS']}
 files=sorted((run/'build').rglob('*.mv'))
 if files:
  archive=run/'retained-modules.zip'
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
   for p in files:z.write(p,str(p.relative_to(run/'build')))
  inventory={str(p.relative_to(run/'build')):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
  with zipfile.ZipFile(archive) as z:
   restored={name:{'sha256':hashlib.sha256(z.read(name)).hexdigest(),'bytes':len(z.read(name))} for name in z.namelist()}
  assert restored==inventory
  (run/'retained-modules.json').write_text(json.dumps({'archive':archive.name,'archive_sha256':sha(archive),'modules':inventory},indent=2)+'\n')
  results[run.name]['retained_modules']=len(files)
assert results['history-third']['summaries']==['Test result: OK. Total tests: 38; passed: 38; failed: 0']
assert results['history-production']['exit_code']==0
assert set(results['mutation-update-history']['failed'])=={
 'soulidity_standard::history_tests::reverted_bytes_still_advance_module_history',
 'soulidity_standard::history_tests::missing_historical_metadata_is_explicit_and_not_fabricated'}
assert results['mutation-topology-history']['failed']==['soulidity_standard::history_tests::same_child_id_reinsertion_has_new_install_and_topology_versions']
data={'status':'EXECUTOR_SCOPED_PASS_INDEPENDENT_REVIEW_PENDING','candidate_source_sha256':sha(source),
 'actual_source_sha256':before['sources/soul.move'],'actual_source_and_original_tests_unchanged':True,
 'existing_struct_layouts_exact':layouts,'existing_tests':26,'focused_tests':12,'results':results,
 'scope':'Neutral immutable source annotation and module/topology versions; consumer handover integration remains open',
 'actual_activation':False,'old_callable_safety_proven':False,'published_compatibility_proven':False,
 'full157_30_1528_15_complete':False,'existing_record_refs':['DOF-001','P01','P09']}
(O/'result.json').write_text(json.dumps(data,indent=2)+'\n')
(O/'REPORT.md').write_text('''# Neutral Standard history and declarations: unactivated proposal

The production root builds; all26 byte-exact original tests and12 new history/declaration controls pass at default budget with network denied and explicitly empty key configuration. Removing the update hook makes two focused controls fail; removing native-topology hooks makes same-ID unnest/reinsert control fail. Earlier ENOSPC/pre-VM syntax attempts remain separate historical evidence.

Eight existing public struct declarations, including Soul, Descriptor and Manifest, are exact. No new DOF/module, mutable UID escape, custody rule, authority setter or business dependency is added. Immutable opaque declarations are producer namespace/type-witness bound at one atomic installation revision; Standard assigns no handover meaning. Applications must agree on and enforce an explicit declaration format. Existing descriptors/manifests do not serialize the new metadata; consumers must read and bind annotation/version getters rather than claiming a whole-state commitment.

Unknown historical metadata is explicit None; a legacy edit can expose installed_revision0, never a fabricated installation proof. Business consumers requiring known history must reject unknown state. Old callable functions may bypass new hooks. Actual source activation, old-callable/effective authority, upgrade/type/object migration, independent security review and full original handover/Market/UI acceptance remain open. Actual0574 kernel and original tests are unchanged.

Recovery: candidate is not activated; leave actual source untouched. Reproduce only in a fresh isolated tree with remapped contained dependencies and the pinned Sui runtime. Public retained module ZIPs have exact member SHA/lengths. Do not extract over existing source or reuse historical runtime-home/key material. Full157/30/1528/15 scope and original Owners remain active.
''')
(O/'HANDOFF.md').write_text('''# Neutral kernel candidate handoff

Read SPEC.md, REPORT.md, result.json and frozen-manifest.json. Source is closure/move/soulidity_standard/sources/soul.move; original0574 source before/soul.move. Production build and original26+focused12 PASS; update/topology downgrade controls reproduce two/one failures. Unactivated and independent review pending. Consume only as a distinct after-candidate, preserving current-kernel construction baseline/counterexamples. Existing struct layouts and all original tests exact; opaque annotations are immutable provider bytes, not Standard business rules. Full lifecycle classification/acknowledgment/history acceptance must be implemented and tested in owning business modules. No current Owner/kernel/Git/chain/CURRENT changes; full goal remains active.
''')
paths=[]
for base in ('closure','variants','before'):
 paths.extend(p for p in (O/base).rglob('*') if p.is_file())
paths.extend(p for p in O.iterdir() if p.is_file() and p.name not in ('frozen-manifest.json','frozen-manifest.sha256'))
for run in sorted((O/'runs').iterdir()):
 for name in ('result.json','public.log','sandbox.sb','retained-modules.zip','retained-modules.json'):
  p=run/name
  if p.exists():paths.append(p)
for p in sorted(paths):
 assert not p.is_symlink() and p.stat().st_nlink==1
 rows[str(p.relative_to(O))]={'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
(O/'frozen-manifest.json').write_text(json.dumps({'files':rows,'scope':data['scope'],'actual_activation':False},indent=2)+'\n')
(O/'frozen-manifest.sha256').write_text(sha(O/'frozen-manifest.json')+'\n')
print(json.dumps({'status':data['status'],'files':len(rows),'source_sha256':sha(source),'freeze_sha256':sha(O/'frozen-manifest.json')}))
