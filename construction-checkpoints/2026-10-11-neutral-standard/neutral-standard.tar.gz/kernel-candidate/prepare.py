from pathlib import Path
import hashlib, json, shutil

O = Path(__file__).resolve().parent
BASE = O.parent
ACTUAL = Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-standard/move/soulidity_standard')
SOURCE = BASE / 'current-standard-construction-adapter-candidate-v1/closure'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(ACTUAL/'sources/soul.move') == '0574d86b7d40dd42e22774b3bd68d9f5e7705fda2cf805cfe58a31d3e777c2c7'
closure = O/'closure'
standard = closure/'move/soulidity_standard'
standard.mkdir(parents=True, exist_ok=False)
for directory in ('sources', 'tests'):
    shutil.copytree(ACTUAL/directory, standard/directory)
for filename in ('Move.toml','Move.lock'):
    source = SOURCE/'move/soulidity_standard'/filename
    if source.exists(): shutil.copyfile(source, standard/filename)
dep = 'https___github_com_MystenLabs_sui_git_2a0becb2fcc6989e492981104af67f62f2c9511a/crates/sui-framework/packages'
for directory in ('sui-framework','move-stdlib'):
    src = SOURCE/'fixed-deps'/dep/directory
    dest = closure/'fixed-deps'/dep/directory
    dest.mkdir(parents=True)
    for p in src.rglob('*'):
        if p.is_file() and 'build' not in p.relative_to(src).parts and (p.suffix == '.move' or p.name in ('Move.toml','Move.lock')):
            target = dest/p.relative_to(src)
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(p,target)
(O/'before').mkdir()
shutil.copyfile(ACTUAL/'sources/soul.move', O/'before/soul.move')
original = {str(p.relative_to(ACTUAL)):sha(p) for d in ('sources','tests') for p in (ACTUAL/d).rglob('*') if p.is_file()}
(O/'actual-before.json').write_text(json.dumps(original,indent=2)+'\n')
p=standard/'sources/soul.move'
s=p.read_text()
s=s.replace('use sui::dynamic_object_field as dof;', 'use sui::dynamic_object_field as dof;\nuse sui::dynamic_field as df;')
s=s.replace('public struct NestedSoulWitness has drop {}', '''public struct NestedSoulWitness has drop {}

/// Neutral history lives outside existing root and descriptor layouts. These
/// private keys cannot be forged by a producer or another application.
public struct ModuleVersionKey has copy, drop, store { namespace: TypeName, name: vector<u8> }
public struct ModuleVersion has copy, drop, store { installed: u64, updated: u64 }
public struct NestingVersionKey has copy, drop, store {}
''')
s=s.replace('    let s = Soul {', '    let mut s = Soul {')
s=s.replace('    };\n    s\n}', '    };\n    df::add(&mut s.id, NestingVersionKey {}, 0u64);\n    s\n}',1)
anchor='fun changed(s: &mut Soul, operation: u8, d: &Descriptor) {'
history='''fun version_key(d: &Descriptor): ModuleVersionKey {
    ModuleVersionKey { namespace: d.namespace, name: d.name }
}
fun installed(s: &mut Soul, d: &Descriptor) {
    let next = s.revision + 1;
    df::add(&mut s.id, version_key(d), ModuleVersion { installed: next, updated: next })
}
fun updated(s: &mut Soul, d: &Descriptor) {
    let key = version_key(d);
    let next = s.revision + 1;
    if (df::exists<ModuleVersionKey>(&s.id, key)) {
        let v: &mut ModuleVersion = df::borrow_mut(&mut s.id, key);
        v.updated = next
    } else {
        // An older root lacks a proved installed version. Keep zero explicit;
        // consumers requiring exact installation history must reject it.
        df::add(&mut s.id, key, ModuleVersion { installed: 0, updated: next })
    }
}
fun removed(s: &mut Soul, d: &Descriptor) {
    let key = version_key(d);
    if (df::exists<ModuleVersionKey>(&s.id, key)) {
        let _: ModuleVersion = df::remove(&mut s.id, key);
    }
}
fun topology_changed(s: &mut Soul, d: &Descriptor) {
    if (d.namespace == type_name::with_defining_ids<NestedSoulWitness>()) {
        let key = NestingVersionKey {};
        let next = s.revision + 1;
        if (df::exists<NestingVersionKey>(&s.id, key)) {
            *df::borrow_mut<NestingVersionKey, u64>(&mut s.id, key) = next
        } else { df::add(&mut s.id, key, next) }
    }
}

/// None means history was not recorded by this kernel. A getter never invents
/// a successful zero version for an unknown legacy module or nesting tree.
public fun module_version(s: &Soul, d: &Descriptor): Option<ModuleVersion> {
    ready(s);
    assert!(s.modules.any!(|current| *current == *d), EIdentity);
    let key = version_key(d);
    if (df::exists<ModuleVersionKey>(&s.id, key)) option::some(*df::borrow(&s.id, key))
    else option::none()
}
public fun installed_revision(v: &ModuleVersion): u64 { v.installed }
public fun updated_revision(v: &ModuleVersion): u64 { v.updated }
public fun nesting_revision(s: &Soul): Option<u64> {
    ready(s); let key = NestingVersionKey {};
    if (df::exists<NestingVersionKey>(&s.id, key)) option::some(*df::borrow(&s.id, key))
    else option::none()
}

'''
assert s.count(anchor)==1
s=s.replace(anchor,history+anchor)
s=s.replace('    s.modules.push_back(d); changed(s, 0, &d)', '    installed(s, &d); topology_changed(s, &d);\n    s.modules.push_back(d); changed(s, 0, &d)')
s=s.replace('    s.modules.remove(i); changed(s, 1, &d); value', '    removed(s, &d); topology_changed(s, &d);\n    s.modules.remove(i); changed(s, 1, &d); value')
s=s.replace('    *s.modules.borrow_mut(i) = d; s.editing = false; changed(s, 2, &d)', '    updated(s, &d);\n    *s.modules.borrow_mut(i) = d; s.editing = false; changed(s, 2, &d)')
s+='''
#[test_only]
public fun remove_version_for_testing<W>(s: &mut Soul, name: vector<u8>) {
    let d = descriptor<W>(s, name).destroy_some(); removed(s, &d)
}
#[test_only]
public fun remove_nesting_version_for_testing(s: &mut Soul) {
    let _: u64 = df::remove(&mut s.id, NestingVersionKey {});
}
'''
p.write_text(s)
assert sha(ACTUAL/'sources/soul.move')==original['sources/soul.move']
print(json.dumps({'status':'PREPARED_UNACTIVATED','candidate_sha256':sha(p),'original_sha256':original['sources/soul.move']}))
