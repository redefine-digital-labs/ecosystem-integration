# Retained attempts

1. history-first: preparatory mirror copy stopped with actual ENOSPC before compiler launch. Its partial input directory is retained; no build/test claim. Other concurrent executors then preserved and verified their own generated compiler artifacts and reclaimed only their own newly generated scratch.
2. history-second: fresh exact source, no network, empty keystore, default budget. See immutable run result.

2 result: compiler rejected new fixture missing semicolons/Scenario result discard and new helper semicolons before any VM execution. Corrected syntax only; retained run source/log/result.
3. history-third: fresh source after syntax corrections; original tests unchanged.
