# Bounded plan

1. Pin original owning material, P3 and broader plan controls; copy Community into a fresh disposable repository.
2. Select only Sui2a/MoveStdlib immutable input closure; preserve original source/test identities and register independent offline verification.
3. Run actual production build and original tests before advancing candidate verification metadata; match P3 module bytes.
4. Freeze scoped Community-only operations and independent payload/recovery pins. Rehearse apply, restore, interruption/resume and drift refusals in disposable copies.
5. Leave English terminal report/result/frozen manifest and scoped handoff for Root and independent acceptance. Do not perform source activation, signing, publication, commits or pushes.
