# Soulidity Phase Handoff: Community independent source candidate v1

## Snapshot

- Created: 2026-10-11T11:39:32+03:00
- Phase: Community independent source candidate v1
- Status: in-progress
- Goal: Independent Community source/CI with preserved original semantics and exact disposable CAS recovery
- Worktree: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity`
- Branch: `codex/soul-dof-v1-contracts`
- Commit: `0cfb60a29b2b378dd9fbf31970b324b2ef2e301e`
- Working tree: dirty (38 status entries)
- Handoff: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity/output/ecosystem-construction/repository-split-2026-10-10/maker-manufacturing-extraction/community-independent-source-candidate-v1/HANDOFF.md` (helper dry-run output saved in authorized scope)

## Outcome

Scoped local source/CI candidate PASS: offline production build, original106 tests, four P3 module byte equality,24 recovery/refusal checks; no actual activation.

## Scope and non-goals

### In scope

- community-independent-source-candidate-v1 output only

### Intentionally not done

- No actual sources/SDK/Standard/Git/network/keys/chain modifications or full157/30 closure

## Durable decisions

- Community project DAG is empty; Standard HOLD does not block Community source proof

## Changed paths and assets

### Changed paths

- output/ecosystem-construction/repository-split-2026-10-10/maker-manufacturing-extraction/community-independent-source-candidate-v1

### Image and binary assets

- No image or binary assets recorded.

### Relevant commits

- No additional commit references recorded.

## Verification

- Original4 production and5 test bytes preserved; original106 VM tests and pinned production build PASS at default budgets
- All4 artifacts byte-equal P3 first unsigned artifact; source/type-origin/chain claims separate
- 195-operation CAS recovery and intended negative controls:24 checks PASS

## Risks and recovery

### Risks or blockers

- Independent review,release/remoteCI,sourceactivation,typeorigin/authority,originalUI/full157/30 remain pending

### Recovery or rollback points

- Scoped independent before-state bytes,apply/restore and interruption/resume verified in disposable targets; no chainrollback claim

### Working-tree evidence

```text
 T packages/soulidity-sdk/src/chain-event-discovery.ts
 T packages/soulidity-sdk/src/chain-object-discovery.ts
 T packages/soulidity-sdk/src/coin-selection.ts
 T packages/soulidity-sdk/src/format.ts
 T packages/soulidity-sdk/src/object-inputs.ts
 T packages/soulidity-sdk/src/profile-read-step.ts
 T packages/soulidity-sdk/src/request.ts
 T packages/soulidity-sdk/src/sui-grpc-compat.ts
 T packages/soulidity-sdk/src/sui-network.ts
 T packages/soulidity-sdk/src/tx-result.ts
?? docs/CONTRACT_REBUILD_COVERAGE.json
?? docs/CONTRACT_REBUILD_SPEC_CN.md
?? docs/CONTRACT_SECURITY_REVIEW_CN.md
?? docs/SOUL_ARCHITECTURE_REVIEW_CN.md
?? docs/SOUL_STANDARD_KERNEL_CN.md
?? docs/codex/
?? docs/ecosystem-construction/
?? move/soulidity_application/
?? move/soulidity_community
?? move/soulidity_content/
?? move/soulidity_custody/
?? move/soulidity_foundation/
?? move/soulidity_model
?? move/soulidity_native/
?? move/soulidity_standard
?? move/soulidity_v1/
?? move/soulidity_visual
?? move/standard_examples/
?? output/
?? scripts/codex/
?? scripts/ecosystem/
?? scripts/inspect_contract_dependencies.py
?? scripts/profile_move_function_trace.py
?? scripts/verify_contract_ability_batches.py
?? scripts/verify_contract_ability_probes.py
?? scripts/verify_contract_publication_budget.py
?? scripts/verify_soul_standard_external.py
?? scripts/verify_soul_standard_local.mjs
```

## Exact next action

Root arranges fresh independent review of the frozen Community-only candidate; source activation remains distinct from isolated chain publication.

