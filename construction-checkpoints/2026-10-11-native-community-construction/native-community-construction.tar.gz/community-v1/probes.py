#!/usr/bin/env python3
"""Rehearse frozen Community CAS and intended refusal controls in disposable targets."""
import hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
def main():
 plan=json.loads((OUT/'operations.json').read_text());ph=sha(OUT/'operations.json');ch=sha(OUT/'community_cutover.py');results=[]
 parent=OUT/'rehearsals';parent.mkdir(exist_ok=True);targets=Path(tempfile.mkdtemp(prefix='probe-run-',dir=parent))
 def run(label,command,target,expected=0,extra=None,contains=None):
  argv=[sys.executable,str(OUT/'community_cutover.py'),command,'--target',str(target),'--expected-plan-sha',ph,'--expected-control-sha',ch]+(extra or [])
  result=subprocess.run(argv,capture_output=True,text=True,timeout=60);row={'label':label,'argv':argv,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'expected':expected};results.append(row)
  assert result.returncode==expected and (contains is None or contains in result.stderr),(label,row)
 def snapshot(target):
  return {o['relative']:sha(target/o['relative']) if (target/o['relative']).is_file() else None for o in plan['operations']}
 good=targets/'apply-restore';run('seed', 'seed',good);before=snapshot(good);run('apply','apply',good);run('restore','restore',good);assert snapshot(good)==before
 backups=good/'.cas/backups'
 for p in backups.iterdir():
  assert p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
  assert p.stat().st_ino not in {q.stat().st_ino for q in (OUT/'payload').rglob('*') if q.is_file()}
 interrupted=targets/'interrupted';run('seed-interrupted','seed',interrupted);run('intentional-interruption','apply',interrupted,1,['--fault-after','20'], 'intentional interrupted apply');run('resume','resume',interrupted);run('restore-resumed','restore',interrupted)
 drift=targets/'baseline-drift';run('seed-drift','seed',drift);p=drift/'module.json';p.write_text(p.read_text()+' ');before=snapshot(drift);run('baseline-CAS-refusal','apply',drift,1,contains='CAS baseline mismatch');assert before==snapshot(drift)
 protected=targets/'protected-drift';run('seed-protected','seed',protected);p=protected/'move/soulidity_community/tests/profile_tests.move';p.write_text(p.read_text()+'\n');before=snapshot(protected);run('protected-test-refusal','apply',protected,1,contains='protected source/test drift');assert before==snapshot(protected)
 unknown=targets/'unknown-restore';run('seed-unknown','seed',unknown);run('apply-unknown','apply',unknown);p=unknown/'module.json';p.write_text(p.read_text()+' ');before=snapshot(unknown);run('unknown-restore-refusal','restore',unknown,1,contains='unknown CAS outcome');assert before==snapshot(unknown)
 backup=targets/'backup-drift';run('seed-backup','seed',backup);run('apply-backup','apply',backup);p=next((backup/'.cas/backups').iterdir());p.chmod(0o644);p.write_bytes(b'bad backup');before=snapshot(backup);run('backup-drift-refusal','restore',backup,1,contains='independent backup drift');assert before==snapshot(backup)
 run('actual-apply-refusal','apply',Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-community'),1,contains='actual source activation disabled')
 run('control-pin-refusal','apply',targets/'wrong-pin',1,['--expected-control-sha','0'*64], 'exact plan/control pins required')
 alias=targets/'ancestor-alias';os.symlink(str(Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem')),alias);run('ancestor-symlink-refusal','apply',alias/'soul-community',1,contains='target ancestor symlink refused')
 # The immutable payload must not be edited even by rehearsal execution.
 payload=OUT/plan['operations'][0]['payload'];original=payload.read_bytes();mode=payload.stat().st_mode&0o777
 try:
  payload.chmod(0o644);payload.write_bytes(b'drift');run('payload-drift-refusal','apply',targets/'payload-drift',1,contains='payload state drift')
 finally:payload.write_bytes(original);payload.chmod(mode)
 source=OUT/'repository'
 def direct(label,argv,contains):
  r=subprocess.run(argv,cwd=source,capture_output=True,text=True,timeout=60,env={**os.environ,'SUI_BINARY':'missing-runtime'});results.append({'label':label,'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==1 and contains in (r.stderr+r.stdout)
 direct('missing-runtime-product-refusal',[sys.executable,'scripts/ci.py','--product'],'pinned Sui')
 direct('static-dependency-write-refusal',[sys.executable,'scripts/ci.py','--changed-path',plan['operations'][0]['relative']],'read-only')
 direct('release-readiness-refusal',[sys.executable,'scripts/ci.py','--release-ready'],'release readiness is pending')
 save(OUT/'probe-results.json',{'result':'PASS','checks':results,'file_operation_restore_equal':True,'independent_backups':True,'actual_activation':False,'actual_apply_enabled':False})
 print(json.dumps({'result':'PASS','checks':len(results),'operations':len(plan['operations'])}))
if __name__=='__main__':main()
