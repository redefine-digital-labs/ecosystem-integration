#!/usr/bin/env python3
"""Community-only CAS rehearsal. Actual source mutation is unconditionally disabled."""
import argparse, hashlib, json, os, stat, tempfile
from pathlib import Path, PurePosixPath
OUT=Path(__file__).resolve().parent
ACTUAL=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-community')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise ValueError(message)
def state(p):
 if p.is_symlink():raise ValueError('symlink refused: '+str(p))
 if not p.exists():return {'kind':'absent'}
 require(p.is_file(),'unsupported file kind')
 return {'kind':'file','sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def safe(root,rel):
 path=PurePosixPath(rel)
 require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0] not in ['.git','.cas'],'unsafe operation path')
 p=root/rel
 for q in [root]+list(p.parents)+[p]:
  if q==root or q.is_relative_to(root):require(not q.is_symlink(),'symlink traversal refused')
 require(p.resolve().is_relative_to(root.resolve()),'path escape refused')
 return p
def atomic(p,data,mode=0o644):
 p.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  os.chmod(tmp,mode);os.replace(tmp,p)
  fd=os.open(p.parent,os.O_RDONLY);os.fsync(fd);os.close(fd)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def save(p,data):atomic(p,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode())
def put(p,s,blob=None):
 if s['kind']=='absent':
  if p.exists():p.unlink()
  return
 require(blob is not None and sha(blob)==s['sha256'],'payload/backup digest mismatch')
 atomic(p,blob.read_bytes(),s['mode'])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['check','seed','apply','restore','resume']);ap.add_argument('--target',type=Path,default=ACTUAL);ap.add_argument('--expected-plan-sha');ap.add_argument('--expected-control-sha');ap.add_argument('--fault-after',type=int);a=ap.parse_args()
 planpath=OUT/'operations.json';plan=json.loads(planpath.read_text());ph=sha(planpath);target=a.target.absolute()
 if a.command!='check':
  require(a.expected_plan_sha==ph and a.expected_control_sha==sha(Path(__file__)),'exact plan/control pins required')
  require(target!=ACTUAL and target.is_relative_to(OUT/'rehearsals'),'actual source activation disabled; disposable target only')
 for ancestor in [target]+list(target.parents):
  if ancestor==OUT.parent:break
  if ancestor==OUT or ancestor.is_relative_to(OUT):require(not ancestor.is_symlink(),'target ancestor symlink refused')
 for op in plan['operations']:
  safe(target,op['relative']);payload=safe(OUT,op['payload']);require(state(payload)==op['after'],'payload state drift')
 for rel,s in plan['protected'].items():safe(target,rel)
 if a.command=='check':
  drift=[op['relative'] for op in plan['operations'] if state(target/op['relative'])!=op['before']]
  drift += [rel for rel,s in plan['protected'].items() if state(target/rel)!=s]
  print(json.dumps({'plan_sha256':ph,'operations':len(plan['operations']),'baseline_drift':drift,'actual_apply_enabled':False}));return
 if a.command=='seed':
  require(not target.exists(),'fresh rehearsal target required')
  for op in plan['operations']:require(state(ACTUAL/op['relative'])==op['before'],'actual baseline drift')
  for rel,s in plan['protected'].items():require(state(ACTUAL/rel)==s,'protected original drift')
  target.mkdir(parents=True)
  for op in plan['operations']:put(target/op['relative'],op['before'],ACTUAL/op['relative'] if op['before']['kind']=='file' else None)
  for rel,s in plan['protected'].items():put(target/rel,s,ACTUAL/rel)
  print(json.dumps({'status':'SEEDED','operations':len(plan['operations'])}));return
 require(target.is_dir(),'target missing')
 control=target/'.cas';require(not control.is_symlink(),'journal directory symlink refused');control.mkdir(exist_ok=True)
 lock=control/'exclusive.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
 try:
  journal=control/'journal.json';backup=control/'backups'
  for rel,s in plan['protected'].items():require(state(target/rel)==s,'protected source/test drift')
  if a.command=='apply':
   require(not journal.exists(),'journal exists: use resume/restore')
   for op in plan['operations']:require(state(target/op['relative'])==op['before'],'CAS baseline mismatch: '+op['relative'])
   backup.mkdir(exist_ok=False)
   for op in plan['operations']:
    if op['before']['kind']=='file':
     digest=op['before']['sha256'];p=backup/digest
     if not p.exists():atomic(p,(target/op['relative']).read_bytes(),0o444)
   j={'plan_sha256':ph,'control_sha256':sha(Path(__file__)),'target':str(target),'status':'applying','completed':[]};save(journal,j)
  else:
   j=json.loads(journal.read_text());require(j['plan_sha256']==ph and j['control_sha256']==sha(Path(__file__)) and j['target']==str(target),'journal identity mismatch')
  for op in plan['operations']:
   require(state(target/op['relative']) in [op['before'],op['after']],'unknown CAS outcome: '+op['relative'])
   if op['before']['kind']=='file':require(sha(backup/op['before']['sha256'])==op['before']['sha256'],'independent backup drift')
  if a.command=='restore':
   for op in reversed(plan['operations']):put(target/op['relative'],op['before'],backup/op['before']['sha256'] if op['before']['kind']=='file' else None)
   for op in plan['operations']:require(state(target/op['relative'])==op['before'],'restore readback failure')
   j['status']='restored';save(journal,j);print(json.dumps({'status':'RESTORED','operations':len(plan['operations'])}));return
  require(j['status']=='applying','terminal journal cannot reapply')
  for i,op in enumerate(plan['operations']):
   if state(target/op['relative'])!=op['after']:put(target/op['relative'],op['after'],OUT/op['payload'])
   require(state(target/op['relative'])==op['after'],'apply readback failure')
   if i not in j['completed']:j['completed'].append(i)
   save(journal,j)
   if a.fault_after is not None and len(j['completed'])>=a.fault_after:raise RuntimeError('intentional interrupted apply')
  j['status']='applied';save(journal,j);print(json.dumps({'status':'APPLIED_DISPOSABLE_ONLY','operations':len(plan['operations'])}))
 finally:lock.unlink()
if __name__=='__main__':
 try:main()
 except (ValueError,OSError,KeyError,RuntimeError) as e:
  print(str(e),file=__import__('sys').stderr);raise SystemExit(1)
