# Community independent source candidate

Original DOF-001/P01/P09 remain in progress under their existing Owners. This bounded candidate supports the full157/30 goal without closing it. Handbook v1.0 sections1–5,7,8.3–8.4,9,12 apply; EVM/DeFi financial models are not involved.

Acceptance: preserve four production modules, five original test files, assertions and default budgets exactly; consume only immutable pinned Sui2a/MoveStdlib snapshots; use no project/sibling/ACT absolute build dependencies; run an actual production build and all106 original tests from a fresh network-denied copy with pinned Sui v1.80.1; compare all four modules to the exact P3 first Community artifact; register an executable independent product command; retain exact scoped file operations, independent backup bytes, CAS recovery and frozen evidence.

Write scope is this fresh directory only. Owning repositories/aliases/SDK/Standard, actual activation, whole-plan guard, network/Git/keys and chain state stay read-only. Type-origin compatibility, effective on-chain authority, independent review, release, actual CI execution and original UI/product acceptance remain separate checks. Standard boundary HOLD has no Community compile dependency and does not block this source proof.
