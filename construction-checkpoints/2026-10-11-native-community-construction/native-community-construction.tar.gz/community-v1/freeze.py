#!/usr/bin/env python3
"""Freeze reviewable source/payload/terminal evidence; no actual source mutations."""
import hashlib,json,stat
from pathlib import Path
OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not (OUT/'frozen-manifest.json').exists(),'fresh manifest required'
 files=set()
 for folder in ['repository','payload']:
  for p in (OUT/folder).rglob('*'):
   rel=p.relative_to(OUT/folder)
   if p.is_file() and not any(x in rel.parts for x in ['output','build','.git','__pycache__']):files.add(p)
 for p in OUT.iterdir():
  if p.is_file() and p.name not in ['operations-preparation-incomplete001.json','intermediate-registered-ci-result.json']:files.add(p)
 evidence=json.loads((OUT/'final-semantic-evidence.json').read_text())
 for item in [evidence['sui_version'],evidence['network_denial_probe'],evidence['build'],evidence['test']]:files.add(OUT/'repository'/item['log'])
 run=OUT/'repository'/Path(evidence['build']['log']).parent
 files.update((run/'production/build/SoulidityCommunity/bytecode_modules').glob('*.mv'))
 probes=json.loads((OUT/'probe-results.json').read_text())
 target=Path(next(x for x in probes['checks'] if x['label']=='restore')['argv'][4])
 # argv[4] is --target; derive the value explicitly to avoid positional assumptions.
 argv=next(x for x in probes['checks'] if x['label']=='restore')['argv'];target=Path(argv[argv.index('--target')+1])
 files.update(p for p in (target/'.cas').rglob('*') if p.is_file())
 plan=json.loads((OUT/'operations.json').read_text());assert len(plan['operations'])==195
 manifest={'schema':'community-independent-frozen-v1','scope':'Community-only disposable source/CI/recovery candidate; actual activation disabled','result':'SCOPED_PASS','independent_review':'pending','file_count':len(files),'operations_sha256':sha(OUT/'operations.json'),'control_sha256':sha(OUT/'community_cutover.py'),'source_pins_sha256':sha(OUT/'repository/source-candidate-pins.json'),'runtime_pin_sha256':sha(OUT/'runtime-pin.json'),'files':{str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for p in sorted(files)},'excluded':'generated source/build caches, extra rehearsal copies, initial incomplete preparation/probe iteration copies; selected final logs/artifacts/independent restored backups retained','actual_sources_activated':False}
 p=OUT/'frozen-manifest.json';p.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
 (OUT/'frozen-manifest.sha256').write_text(sha(p)+'  frozen-manifest.json\n')
 for rel,data in manifest['files'].items():assert sha(OUT/rel)==data['sha256']
 print(json.dumps({'result':'FROZEN_SCOPED_PASS','files':len(files),'manifest_sha256':sha(p),'operations_sha256':manifest['operations_sha256'],'control_sha256':manifest['control_sha256']}))
if __name__=='__main__':main()
