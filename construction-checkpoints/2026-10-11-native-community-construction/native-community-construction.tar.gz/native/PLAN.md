# Execution plan

1. Pin coherent-source accepted ae467539/1681 inputs, coupling declarations and immutable baseline; preserve original750 test files and all assertions/budgets.
2. Compare direct package move (cycle), public constructors (authority leakage), and consumed typed attestation (selected). Extract Catalog/native installer/revision and Native creation adapter into independent native binder; leave fixed canonical Core consumed wrappers.
3. Build unchanged original and candidate Native/Core closures; exercise unchanged native/content/output/admission/rights/supply/rollback tests with pinned default budget. Keep known exact-origin assertions unchanged and identify their migration result.
4. Add source/foreign compiler and VM negatives for constructor, operator namespace, address, typed Build/revision, Config/CAS and current-role protections. Record primary diagnostics and source SHA individually.
5. Pin final sources, artifact deltas, one-way DAG, rollback mapping and English report. No actual source or chain activation.
