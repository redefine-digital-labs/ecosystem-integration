# Native/Core authority seam extraction result

**Executable unpublished seam candidate PASS; independent review and whole cutover remain pending.** Actual Catalog, NativeInstaller/revision authority and the Native creation bridge now live in the independently buildable `SoulidityNativeBinder` candidate. Core consumes that source through a fixed typed wrapper; its private ApplicationOperator constructor remains package private. The candidate closes the Binder→Core declaration cycle for this seam. It does not complete the remaining Core operator/Maker/extension extraction or final Standard boundary.

Baseline source manifest is accepted ae467539/1681. This directory contains independent baseline, candidate, migration-test and foreign-probe copies; no installed repository, alias, SDK, Standard source, signing output, Git state, wallet, network, DB/Genesis or chain authority was changed. Original DOF-001/P01/P09, all Owners and original157/30 obligations remain. The requested MIXED_CORE14 probe's generated lexical evidence remains in its original extraction-probes location; every new seam edit is here.

## Actual code and authority contract

`candidate/move/soulidity_native_binder/sources/native_binding.move` owns the real Catalog constructor, commitment, generation/history, disabled Config/Admin/CAS installation, current role checks, Publisher/UpgradeCap registration, private NativeInstaller1/NativeRevision2 construction and consumed admission operation. `native_creation.move` owns the concrete sealed Account→Native creation bridge. Its actual Native Registry/Birth and custody implementation are unchanged dependencies.

The Core `native_binding` wrapper always supplies the same concrete `issuer::Build`, `application_operator::ApplicationOperator` and `ApplicationRevision1`. It has no generic user-facing choice and returns no private marker. The independently owned binder takes authentic private operator/revision values, checks their exact module/datatype and original-package relationship to the real typed Build, and stores the operator lineage plus defining revision in Catalog. Schema3/domainv3 commitments include these fields and both original/defining versions of the complete original15-role vector. Protected admission compares that exact stored tuple, current actual Native Config role/revision, Catalog ID/generation/commitment and payment coin before constructing the private installer and consuming the operator.

Maker admission adds `bind_external`; the original same-package `bind` remains byte-exact source. The new method requires the actual configured Native witness/revision and the genuine private application operator associated with the Build type. Native binder supplies those private source values after its exact current Catalog check. Neither copied TypeName metadata nor a foreign same-name NativeInstaller can manufacture a Binding. Existing genuine paid-action, exact source/target/actor/receipt, Character initialization, supply/rights and linear completion obligations are unchanged.

Three alternatives were compared: a direct fixed-type move preserves the Core Build dependency and creates a dependency cycle; making the shared operator constructor public exports application authority; the selected typed consumed contract removes the cycle while preserving the fixed canonical consumer. A new independent operator library would require moving every concrete operator-consuming business path in the same increment and would exceed this bounded seam.

**Explicit review delta:** a different authentic application package can request installation through its own private operator/revision and typed Build only with the actual disabled Config/Admin/CAS. The alternative is stored in the commitment; the original canonical consumer rejects it. This broader explicit installation choice is a candidate consumed-contract delta requiring review, not approved production behavior. Root's instruction explicitly permits evaluating it. It is not an arbitrary raw role tuple, a public witness constructor or a fallback issuer.

## Verification

All builds/tests use pinned `sui 1.80.1-671ba71e69c7`, SHA `1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3`; sandbox denies network and writes outside disposable run/cache outputs. Original default budgets remain: no gas override, assertion removal, changed loop, supply/payment/rights guard relaxation or original source-helper change.

| Gate | Result | Exact evidence |
| --- | --- | --- |
| Unchanged baseline Core production |196 modules PASS|runs/002-baseline-core-build|
| Independent candidate Binder production |PASS|runs/001-candidate-binder-build|
| Candidate Core production |198 modules PASS|runs/003-candidate-core-build|
| Independent Binder at actual unpublished root address0 |PASS|runs/028-independent-binder-zero-root|
| Unchanged baseline originals |1071/1071 PASS|runs/004-baseline-original-core|
| Unchanged full candidate originals |Compiler FAIL EC03003 old Catalog import|runs/005-candidate-original-core|
| Unchanged scoped originals, one exact fixture omitted in disposable run only |1059/1060 PASS; old Native-ID assertion FAIL|runs/007-candidate-original-scoped|
| Complete original identity set with only necessary type migration |1071/1071 PASS|runs/017-full-migration-suite|
| Foreign runtime controls |10/10 PASS at exact expected abort module/code|runs/027-foreign-runtime-final; runtime-foreign-results.json|
| Independent foreign compiler negatives |8/8 intended first EC04001 PASS|runs/019–026; compiler-negative-results.json|
| Actual installed/runtime source guards |197 current plus181 historical-current exact guards PASS|source-guards.json|
| Original750 test files |All exact in baseline/candidate|original-test-preservation.json|

The migration copy changes exactly three original test files and three source-line blocks: installation_tests line5 imports Catalog from its new defining module; native_binding_tests line19 points NativeInstaller/Revision type-ID assertions at their actual new source; content_boundary_tests line71 supplies the actual new NativeRevision type to its unrelated-Cap negative. All assertions, budgets, loops, business expectations and1071 test identities remain. Exact before/after lines, SHA and unified diffs are in migration-test-adaptation.json; every1071 baseline/candidate identity is separately mapped in original-identity-mapping.json. No expected diagnostic-module remap was needed. The unadapted failures are retained as actual namespace migration evidence, not relabeled successes.

Foreign compiler cases independently reject private NativeInstaller/NativeRevision packing, ApplicationOperator packing, the private operator/revision constructors, linear Binding packing, raw Catalog UID and sealed Account Cap access. Each binds exact source SHA, primary source location/code and raw log. Runtime cases prove canonical tuple acceptance; wrong-address same-named app rejection; mismatched Build/operator addresses; wrong Build/revision declarations; primitive/wrong-module operators; forged Native namespace at admission; obsolete Core Native marker rejection; and rejection of an explicitly installed alternative by the fixed canonical consumer.

Initial foreign harness runs are retained as failures: implicit framework fetch was denied, a dependency alias had the wrong package name, and a fixture returned test_scenario effects without its terminal semicolon. They are not authority negatives. Pinned local manifests and terminal cleanup repaired only the new probes. The evidence helper was made compatible with local Python without tomllib. No business implementation iteration or budget change followed the passing builds/tests.

## Exact artifact and migration boundary

Baseline196 versus candidate198 production modules:193 original module bytes remain exact. Only Core native_binding/native_creation and MakerAdmission maker_issuance change; two independently owned Binder modules are added. Standard, issuer, ApplicationOperator, Foundation/payment/revenue, custody, Native Registry/Birth, Maker supply/rights and every other unchanged production module retain exact bytes. Source delta is seven files including two manifests and two new Native owner sources. production-artifact-delta.json and source-delta.json contain exact hashes.

The declared production DAG is acyclic (26 roots including fixed external packages), with Core→NativeBinder and no NativeBinder→Core edge. This is source/compiler dependency evidence, not actual chain linkage, final19-root publication, a new approved retained release unit, or final Standard ownership. Integrated VM/compiler candidate uses distinct offline Binder address0xb17de solely to distinguish the moved type namespace. It is not a chain/package ID. Separate zero-root production proof builds Binder as a real unpublished root; future Core linkage must consume its actual publication metadata rather than this placeholder.

Catalog/Commitment nominal type and layout, native role lineage/Publisher/Cap package and creation-bridge module all change. Existing chain Catalogs and installed old Native roles do not migrate by changing a directory. `NativeRevision1` in the new owner is a source-name mapping, not a claim of old Core type-origin compatibility. Old Core Native marker declarations are inert source references with no constructed/exported value; their configured-role rejection is tested. They remain for historical mapping in this partial candidate and must be reviewed/retired appropriately in actual cutover. ApplicationOperator/Revision and Core Build remain their old defining namespace in this bounded increment.

## Rollback and remaining work

Rollback is to ignore this unactivated directory and use the independent immutable baseline/accepted ae467539 sources. No actual restore mutation is necessary. baseline-manifest.json pins all1681 originals; candidate-manifest.json pins all1684 construction inputs; zero-root and migration/probe variants are pinned separately. Never write the new Catalog layout into old chain objects or treat a local source rollback as a chain-state rollback.

Source/VM acceptance is complete only for this seam. Required next checks remain: fresh independent read-only seam review; acceptance or restriction of alternate application owner registration; further Maker/extension operator consumers and Core source extraction; final Standard owner/nesting calibration; fresh actual package/type-origin/linkage/Publisher/Cap/source-revision/old-callable verification; actual repository/config/CI/alias cutover; actual money/custody/new-object rollback readback; and complete original157/30 user journeys/releases. VM late-failure/payment/supply/custody tests preserve their intended diagnostics and compiled sources, but do not prove real transaction rollback receipts. No signature, publication, deployed governance, multisig/timelock/immutability, external audit, full cutover or full-product completion is claimed.
