# Application target read candidate v1

Existing full modularization goal remains active. This bounded attachment repairs the evidenced default-budget regression from ad70 frozen source only. Original Pack supply-negative11 fails while positive10 passes; the stack reaches character state_target through fresh issuance and repeated dynamic object borrows. Exact failing iteration is unknown.

Sole production delta: private character.state_target reuses its immutable Composition reference, borrows RootVisual once after EPart and policy.use_follows_soul, and reuses scene/adapters during this immutable call. Preserve business validations and order, adapter last-match and copies, rights/source/layout/mapping, issuer and supply cap ordering. No authorization caches, tokens, API/schema/layout/type/dependency/budget/test changes. Compare three equivalents and choose minimal.

Acceptance: fixed CLI SHA256 1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3;1667 ordinary independent inputs/fixed dependencies copied exactly except sole delta; unchanged original60 Core test files and original buy_choice/positive10/negative11; default Pack57; on improvement production build, whole Core1062, Maker49; exact identity comparison; installed181 zero drift; raw logs/process receipts and frozen source/ABI/layout/test ledger. Max2 substantive rounds, stop on no progress. Any original failure forbids install-ready/full-goal-complete claims.

Write scope: this candidate directory only. No actual source/CURRENT/Git/remotes/keys/deploy changes. Sandbox denies network/global .move, frozen/upstream/actual writes; private MOVE_HOME; unique install directories. Parent independently reviews.
