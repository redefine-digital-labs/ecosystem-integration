# Plan

1. Verify ad70 manifest and181 installed guard; copy1667 independent ordinary inputs.
2. Compare3 equivalents; choose direct typed RootVisual reference and existing adapter copy.
3. Run original Pack57 default; report first result; max2 bounded substantive rounds and stop on no progress.
4. On scoped improvement, independent production/Core1062/Maker49 verification.
5. Freeze sources and source/test/ABI/layout/artifact ledgers; English review/report/handoff. Actual installation and full parent goal remain pending.
