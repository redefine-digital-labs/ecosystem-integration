# Application target read candidate: NOT_INSTALL_READY

One private Application function body reuses immutable Composition and RootVisual references. It reduces the unchanged positive10 VM reported units by13617 but does not repair the original negative11 default-budget failure. Actual sources remain uninstalled; full original modularization goal remains active.

Frozen1667 ordinary independent inputs: `frozen/inputs`. Manifest SHA256 `f4b3faa77d1640e69e63e53316de6231e946255a5101269bbe2b44756186f6d0`. Upstream manifest SHA256 `ad70e19cd71102d7ca2ace85abea6f0ed9a7cf7b645074a7ec2e311f530ff24f`. Sole source delta `move/soulidity_application/sources/character.move` SHA256 `007b812acfe2f35b2a7deec756d9d6e70a3cc326455a34469f35fbefa686bb4e` → `beda5ff11c690e9ef6dff596dd716549a60d97d68d06372a8a615333bde9dcff`. No symlinks;1343 fixed dependency files exact. No other production or test/manifest/lock input changed.

| Independent run | Actual result |
| --- | --- |
| 001 original Pack57/default/statistics |56PASS/1FAIL; exact ad70 identity/status |
| 002 production build |exit0;194 compiled modules, only Application character.mv changed |
| 003 whole Core1062/default |1061PASS/1FAIL; exact ad70 identity/status |
| 004 Maker49/default |49PASS; exact ad70 identity/status |

All743 test source files, including fixed dependencies, are byte exact. All original60 Core testfiles and historical buy_choice/positive10/negative11 are byte exact, including original loops10/11 and expected maker_catalog abort6. All1062 Core/57Pack/49Maker identities and statuses match ad70; original1058 identity subset preserved and1038 inherited original mapping remains unchanged. No removed/skipped/added/rewritten test or budget/loop override.

Sole function `state_target`: after original Composition borrow, EPart and use_follows_soul, borrow RootVisual directly via `dof::borrow(&c.id,RootVisualKey{})` once. Native matching and target scene use `&root_visual.scene`; root adapter branch copies `root_visual.adapters` exactly as before. Scoped profile adapter branch and forward loop selecting the last match remain unchanged. EAdapter, representation mapping, Source layout and Adapter layout check order unchanged. No changes to rights, issuer/cap/Config/source/funds validation or their call order. Immutable reference reuse is local to one call; no persistent authority cache/token/scene hash.

Three equivalents compared in design-options.json; direct RootVisual references minimize the diff without copying Scene or introducing an extra alias. Source proof: replacing candidate state_target with its exact old body restores the whole character source byte-for-byte; all207 public headers and44 struct declarations/layouts exact. No schema/API/type/ability/dependency change. This evidence concerns the unpublished candidate and does not assert old published compatibility or chain execution.

Original positive10 reported units ad70 `49999999813976` → candidate `49999999800359`, reduction13617. Negative11 remains saturated at `50000000000000`. VM reported units are not real chain Gas. Full57 cost rows retained in costs.json. Actual Pack and wholeCore failure now occurs at std::hash::sha2_256 through economics::assert_recovery_identity → assert_enabled → assert_primary → primary_quote → issuer::enhance_prepare → historical buy_choice. Earlier ad70 failure was dynamic object field borrow through character::state_root_visual/state_scene/state_target. This evidences scoped progress; exact failing iteration remains UNKNOWN, no marker or loop inference.

Stop after one substantive round: remaining actual failure is outside permitted state_target. No second source rewrite would be justified by current evidence. No scope expansion, issuer/cap reordering, authorization weakening, budget inflation or original test alteration. Parent must select any next scope from the new actual trace and perform independent review.

Fixed CLI SHA256 `1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3`. Each run retains before.json, raw.log, result.json, full command, environment path, sandbox policy, complete process exit, timestamps, source/hash/identity evidence and194-module bytecode ledger. Offline sandbox denies network and global ~/.move/frozen inputs/actual source writes; private MOVE_HOME; distinct install dirs. Source/generated inputs/locks, upstream1667, current broader5145 installed guard and original installed181 guard show zero drift in every run. Historical broader guard differed in2 continuation docs CURRENT/PROJECT_MEMORY before candidate creation; historical-guard-drift.json records that pre-existing change, then fresh guard pins current docs. Original181 source guard was never rebased and has zero drift.

Handbook1.0/OPERATING_MODEL8 attachment in REVIEW.md separates stage, status and exit checks. Candidate implemented/local, scoped verification partial, unreleased/undeployed. Recovery: ignore candidate and keep ad70/actual sources. No actual source/CURRENT/Git/remotes/wallet/keys/deploy/goal update occurred. Parent independent review, actual installation/release, original SDK/UI journeys and full-duty acceptance remain required.
