# Existing construction work: Application target read review

Attachment to the existing full contract modularization work; no replacement task board, owner change or release authorization. Handbook v1.0 (2026-10-06), sections1–4,7,8.3–8.4,9,12 and OPERATING_MODEL section8 read. Implementation owner and independent acceptance roles remain those of the parent construction record. Parent independent review remains pending.

Product operation: original fresh free Pack purchase uses exact published supply, preserves original Item identity on replacement, and rejects purchase beyond authored cap with maker_catalog abort6. Existing ad70 source fails default-budget negative11 while positive10 passes. Exact failing iteration is unknown.

Scope: one private Application function body, immutable transient references only. Production API, object identities/abilities/layout, Config authority, source validation, supply checks, settlement, rights and all original test bytes unchanged. No cache or token can outlive the function. All other1666 inputs and fixed dependencies remain byte exact.

| Check domain | Evidence/status | Remaining check |
| --- | --- | --- |
| Management/product | PASS scope matches original failing journey; full parent goal remains active | Original failure still needs repair |
| Agile acceptance | FAIL original negative11; PASS positive10 | Exact default-budget expected business abort6 |
| DevOps/recovery | PASS fixed CLI, offline sandbox, private MOVE_HOME, independent install dirs, process receipts, source hashes | Parent independent reproduction/review |
| Funds/payment | PASS source unchanged; no fee/rate/recipient/order delta | Actual chain journey remains parent work |
| Financial models | N/A no new price/model/mechanism | None in this candidate |
| Shared contract security | PASS source invariants and unchanged tests; failure scope retained | Independent parent review |
| Ethereum/EVM | N/A Sui-only candidate | None |
| Sui Move | PASS immutable refs/type checking, exact public declarations and struct layout, source/test ledger | Full Release gates remain parent work |
| Governance/upgrades/locks | PASS no authority/API/layout/dependency delta; no signature or upgrade | No deployed control claim |
| Operate/monitor/exit | N/A isolated source candidate, unreleased/undeployed | Existing owners retain parent integration/monitoring |

Authority paths remain actual Config/roles/revisions/issuer, Source policy and original supply count. Adapter loop preserves last matching adapter and copy. EPart and use_follows_soul run first, then RootVisual borrow at the old first state_scene evaluation. native_matches uses the same scene. Root and scoped adapter branch selection, EAdapter, mapping/source/adapter layout validation and order remain identical. Reusing an immutable DOF reference in this call introduces no permission or stored authority.

Compared3 local equivalent forms in design-options.json: direct RootVisual refs (chosen), alias scene reference (extra local), copied scene value (extra copy). Selected minimal sufficient form. Sole delta recorded in source-delta.patch; every other function text exact. No second source round is justified: the first negative trace now reaches economics.primary_quote identity hashing outside this authorized Application function. Do not move issuer/cap checks or broaden into economics under this spec.

Plan and Code local complete; Build/Test evidence recorded in REPORT.md. Release/Deploy/Operate/Monitor not performed. Acceptance differs from stage/status: source candidate implemented, original regression uncorrected, NOT_INSTALL_READY. Rollback is to ignore this candidate and retain ad70/actual source; actual sources were never installed.
