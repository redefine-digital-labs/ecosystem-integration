Generated with the repository phase_handoff.py in --dry-run mode and captured here to honor the candidate-only write boundary. No managed CURRENT, original handoff path or Git lock was written. The repository Snapshot below identifies authoritative continuation, not installation of this candidate.

# Soulidity Phase Handoff: application-target-read-candidate-v1

## Snapshot

- Created: 2026-10-11T09:05:28+03:00
- Phase: application-target-read-candidate-v1
- Status: in-progress
- Goal: Continue full original modularization with bounded Application target read optimization
- Worktree: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity`
- Branch: `codex/soul-dof-v1-contracts`
- Commit: `0cfb60a29b2b378dd9fbf31970b324b2ef2e301e`
- Working tree: dirty (38 status entries)
- Handoff: `docs/codex/handoffs/application-target-read-candidate-v1-20261011.md`

## Outcome

NOT_INSTALL_READY: one private state_target read delta; original negative11 still OOG; positive10 reported units lower13617. Actual sources uninstalled.

## Scope and non-goals

### In scope

- Application private state_target only; unchanged original tests/default budgets

### Intentionally not done

- No source installation, CURRENT, Git, remote, funds, keys, deployment or full-goal completion

## Durable decisions

- Preserve business validation/order, adapter last-match/copies and rights; no caches/tokens or issuer/cap reordering

## Changed paths and assets

### Changed paths

- /Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/application-target-read-candidate-v1/frozen/inputs/move/soulidity_application/sources/character.move

### Image and binary assets

- No image or binary assets recorded.

### Relevant commits

- No additional commit references recorded.

## Verification

- Pack57 default56PASS/1FAIL; Core1062 default1061PASS/1FAIL; Maker49 PASS; production exit0
- Original60Core and743 test source SHA exact;181 installed guard zero drift PASS

## Risks and recovery

### Risks or blockers

- Original negative11 still fails; exact failing iteration UNKNOWN; independent parent review pending

### Recovery or rollback points

- Actual sources untouched; ignore candidate and retain ad70 baseline

### Working-tree evidence

```text
 T packages/soulidity-sdk/src/chain-event-discovery.ts
 T packages/soulidity-sdk/src/chain-object-discovery.ts
 T packages/soulidity-sdk/src/coin-selection.ts
 T packages/soulidity-sdk/src/format.ts
 T packages/soulidity-sdk/src/object-inputs.ts
 T packages/soulidity-sdk/src/profile-read-step.ts
 T packages/soulidity-sdk/src/request.ts
 T packages/soulidity-sdk/src/sui-grpc-compat.ts
 T packages/soulidity-sdk/src/sui-network.ts
 T packages/soulidity-sdk/src/tx-result.ts
?? docs/CONTRACT_REBUILD_COVERAGE.json
?? docs/CONTRACT_REBUILD_SPEC_CN.md
?? docs/CONTRACT_SECURITY_REVIEW_CN.md
?? docs/SOUL_ARCHITECTURE_REVIEW_CN.md
?? docs/SOUL_STANDARD_KERNEL_CN.md
?? docs/codex/
?? docs/ecosystem-construction/
?? move/soulidity_application/
?? move/soulidity_community
?? move/soulidity_content/
?? move/soulidity_custody/
?? move/soulidity_foundation/
?? move/soulidity_model
?? move/soulidity_native/
?? move/soulidity_standard
?? move/soulidity_v1/
?? move/soulidity_visual
?? move/standard_examples/
?? output/
?? scripts/codex/
?? scripts/ecosystem/
?? scripts/inspect_contract_dependencies.py
?? scripts/profile_move_function_trace.py
?? scripts/verify_contract_ability_batches.py
?? scripts/verify_contract_ability_probes.py
?? scripts/verify_contract_publication_budget.py
?? scripts/verify_soul_standard_external.py
?? scripts/verify_soul_standard_local.mjs
```

## Exact next action

Parent independently review this frozen candidate; choose next bounded regression scope from actual economics primary_quote identity-hash trace.

