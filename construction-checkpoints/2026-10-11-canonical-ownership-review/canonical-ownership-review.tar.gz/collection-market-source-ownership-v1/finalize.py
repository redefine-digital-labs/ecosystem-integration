from pathlib import Path
import hashlib,json,re,shutil,difflib
O=Path(__file__).resolve().parent;S=O/'stage';B=O.parent/'coherent-market-maker-graph-v2/frozen/inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv(p):return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
baseline=inv(B);current=inv(S)
assert not any(p.is_symlink() for p in S.rglob('*'))
ledger=[];diff=[]
for key in sorted(baseline.keys()|current.keys()):
 if baseline.get(key)!=current.get(key):
  ledger.append({'path':key,'before':baseline.get(key),'after':current.get(key)})
  if key.endswith(('.move','.toml')):
   a=(B/key).read_text().splitlines(True) if key in baseline else []
   b=(S/key).read_text().splitlines(True) if key in current else []
   diff.extend(difflib.unified_diff(a,b,fromfile='baseline/'+key,tofile='candidate/'+key))
(O/'source-delta-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
(O/'source.patch').write_text(''.join(diff))
edges={};names={};seen=set()
def read_manifest(p):
 txt=(p/'Move.toml').read_text();data={};section=None
 for line in txt.splitlines():
  line=line.split('#',1)[0].strip()
  if line.startswith('['):section=line.strip('[]');data.setdefault(section,{})
  elif '=' in line:
   key,value=line.split('=',1);key=key.strip()
   if section=='package' and key=='name':data[section][key]=value.strip().strip('"')
   elif section in ('dependencies','dev-dependencies'):
    m=re.search(r'local\s*=\s*"([^"]+)"',value)
    assert m,(p,line)
    data[section][key]={'local':m[1]}
 return data
def visit(p,dev):
 p=p.resolve();key=(str(p),dev)
 if key in seen:return
 seen.add(key);data=read_manifest(p);label=str(p.relative_to(S))
 names[label]=data['package']['name'];edges.setdefault(label,[])
 groups=['dependencies']+(['dev-dependencies'] if dev else [])
 for group in groups:
  for alias,d in data.get(group,{}).items():
   assert 'local' in d,(p,group,alias,d)
   provider=(p/d['local']).resolve();assert provider.is_relative_to(S)
   plabel=str(provider.relative_to(S));edge={'provider':plabel,'alias':alias,'kind':group}
   if edge not in edges[label]:edges[label].append(edge)
   visit(provider,dev)
def closure(p,dev):
 old=set(seen);visit(p,dev)
 root=str(p.relative_to(S));visited=set();active=set()
 def walk(k):
  assert k not in active,('cycle',k,active)
  if k in visited:return
  active.add(k)
  for e in edges[k]:
   if dev or e['kind']=='dependencies':walk(e['provider'])
  active.remove(k);visited.add(k)
 walk(root);return sorted(visited)
market=closure(S/'move/soulidity_market',False)
core=closure(S/'move/soulidity_v1',False)
whole=closure(S/'move/collection_market_harness',True)
assert 'move/soulidity_v1' not in market
for package in ['soulidity_collection','soulidity_market']:
 assert all('soulidity_v1' not in p.read_text() for p in (S/'move'/package).rglob('*.move'))
(O/'package-dag.json').write_text(json.dumps({'acyclic':True,'independent_market_production_closure':market,'core_production_closure':core,'whole_including_dev_closure':whole,'edges':edges,'package_names':names},indent=2)+'\n')
test_ledger=[]
def test_ids(txt):return re.findall(r'#\[test(?=[,\]])[^\]]*\]\s*(?:#\[[^\]]+\]\s*)*fun (\w+)',txt)
for original in sorted((B/'move/soulidity_market/tests').glob('*.move')):
 candidate=S/'move/collection_market_harness/tests'/original.name
 a=original.read_text();b=candidate.read_text()
 assert test_ids(a)==test_ids(b)
 assert re.findall(r'abort_code\s*=\s*\d+',a)==re.findall(r'abort_code\s*=\s*\d+',b)
 # All business function bodies exactly match after the exhaustive permitted
 # namespace/type/helper transport applied to both sides. Declarations/imports
 # and expected-abort module locations are separately shown in source.patch.
 def normalize(txt):
  txt=re.sub(r'\b(?:soulidity_v1|soulidity_market|soulidity_collection|collection_market_harness)::','',txt)
  return txt
 # Compare function body from first declaration onward; tests include private
 # helpers and all statements/values, with only source qualification stripped.
 aa=normalize(a[a.index('fun '):]);bb=normalize(b[b.index('fun '):])
 assert aa==bb,original.name
 test_ledger.append({'file':original.name,'original_sha256':sha(original),'candidate_sha256':sha(candidate),'test_names':test_ids(a),'test_count':len(test_ids(a)),'function_bodies_equal_modulo_namespace_only':True,'abort_codes_unchanged':True})
assert sum(x['test_count'] for x in test_ledger)==64
# Every original Core test still exists. Function bodies outside fixtures stay
# exact modulo canonical nominal origins; all abort codes remain identical.
core_test_ledger=[]
for original in sorted((B/'move/soulidity_v1/tests').glob('*.move')):
 candidate=S/'move/soulidity_v1/tests'/original.name;assert candidate.exists()
 a=original.read_text();b=candidate.read_text()
 assert test_ids(a)==test_ids(b)
 assert re.findall(r'abort_code\s*=\s*\d+',a)==re.findall(r'abort_code\s*=\s*\d+',b)
 if original.name=='fixtures.move':assert b.startswith(a)
 elif a!=b:assert normalize(a[a.index('fun '):])==normalize(b[b.index('fun '):]),original.name
 core_test_ledger.append({'file':original.name,'original_sha256':sha(original),'candidate_sha256':sha(candidate),'test_names':test_ids(a),'test_count':len(test_ids(a))})
(O/'test-transport-ledger.json').write_text(json.dumps({'market64':test_ledger,'all_original_core_tests':core_test_ledger,'all_original_core_tests_retained':True,'fixtures_original_prefix_exact':True},indent=2)+'\n')
types=[];functions=[]
for mod,owner in [('collection','soulidity_collection'),('market','soulidity_market')]:
 original=B/'move/soulidity_v1/sources'/f'{mod}.move';leaf=S/'move'/owner/'sources'/f'{mod}.move';facade=S/'move/soulidity_v1/sources'/f'{mod}.move'
 a=original.read_text();l=leaf.read_text();w=facade.read_text()
 for name in re.findall(r'public struct (\w+)',a):
  types.append({'type':name,'previous_source_origin':'soulidity_v1::'+mod+'::'+name,'canonical_source_origin':owner+'::'+mod+'::'+name,'canonical_named_address':'0x10e' if mod=='collection' else '0x10d','old_published_compatible':False})
 for match in re.finditer(r'public(?:\(package\))? fun (\w+)[^{]+',a):
  name=match[1]
  wrapper=re.search(r'public(?:\(package\))? fun '+name+r'[^\n]+',w)
  assert wrapper,name
  assert 'implementation::'+name in wrapper[0]
  functions.append({'module':mod,'function':name,'original_signature':match[0].strip(),'core_wrapper':wrapper[0],'canonical_source':str(leaf.relative_to(S))})
 assert not re.search(r'public struct',w)
(O/'origin-and-api-deltas.json').write_text(json.dumps({'types_and_events':types,'original_public_function_journeys':functions,'operator_binding':'Collection.add_soul<W:drop>/add_kiosk_soul<C,W:drop>; authentic Core private witness supplied by facade; unchanged character::bind_collection stored TypeName validation','old_published_compatibility':False,'external_consumer_migration_required':True,'move_aliases_are_lexical_not_reexports':True},indent=2)+'\n')
# Production source sets exactly match actual successful receipts. Test-only
# bodies changed after Core build; run5 VM compiles and verifies the final set.
prod=lambda d:{k:v for k,v in d.items() if '/tests/' not in k and not k.startswith('move/collection_market_harness/')}
mb=json.loads((O/'round-1-market-build/result.json').read_text())
cb=json.loads((O/'round-2-core-build/result.json').read_text())
assert prod(cb['source_after'])==prod(current)
assert mb['source_after']['move/soulidity_market/sources/market.move']==current['move/soulidity_market/sources/market.move']
assert mb['source_after']['move/soulidity_collection/sources/collection.move']==current['move/soulidity_collection/sources/collection.move']
verification={'market_build':{'exit_code':mb['exit_code'],'modules':sum(p.endswith('.mv') and 'bytecode_modules/' in p for p in mb['artifacts']),'core_excluded':True},'core_build':{'exit_code':cb['exit_code'],'modules':sum(p.endswith('.mv') and 'bytecode_modules/' in p for p in cb['artifacts']),'exact_production_source_set_current':True},'market_vm':{'total':64,'passed':63,'failed':1,'failure':'core_market_role_does_not_authorize_independent_market: no abort; historical Core setup now uses canonical role'},'collection_vm':{'total':71,'passed':71,'failed':0},'all_dag_acyclic':True,'max_iterations':5,'source_or_protected_run_drift':{},'maker_pack_failure_preserved':'56/57 FAIL at default budget; not rerun','activation':'PROHIBITED','full_goal':'ACTIVE','overall':'INCOMPLETE'}
(O/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
F=O/'frozen';F.mkdir(exist_ok=False);shutil.copytree(S,F/'inputs',symlinks=False)
(F/'manifest.json').write_text(json.dumps({'algorithm':'sha256','input_count':len(current),'inputs':current},indent=2)+'\n')
print(json.dumps({'input_count':len(current),'changed':len(ledger),'frozen_manifest_sha256':sha(F/'manifest.json'),'market_test_count':64,'core_test_file_count':len(core_test_ledger),'dag_packages':len(whole),'verification':verification}))
