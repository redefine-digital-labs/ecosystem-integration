# Product engineering review attachment — original DOF-001 / P01 / P09

Existing product owners, reviewer responsibility, milestone/status and roadmap are retained. This local attachment is not a new task board or external message. Handbook1.0 sections1–5,7,8.3–8.4,9,12 and OPERATING_MODEL8 applied. Authoritative specs: primary docs/SOULIDITY_ECOSYSTEM_MODULARIZATION_SPEC_CN.md1.1 and docs/open-ecosystem/CONSTRUCTION_BOUNDARY_DECISIONS_CN.md; actual worktree memory/CURRENT/sole handoff read.

Stage: Plan/Code implemented; actual Build PASS; Test **FAIL63/64 Market**, Collection71/71 PASS with nominal origin transport. Release exit condition not met; Deploy/Operate/Monitor NOT RUN. Full original157 responsibilities/30 duties and parent goal ACTIVE retained. No additional owner/status or authorization assigned.

| Check | Result and evidence | Remaining check |
| --- | --- | --- |
| Management/product ownership | PASS scoped candidate: Maker original Collection/Physical relationship maintenance unit, no new repo; SPEC three options and source ledger | Parent independent review and existing record evidence |
| Agile acceptance | FAIL Market63/64; Collection71/71 PASS; preserved exact64 and all1062 original Core identities | Reconstruct historical authority fixture, preserve negative, rerun |
| DevOps/recovery | PASS local pinned tool/fixed dependencies, deny-network/deny-source-write receipts, frozen1678 plain inputs, acyclic29 DAG | Independent release/CI/recovery and activation gates |
| Payment/ledger | PASS scoped VM/source preservation: original Collection CEIL components and ordinary Market FLOOR unchanged; actual VM Coin payment/receipts | Real deployment and actual-chain receipts not performed |
| Financial engineering/DeFi | N/A no new financial product/model; source fees retained | Parent broader economics scope remains |
| Contract security | PASS unchanged generic witness check, role/policy/custody checks; FAIL historical role test premise | Historical old writer/authority negative proof and qualified independent review |
| Ethereum/EVM | N/A Sui-only candidate | None in this scope |
| Sui Move | PASS production root allocation/build, sole owner source, canonical type transports; no UID/cap/witness escape added | Unpublished origins are breaking, consumer/policy/event/object migration requires separate checks |
| Governance/upgrades/locks | Pending effective on-chain role/cap/publisher initialization and upgrades; source register/Factory init retained | Verify actual current callable lineage and every authority path; source/VM are not deployment proof |
| Runtime/monitor/exit | PASS scoped permissionless terminal cleanup and current holder/Right VM checks | Real deployment/operation/monitoring; unchanged known D26 and Maker PackFAIL |

Mechanism: creator owns membership admission; stored authentic operator scopes Soul mutation; role4 private leaf authority scopes Right custody; actual leaf Factory Publisher scopes Right policy and package role register; role3 private canonical Market authority scopes settlement. Account keeps native cap; holder buys/sells Right and receives collection proceeds. All original supply/fees/rounding/CAS/terminal/exit checks are retained; no new timelock, multisig, immutability or pause control is claimed. Role registration still requires actual Config/Admin expected revision/hash plus Publisher/latest UpgradeCap; no production legacy authority remains in Core delegates.

Known failure: common VM enabled Config helper now bootstraps canonical Market role, so the unchanged historical-Core-role negative test completes instead of aborting. This is a fixture-premise regression, not a finding that the canonical role can safely stand in for historical Core. Keep expected abort2 from package_roles; do not add a production legacy role or authority alias. Exact source/diagnostic and follow-up are in REPORT.md.

Release decision: **DO NOT ACTIVATE**. Bounds exhausted at iteration5. Source candidate and failures are durable; rollback is ignoring isolated directory. No real keys/funds/signatures, chain, UI, Git, remotes, installed/frozen input writes. High-risk external/qualified audit and complete original product acceptance remain separate and unperformed.
