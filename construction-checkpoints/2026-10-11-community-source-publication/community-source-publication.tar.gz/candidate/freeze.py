#!/usr/bin/env python3
import hashlib,json,stat
from pathlib import Path
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (OUT/'frozen-manifest.json').exists()
files=set()
for folder in ['repository','payload']:
 for p in (OUT/folder).rglob('*'):
  if p.is_file() and not any(x in p.relative_to(OUT/folder).parts for x in ['output','build','__pycache__','.git']):files.add(p)
files.update(p for p in OUT.iterdir() if p.is_file() and not p.name.startswith(('preparation-','freeze.log','probes.log')))
e=json.loads((OUT/'final-semantic-evidence.json').read_text())
for key in ['sui_version','network_denial_probe','build','test']:files.add(OUT/'repository'/e[key]['log'])
files.update((OUT/'repository'/Path(e['build']['log']).parent/'production/build/SoulidityCommunity/bytecode_modules').glob('*.mv'))
m={'schema':'community-source-cutover-frozen-v2','scope':'source-only; workflow preserved; remote semantic CI unfinished','independent_review':'pending','actual_sources_activated':False,'actual_approval_present':False,'operations_sha256':sha(OUT/'operations.json'),'control_sha256':sha(OUT/'community_cutover.py'),'v1_manifest_sha256':'20ae322d5aac7aff0ecc41f10a75790a49208825c52a5a2f82ccaa19226f3694','files':{str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for p in sorted(files)}}
m['file_count']=len(m['files']);(OUT/'frozen-manifest.json').write_text(json.dumps(m,sort_keys=True,indent=2)+'\n');(OUT/'frozen-manifest.sha256').write_text(sha(OUT/'frozen-manifest.json')+'  frozen-manifest.json\n');print(json.dumps({'files':m['file_count'],'manifest_sha256':sha(OUT/'frozen-manifest.json')}))
