#!/usr/bin/env python3
"""Real guarded CAS rehearsals, all source writes contained in this output."""
import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
ACTUAL=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-community')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((OUT/'frozen-manifest.json').read_text());mh=sha(OUT/'frozen-manifest.json');plan=json.loads((OUT/'operations.json').read_text());checks=[]
(OUT/'approvals').mkdir(exist_ok=True);(OUT/'rehearsals').mkdir(exist_ok=True);(OUT/'probe-logs').mkdir(exist_ok=True)
def approval(target,name,**changes):
 a={'schema':'community-cutover-approval-v2','approved':True,'scope':'rehearsal','target':str(target),'manifest_sha256':mh,'operations_sha256':m['operations_sha256'],'control_sha256':m['control_sha256'],'allowed_actions':['seed','apply','rollback','resume'],'reviewer':'isolated rehearsal fixture, not actual authorization','authorization_ref':'SPEC.md isolated-only recovery exercise'};a.update(changes);p=OUT/'approvals'/name;p.write_text(json.dumps(a,sort_keys=True,indent=2)+'\n');return p

def run(label,cmd,target,ap=None,ok=0,extra=None):
 argv=[sys.executable,str(OUT/'community_cutover.py'),cmd,'--target',str(target),'--expected-manifest-sha',mh]
 if ap:argv+=['--approval',str(ap)]
 argv+=extra or [];r=subprocess.run(argv,capture_output=True,text=True);p=OUT/'probe-logs'/(label+'.log');p.write_text(r.stdout+r.stderr);assert r.returncode==ok,(label,r.returncode,r.stdout,r.stderr);checks.append({'label':label,'argv':argv,'exit_code':r.returncode,'log':str(p.relative_to(OUT)),'log_sha256':sha(p)});return r

def seed(name):
 t=OUT/'rehearsals'/name;a=approval(t,name+'.json');run(name+'-seed','seed',t,a);return t,a

def equality(t,phase):
 for op in plan['operations']:
  p=t/op['relative'];s=op[phase]
  if s['kind']=='absent':assert not p.exists(),op['relative']
  else:assert sha(p)==s['sha256'] and p.stat().st_mode&0o777==s['mode'],op['relative']
 for rel,s in plan['protected'].items():assert sha(t/rel)==s['sha256'] and (t/rel).stat().st_mode&0o777==s['mode'],rel

run('actual-baseline','check',ACTUAL)
run('actual-approval-absent','apply',ACTUAL,ok=1)
t,a=seed('normal');run('real-apply','apply',t,a);equality(t,'after');run('apply-idempotent','apply',t,a);run('real-rollback','rollback',t,a);equality(t,'before');run('rollback-idempotent','rollback',t,a)
t,a=seed('hard-interrupt');run('hard-exit-after-write-before-journal','apply',t,a,ok=73,extra=['--fault-after','193','--fault-point','after-write']);j=json.loads((t/'.cas/journal.json').read_text());assert j['status']=='applying' and len(j['completed'])==192;assert sha(t/plan['operations'][192]['relative'])==plan['operations'][192]['after']['sha256'];run('resume-after-hard-exit','resume',t,a);equality(t,'after');run('resume-applied-idempotent','resume',t,a);run('interrupt-rollback','rollback',t,a,ok=73,extra=['--fault-after','3','--fault-point','after-write']);run('resume-rollback','resume',t,a);equality(t,'before');run('resume-restored-idempotent','resume',t,a)
t,a=seed('journal-interrupt');run('hard-exit-after-journal','apply',t,a,ok=74,extra=['--fault-after','4']);run('resume-after-journal','resume',t,a);run('journal-interrupt-rollback','rollback',t,a);equality(t,'before')
t,a=seed('negative-baseline');op=next(x for x in plan['operations'] if x['before']['kind']=='file');p=t/op['relative'];p.write_bytes(p.read_bytes()+b'\nDRIFT');run('baseline-drift-refused','apply',t,a,ok=1);assert not (t/'.cas/journal.json').exists()
t,a=seed('negative-protected');p=t/'move/soulidity_community/sources/profile.move';p.write_bytes(p.read_bytes()+b'\nDRIFT');run('protected-drift-refused','apply',t,a,ok=1)
t,a=seed('negative-unknown');run('unknown-partial','apply',t,a,ok=74,extra=['--fault-after','3']);p=t/plan['operations'][0]['relative'];p.chmod(0o644);p.write_bytes(b'UNKNOWN');run('unknown-outcome-refused','resume',t,a,ok=1)
t,a=seed('negative-backup');run('backup-partial','apply',t,a,ok=74,extra=['--fault-after','2']);p=next((t/'.cas/backups').iterdir());p.chmod(0o644);p.write_bytes(b'CORRUPT');run('corrupt-backup-refused','rollback',t,a,ok=1)
t,a=seed('negative-missing-backup');run('missing-backup-partial','apply',t,a,ok=74,extra=['--fault-after','2']);next((t/'.cas/backups').iterdir()).unlink();run('missing-backup-refused','resume',t,a,ok=1)
t,a=seed('negative-journal');run('journal-partial','apply',t,a,ok=74,extra=['--fault-after','2']);p=t/'.cas/journal.json';j=json.loads(p.read_text());j['target']='wrong';p.write_text(json.dumps(j));run('journal-binding-refused','resume',t,a,ok=1)
t,a=seed('negative-symlink');p=t/'move/soulidity_community/sources/profile.move';p.unlink();p.symlink_to(OUT/'repository/move/soulidity_community/sources/profile.move');run('source-symlink-refused','apply',t,a,ok=1)
t,a=seed('negative-hardlink');p=t/'move/soulidity_community/sources/profile.move';p.unlink();os.link(OUT/'rehearsals/normal/move/soulidity_community/sources/profile.move',p);run('source-hardlink-refused','apply',t,a,ok=1);p.unlink()
t,a=seed('negative-lock');(t/'.cas').mkdir();fd=os.open(t/'.cas/exclusive.lock',os.O_CREAT|os.O_RDWR,0o600);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);run('concurrent-lock-refused','apply',t,a,ok=1);os.close(fd);run('lock-released-apply','apply',t,a);run('lock-released-rollback','rollback',t,a);equality(t,'before')
t=OUT/'rehearsals/unapproved';a=approval(t,'unapproved.json',approved=False);run('unapproved-json-refused','seed',t,a,ok=1)
t=OUT/'rehearsals/wrong-pins';a=approval(t,'wrong-ops.json',operations_sha256='0'*64);run('approval-operations-binding-refused','seed',t,a,ok=1);a=approval(t,'wrong-control.json',control_sha256='0'*64);run('approval-control-binding-refused','seed',t,a,ok=1);a=approval(t,'wrong-manifest.json',manifest_sha256='0'*64);run('approval-manifest-binding-refused','seed',t,a,ok=1)
a=approval(ACTUAL,'actual-unapproved-template.json',approved=False,scope='actual',human_source_activation_authorized=False);run('actual-unapproved-template-refused','apply',ACTUAL,a,ok=1)
a=approval(ACTUAL,'actual-rehearsal-binding.json');run('rehearsal-cannot-authorize-actual','apply',ACTUAL,a,ok=1)
run('outside-target-refused','apply',OUT/'repository',a,ok=1);run('bad-frozen-pin-refused','check',ACTUAL,ok=1,extra=['--expected-manifest-sha','0'*64])
link=OUT/'rehearsals/target-alias';link.symlink_to(OUT/'rehearsals/normal',target_is_directory=True);a=approval(link,'target-alias.json');run('target-symlink-refused','apply',link,a,ok=1);link.unlink()
p=OUT/plan['operations'][0]['payload'];original=p.read_bytes();mode=p.stat().st_mode&0o777;p.chmod(0o644);p.write_bytes(b'FROZEN DRIFT');run('frozen-payload-refused','check',ACTUAL,ok=1);p.write_bytes(original);p.chmod(mode)
run('actual-final-baseline','check',ACTUAL)
v1=OUT.parent/'community-independent-source-candidate-v1';old=json.loads((v1/'frozen-manifest.json').read_text());assert sha(v1/'frozen-manifest.json')=='20ae322d5aac7aff0ecc41f10a75790a49208825c52a5a2f82ccaa19226f3694'
for rel,row in old['files'].items():assert sha(v1/rel)==row['sha256'],rel
whole=OUT.parent/'coherent-source-activation-plan-v1/source_cutover.py';assert sha(whole)==json.loads((OUT/'input-pins.json').read_text())['whole_actual_guard_sha256']
result={'schema':'community-cutover-real-rehearsal-v2','result':'PASS','checks':checks,'checks_count':len(checks),'actual_source_mutations':0,'actual_approval_present':False,'manifest_sha256':mh,'v1_frozen452_unchanged':True,'whole_plan_guard_unchanged':True,'full157_30_goal':'ACTIVE','remote_semantic_ci':'unfinished','real_apply_rollback_exact_equality':True,'hard_interrupt_before_journal_resume':True,'rollback_interruption_resume':True}
(OUT/'probe-results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({'result':'PASS','checks':len(checks)}))
