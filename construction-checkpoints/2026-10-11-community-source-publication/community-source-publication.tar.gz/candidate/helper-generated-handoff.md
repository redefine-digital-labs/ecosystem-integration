# Soulidity Phase Handoff: Community source-only cutover v2

## Snapshot

- Created: 2026-10-11T11:52:16+03:00
- Phase: Community source-only cutover v2
- Status: in-progress
- Goal: Bounded Community source candidate and guarded approval CAS within ACTIVE full157/30 goal
- Worktree: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity`
- Branch: `codex/soul-dof-v1-contracts`
- Commit: `0cfb60a29b2b378dd9fbf31970b324b2ef2e301e`
- Working tree: dirty (38 status entries)
- Handoff: `docs/codex/handoffs/20261011-115216-community-source-only-cutover-v2.md`

## Outcome

Source-only194 operations preserve actual CI workflow; fresh offline original106 tests/exact4 artifacts PASS; actual source unactivated and remote semantic CI unfinished

## Scope and non-goals

### In scope

- Only community-independent-source-candidate-v2 output; actual owning source read-only

### Intentionally not done

- No additional non-goals recorded.

## Durable decisions

- No durable decisions recorded for this boundary.

## Changed paths and assets

### Changed paths

- output/ecosystem-construction/repository-split-2026-10-10/maker-manufacturing-extraction/community-independent-source-candidate-v2

### Image and binary assets

- No image or binary assets recorded.

### Relevant commits

- No additional commit references recorded.

## Verification

- Real CAS apply/rollback, hard interruption/resume, idempotence and refusal logs PASS

## Risks and recovery

### Risks or blockers

- No actual source approval; remote semantic CI trust/runtime/remote execution unfinished; independent review pending

### Recovery or rollback points

- Pinned independent backups and durable atomic phase journal; no onchain rollback claim

### Working-tree evidence

```text
 T packages/soulidity-sdk/src/chain-event-discovery.ts
 T packages/soulidity-sdk/src/chain-object-discovery.ts
 T packages/soulidity-sdk/src/coin-selection.ts
 T packages/soulidity-sdk/src/format.ts
 T packages/soulidity-sdk/src/object-inputs.ts
 T packages/soulidity-sdk/src/profile-read-step.ts
 T packages/soulidity-sdk/src/request.ts
 T packages/soulidity-sdk/src/sui-grpc-compat.ts
 T packages/soulidity-sdk/src/sui-network.ts
 T packages/soulidity-sdk/src/tx-result.ts
?? docs/CONTRACT_REBUILD_COVERAGE.json
?? docs/CONTRACT_REBUILD_SPEC_CN.md
?? docs/CONTRACT_SECURITY_REVIEW_CN.md
?? docs/SOUL_ARCHITECTURE_REVIEW_CN.md
?? docs/SOUL_STANDARD_KERNEL_CN.md
?? docs/codex/
?? docs/ecosystem-construction/
?? move/soulidity_application/
?? move/soulidity_community
?? move/soulidity_content/
?? move/soulidity_custody/
?? move/soulidity_foundation/
?? move/soulidity_model
?? move/soulidity_native/
?? move/soulidity_standard
?? move/soulidity_v1/
?? move/soulidity_visual
?? move/standard_examples/
?? output/
?? scripts/codex/
?? scripts/ecosystem/
?? scripts/inspect_contract_dependencies.py
?? scripts/profile_move_function_trace.py
?? scripts/verify_contract_ability_batches.py
?? scripts/verify_contract_ability_probes.py
?? scripts/verify_contract_publication_budget.py
?? scripts/verify_soul_standard_external.py
?? scripts/verify_soul_standard_local.mjs
```

## Exact next action

Independently review v2 frozen manifest and actual approval-bound CAS; Root owns any later activation/backup; keep Gate0/chain/release/fullgoal separate

