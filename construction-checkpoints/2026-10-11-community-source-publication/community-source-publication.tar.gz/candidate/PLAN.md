# Execution and exit criteria

1. Read authoritative worktree state and bounded v1; verify v1 frozen452 manifest. PASS.
2. Derive source-only194 operations, preserving owning workflow and original semantic inputs. PASS.
3. Run exact registered `python3 scripts/ci.py --product` with pinned runtime, offline build/original106 tests/exact4 artifacts. PASS.
4. Freeze source/control/operations/evidence, then exercise actual CAS implementation against isolated seeded copies; no owning repository apply. Required recovery and refusals recorded in probe-results.json.
5. Deliver immutable candidate and separate terminal evidence; independent review remains pending. Full goal active; no release/chain/product completion claim.

Handbook1.0 sections1–5,7,8.3–8.4,9,12; OPERATING_MODEL section8. Existing DOF-001/P01/P09 owners/status stay unchanged. Stage=Test / source candidate awaiting independent acceptance; original record attachment remains pending Root-owned update, not a new board.
