#!/usr/bin/env python3
"""Frozen Community CAS apply/rollback/resume. Actual writes require reviewed opt-in JSON."""
import argparse, fcntl, hashlib, json, os, stat, tempfile
from pathlib import Path, PurePosixPath
OUT=Path(__file__).absolute().parent
ACTUAL=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-community')
def require(ok,msg):
 if not ok:raise ValueError(msg)
def noalias(p):
 for q in [p]+list(p.parents):require(not q.is_symlink(),'symlink refused: '+str(q))
 if p.exists() and p.is_file():require(p.stat().st_nlink==1,'hardlink alias refused: '+str(p))
def sha(p):
 noalias(p);return hashlib.sha256(p.read_bytes()).hexdigest()
def state(p):
 noalias(p)
 if not p.exists():return {'kind':'absent'}
 require(p.is_file(),'unsupported file kind: '+str(p))
 return {'kind':'file','sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def safe(root,rel,internal=False):
 path=PurePosixPath(rel)
 require(isinstance(rel,str) and str(path)==rel and not path.is_absolute() and '..' not in path.parts and '\\' not in rel and path.parts,'unsafe path')
 require(internal or path.parts[0] not in ['.git','.cas'],'reserved operation path')
 p=root/rel;noalias(p);require(p.resolve().is_relative_to(root.resolve()),'path escape refused');return p
def fsyncdir(p):
 fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
def atomic(p,data,mode=0o644):
 noalias(p);p.parent.mkdir(parents=True,exist_ok=True);noalias(p.parent)
 fd,tmp=tempfile.mkstemp(prefix='.community-cas-',dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fchmod(f.fileno(),mode);os.fsync(f.fileno())
  noalias(p);os.replace(tmp,p);fsyncdir(p.parent)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def save(p,data):atomic(p,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode(),0o600)
def put(p,s,blob=None):
 noalias(p)
 if s['kind']=='absent':
  if p.exists():p.unlink();fsyncdir(p.parent)
 else:
  require(blob is not None and sha(blob)==s['sha256'],'payload/backup digest mismatch');atomic(p,blob.read_bytes(),s['mode'])
def frozen(a):
 mp=OUT/'frozen-manifest.json';m=json.loads(mp.read_text());mh=sha(mp)
 require(a.expected_manifest_sha==mh,'exact frozen manifest pin required')
 require(sha(OUT/'operations.json')==m['operations_sha256'] and sha(Path(__file__))==m['control_sha256'],'operations/control pin mismatch')
 for rel,row in m['files'].items():
  p=safe(OUT,rel);require(state(p)=={'kind':'file','sha256':row['sha256'],'mode':row['mode']} and p.stat().st_size==row['bytes'],'frozen input drift: '+rel)
 return m,mh
def authorize(a,target,m,mh):
 require(a.approval is not None,'reviewed approval JSON required for any mutation')
 p=a.approval.absolute();noalias(p);require(p.is_relative_to(OUT/'approvals'),'approval must be in this candidate approvals directory')
 approval=json.loads(p.read_text());kind='actual' if target==ACTUAL else 'rehearsal'
 require(approval.get('schema')=='community-cutover-approval-v2' and approval.get('approved') is True,'approval is absent or not approved')
 for key,value in {'target':str(target),'manifest_sha256':mh,'operations_sha256':m['operations_sha256'],'control_sha256':m['control_sha256'],'scope':kind}.items():require(approval.get(key)==value,'approval binding mismatch: '+key)
 require(a.command in approval.get('allowed_actions',[]),'action not approved')
 require(approval.get('reviewer') and approval.get('authorization_ref'),'review identity/authorization reference required')
 if kind=='actual':require(approval.get('human_source_activation_authorized') is True,'actual source authorization absent')
 return sha(p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['check','seed','apply','rollback','resume']);ap.add_argument('--target',type=Path,default=ACTUAL);ap.add_argument('--expected-manifest-sha');ap.add_argument('--approval',type=Path);ap.add_argument('--fault-after',type=int);ap.add_argument('--fault-point',choices=['after-write','after-journal'],default='after-journal');a=ap.parse_args()
 target=a.target.absolute();noalias(target);require(target==ACTUAL or target.is_relative_to(OUT/'rehearsals'),'exact owning repo or isolated rehearsal required')
 require(target.resolve()==target,'target alias refused');m,mh=frozen(a);plan=json.loads((OUT/'operations.json').read_text());ops=plan['operations'];protected=plan['protected']
 require(plan['target']==str(ACTUAL),'owning repository identity mismatch')
 require(len({x['relative'] for x in ops})==len(ops) and not set(protected)&{x['relative'] for x in ops},'duplicate/protected operation')
 for op in ops:require(state(safe(OUT,op['payload']))==op['after'],'payload state drift');safe(target,op['relative'])
 for rel in protected:safe(target,rel)
 def protect(root):
  for rel,s in protected.items():require(state(safe(root,rel))==s,'protected drift: '+rel)
 if a.command=='check':
  drift=[op['relative'] for op in ops if state(safe(target,op['relative']))!=op['before']]+[rel for rel,s in protected.items() if state(safe(target,rel))!=s]
  print(json.dumps({'status':'BASELINE_PASS' if not drift else 'BASELINE_DRIFT','baseline_drift':drift,'operations':len(ops),'actual_approval_present':False}));return 0 if not drift else 1
 ah=authorize(a,target,m,mh)
 require(a.fault_after is None or target!=ACTUAL,'fault injection is rehearsal only')
 if a.command=='seed':
  require(target!=ACTUAL and not target.exists(),'seed requires fresh isolated target');protect(ACTUAL)
  for op in ops:require(state(safe(ACTUAL,op['relative']))==op['before'],'actual baseline drift: '+op['relative'])
  target.mkdir(parents=True)
  for op in ops:put(safe(target,op['relative']),op['before'],safe(ACTUAL,op['relative']) if op['before']['kind']=='file' else None)
  for rel,s in protected.items():put(safe(target,rel),s,safe(ACTUAL,rel))
  print(json.dumps({'status':'SEEDED','operations':len(ops)}));return 0
 require(target.is_dir(),'target missing');control=safe(target,'.cas',True);control.mkdir(exist_ok=True);noalias(control)
 lock=safe(control,'exclusive.lock',True);fd=os.open(lock,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
 try:
  require(os.fstat(fd).st_nlink==1,'lock alias refused')
  try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise ValueError('concurrent cutover refused')
  journal=safe(control,'journal.json',True);backup=safe(control,'backups',True);protect(target)
  if not journal.exists():
   require(a.command=='apply','journal missing: only apply initializes')
   for op in ops:require(state(safe(target,op['relative']))==op['before'],'CAS baseline mismatch: '+op['relative'])
   j={'schema':'community-cas-journal-v2','manifest_sha256':mh,'operations_sha256':m['operations_sha256'],'control_sha256':m['control_sha256'],'target':str(target),'approval_sha256':ah,'status':'preparing','completed':[],'rolled_back':[]};save(journal,j)
  else:
   j=json.loads(journal.read_text())
   for key,value in {'schema':'community-cas-journal-v2','manifest_sha256':mh,'operations_sha256':m['operations_sha256'],'control_sha256':m['control_sha256'],'target':str(target),'approval_sha256':ah}.items():require(j.get(key)==value,'journal identity mismatch: '+key)
   require(j['status'] in ['preparing','applying','applied','rolling_back','restored'],'unknown journal status')
  # Validate the entire candidate before any file mutation; only exact before/after crash outcomes are accepted.
  for i,op in enumerate(ops):
   s=state(safe(target,op['relative']));require(s in [op['before'],op['after']],'unknown CAS outcome: '+op['relative'])
   if j['status'] in ['preparing','restored']:require(s==op['before'],'expected restored/baseline state: '+op['relative'])
   if j['status']=='applied':require(s==op['after'],'expected applied state: '+op['relative'])
  if j['status']=='preparing':
   backup.mkdir(exist_ok=True);noalias(backup)
   for op in ops:
    if op['before']['kind']=='file':
     p=safe(backup,op['before']['sha256'],True)
     if not p.exists():atomic(p,safe(target,op['relative']).read_bytes(),0o444)
     require(sha(p)==op['before']['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444,'independent backup drift')
   fsyncdir(backup);j['status']='applying';save(journal,j)
  for op in ops:
   if op['before']['kind']=='file':
    p=safe(backup,op['before']['sha256'],True);require(sha(p)==op['before']['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444,'independent backup drift')
  rollback=a.command=='rollback' or j['status']=='rolling_back'
  if j['status']=='restored':
   require(a.command in ['rollback','resume'],'restored transaction cannot reapply');print(json.dumps({'status':'RESTORED_IDEMPOTENT'}));return 0
  if j['status']=='applied' and not rollback:print(json.dumps({'status':'APPLIED_IDEMPOTENT'}));return 0
  if rollback:j['status']='rolling_back';save(journal,j)
  indices=list(reversed(range(len(ops)))) if rollback else list(range(len(ops)))
  field='rolled_back' if rollback else 'completed'
  for i in indices:
   op=ops[i];protect(target);p=safe(target,op['relative']);require(state(p) in [op['before'],op['after']],'CAS changed during transaction')
   desired=op['before'] if rollback else op['after'];blob=(safe(backup,desired['sha256'],True) if rollback else safe(OUT,op['payload'])) if desired['kind']=='file' else None
   if state(p)!=desired:put(p,desired,blob)
   require(state(p)==desired,'mutation readback failure')
   if a.fault_after==indices.index(i)+1 and a.fault_point=='after-write':os._exit(73)
   if i not in j[field]:j[field].append(i)
   save(journal,j)
   if a.fault_after==indices.index(i)+1 and a.fault_point=='after-journal':os._exit(74)
  protect(target);j['status']='restored' if rollback else 'applied';save(journal,j)
  print(json.dumps({'status':'RESTORED' if rollback else 'APPLIED','target':str(target),'operations':len(ops),'actual':target==ACTUAL}));return 0
 finally:os.close(fd)
if __name__=='__main__':
 try:raise SystemExit(main())
 except (ValueError,OSError,KeyError,TypeError) as e:print('Community cutover refused: '+str(e),file=__import__('sys').stderr);raise SystemExit(1)
