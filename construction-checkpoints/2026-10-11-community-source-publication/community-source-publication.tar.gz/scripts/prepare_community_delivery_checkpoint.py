from pathlib import Path
import hashlib, io, json, re, stat, tarfile

ACT=Path('/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity')
BASE=ACT/'output/ecosystem-construction/repository-split-2026-10-10/maker-manufacturing-extraction'
RB=Path(__file__).parent
DEST=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/ecosystem-integration/construction-checkpoints/2026-10-11-community-source-publication')
members={}

def sha(data): return hashlib.sha256(data).hexdigest()

def add(path,name,digest=None):
    assert path.is_file() and not path.is_symlink()
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert not any(x in path.parts for x in ('node_modules','__pycache__','.git'))
    assert path.name not in ('sui.keystore','client.yaml','network.yaml','coordinator-approval.json','signed-recovery.json')
    data=path.read_bytes()
    if digest: assert sha(data)==digest, str(path)
    for pattern in (rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'suiprivkey1[a-z0-9]{30,}',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'xox[baprs]-[A-Za-z0-9-]{20,}',rb'AKIA[A-Z0-9]{16}'):
        assert not re.search(pattern,data),'Credential encoding in '+name
    value=(data,stat.S_IMODE(path.stat().st_mode))
    assert name not in members or members[name]==value
    members[name]=value

def mapped(root,rows,prefix):
    for rel,row in rows.items():
        digest=row['sha256'] if isinstance(row,dict) else row
        add(root/rel,prefix+'/'+rel,digest)

c=BASE/'community-independent-source-candidate-v2'
add(c/'frozen-manifest.json','candidate/frozen-manifest.json','92e3426aed0648b8274954e79d7528c5198065011d7beb5c20b9f730140a3cef')
mapped(c,json.loads((c/'frozen-manifest.json').read_text())['files'],'candidate')
add(c/'terminal-evidence-manifest.json','candidate/terminal-evidence-manifest.json','5d17feeff9c13fd789c5bd5a568b18f1ad2ddf1762c1802c4c69fd6db0e85abe')
mapped(c,json.loads((c/'terminal-evidence-manifest.json').read_text())['files'],'candidate')
for directory in ('community-source-cutover-v2-readonly-review','community-publication-v5-readonly-review',
                  'community-source-cutover-root-prerequisites-v2','community-source-actual-activation-v2'):
    for path in sorted((BASE/directory).iterdir()):
        if path.is_file() and not path.is_symlink():add(path,'evidence/'+directory+'/'+path.name)
p=BASE/'actual-publication-preparation-v5'
add(p/'state.json','publication/state-after-first-community.json','d33aadc933a1a42aea0c7df1d44ddc36e7c8d3372e42cbcc37938ad50853722b')
add(p/'state-preparation-snapshot.json','publication/state-before-first-community.json','395ce5bcbc4d6a333c8ab7c4e30b48d62b82b7db9fd234b776181923d5f310ce')
for path in sorted((p/'intents/revision-0-soulidity_community').iterdir()):
    if path.is_file():add(path,'publication/'+path.name)
for name in ('community-source-remote.json','native-community-remote.json','verify_community_source_remote.py',
             'verify_native_community_remote.py','check_community_v2_prerequisites.py'):
    add(RB/name,'remote/'+name)
assert json.loads((RB/'community-source-remote.json').read_text())['status']=='PASS_FRESH_PUBLIC_SOURCE_RECOVERY'
for name in ('CURRENT.md','PROJECT_MEMORY.md'):add(ACT/'docs/codex'/name,'continuation/'+name)
text=(ACT/'docs/codex/CURRENT.md').read_text()
handoff=re.search(r'Latest handoff: `([^`]+)`',text).group(1)
add(ACT/handoff,'continuation/'+Path(handoff).name)
add(ACT/'docs/ecosystem-construction/ACTIVE_CONSTRUCTION_CN.md','continuation/ACTIVE_CONSTRUCTION_CN.md')
add(Path(__file__),'scripts/'+Path(__file__).name)
assert not DEST.exists(),'Never overwrite an existing checkpoint'
DEST.mkdir(parents=True)
archive=DEST/'community-source-publication.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for name,(data,mode) in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=mode;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
manifest={'algorithm':'sha256','archive':archive.name,'archive_sha256':sha(archive.read_bytes()),
          'member_count':len(members),'members':{k:{'sha256':sha(v[0]),'bytes':len(v[0]),'mode':v[1]} for k,v in sorted(members.items())},
          'scope':'Community independent source activation and first isolated publication; full157/30 active',
          'excluded':['custody keys/fingerprints and signed recovery files','runtime databases/network configs/binaries/caches','repeated source/build copies'],
          'credential_scan':'PASS known credential encodings absent'}
(DEST/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as tar:
    actual={m.name:{'sha256':sha(tar.extractfile(m).read()),'bytes':m.size,'mode':m.mode} for m in tar.getmembers()}
assert actual==manifest['members']
(DEST/'README.md').write_text('''# Actual independent Community source and isolated publication

Full157 responsibilities/30 original duties/1528 queue reconstruction remains active. Original Owners and15 retained units remain unchanged.

- Owning source commit [aa3cff3642885ef0dc1707c2e8bf037b725306ec](https://github.com/redefine-digital-labs/soul-community/commit/aa3cff3642885ef0dc1707c2e8bf037b725306ec) is public.194 exact operations activated after independent review;30 protected states and recovery backups verified. Original four production and five test bodies remain unchanged.
- Actual owning and fresh public clone registered offline builds pass106 original tests and exact four module hashes, only Sui/MoveStdlib187 contained framework inputs. Remote semantic CI, independent release, operation and original UI remain pending; Actions are disabled.
- Exact first Community transaction EqefAQPJodhGbfyaCisqWPSAKKqfYooowCmrXUiXUean succeeded on retained isolated ae60751d/protocol137. Package e32112eb5933eb4011297316398355e05c9a889a8e5d56f02e2d4a39e271ea53, Genesis-held upgrade capability and four initialized registries passed transaction/package/origin/linkage/custody readback. This is1/19 roots in that publication snapshot; other18 are unapproved. Native seam graph is separate; production and effective-governance acceptance are not inferred.
- Source v2 frozen446 inputs,123 terminal receipts,53 real recovery/refusal logs, independent reviews and actual activation evidence are recoverable here. Original mode bits are included. Historical pre-execution facts retain their scope.
- Subsequent Community status prose replaces stale cross-module status. Exact old status and restore-before-source-rollback order are recorded. Local recovery journal is not committed. Source rollback cannot undo a published package; never replay the completed digest or reset retained Genesis/DB.

Verify archive SHA and every member SHA/length/mode against archive-manifest.json; extract only to a fresh directory. Pinned runtime binaries must be supplied separately. Historical absolute paths need deliberate replay remapping; archived tools/approval fixtures do not authorize execution. Custody data and signed recovery files are excluded. Gate0/D26/B0, remaining module activation/Channel, SDK/original UI/recovery, independent DevOps and full157/30 remain unfinished.
''')
print(json.dumps({'member_count':len(members),'archive_bytes':archive.stat().st_size,'archive_sha256':manifest['archive_sha256']}))
