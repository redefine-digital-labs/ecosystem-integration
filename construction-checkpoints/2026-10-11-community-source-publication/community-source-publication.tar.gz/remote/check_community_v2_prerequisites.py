"""Coordinator prerequisite verification, not independent release approval."""
from pathlib import Path
import base64, hashlib, json, stat, subprocess

ACT = Path('/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity')
BASE = ACT/'output/ecosystem-construction/repository-split-2026-10-10/maker-manufacturing-extraction'
OUT = BASE/'community-source-cutover-root-prerequisites-v2'
C = BASE/'community-independent-source-candidate-v2'
R = Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-community')
EXPECTED = '92e3426aed0648b8274954e79d7528c5198065011d7beb5c20b9f730140a3cef'

def sha(p):
    assert p.is_file() and not p.is_symlink(), str(p)
    return hashlib.sha256(p.read_bytes()).hexdigest()

def state(p):
    if not p.exists():
        return {'kind': 'absent'}
    return {'kind': 'file', 'sha256': sha(p), 'mode': stat.S_IMODE(p.stat().st_mode)}

assert sha(C/'frozen-manifest.json') == EXPECTED
frozen = json.loads((C/'frozen-manifest.json').read_text())
assert len(frozen['files']) == 446
for rel,row in frozen['files'].items():
    p=C/rel
    assert state(p)=={'kind':'file','sha256':row['sha256'],'mode':row['mode']}
    assert p.stat().st_size==row['bytes']
assert sha(C/'community_cutover.py') == frozen['control_sha256']
assert sha(C/'operations.json') == frozen['operations_sha256']
terminal=json.loads((C/'terminal-evidence-manifest.json').read_text())
assert terminal['frozen_source_manifest_sha256']==EXPECTED
for rel,row in terminal['files'].items():
    p=C/rel
    digest=row['sha256'] if isinstance(row,dict) else row
    assert sha(p)==digest
plan=json.loads((C/'operations.json').read_text())
assert len(plan['operations'])==194 and len(plan['protected'])==30
for op in plan['operations']:
    assert state(R/op['relative'])==op['before']
    assert state(C/op['payload'])==op['after']
for rel,s in plan['protected'].items():
    assert state(R/rel)==s
old=json.loads((R/'module.json').read_text())
new=json.loads((C/'repository/module.json').read_text())
for key in ('management','engineering_permissions','agent_contract','release_readiness'):
    assert old[key]==new[key], key
assert '.github/workflows/ci.yml' in plan['protected']
assert not any(x['relative'].startswith('.github/') for x in plan['operations'])
pins=json.loads((C/'repository/source-candidate-pins.json').read_text())
assert len(pins['inputs'])==198 and pins['project_dependencies']==[] and pins['expected_tests']==106
actual={str(p.relative_to(C/'repository')):sha(p)
        for folder in ('move','.deps') for p in (C/'repository'/folder).rglob('*')
        if p.is_file() and 'build' not in p.parts}
assert actual==pins['inputs']
proof=json.loads((C/'final-semantic-evidence.json').read_text())
assert proof['result']=='PASS' and proof['summary']=={'result':'OK','total':106,'passed':106,'failed':0}
assert proof['packages']==['MoveStdlib','SoulidityCommunity','Sui'] and proof['project_dependencies']==[]
assert proof['inputs_before']==pins['inputs'] and proof['production_artifacts']==pins['production_artifacts']
for label in ('build','test','network_denial_probe'):
    log=proof[label]['log']
    assert sha(C/'repository'/log)==proof[label]['log_sha256']
    assert not any('gas-limit' in x for x in proof[label]['argv'])
assert proof['build']['exit_code']==0 and proof['test']['exit_code']==0
assert proof['network_denial_probe']['exit_code']!=0
prepared=json.loads((BASE/'actual-publication-preparation-v5/state.json').read_text())
module_hashes=sorted(hashlib.sha256(base64.b64decode(x)).hexdigest()
                     for x in prepared['pending']['artifact']['modules'])
assert module_hashes==sorted(pins['production_artifacts'].values())
checks=json.loads((C/'probe-results.json').read_text())
assert checks['checks_count']==len(checks['checks'])==53
for check in checks['checks']:
    assert sha(C/check['log'])==check['log_sha256']
assert checks['result']=='PASS' and checks['actual_source_mutations']==0
assert not (C/'approvals/actual.json').exists() and not (R/'.cas').exists()
OUT.mkdir(exist_ok=True)
cmd=['/Library/Developer/CommandLineTools/usr/bin/python3',str(C/'community_cutover.py'),
     'check','--expected-manifest-sha',EXPECTED]
run=subprocess.run(cmd,capture_output=True,timeout=30)
(OUT/'actual-baseline.log').write_bytes(run.stdout+run.stderr)
assert run.returncode==0, run.stderr.decode()
receipt={'status':'PASS_COORDINATOR_PREREQUISITES','frozen_manifest_sha256':EXPECTED,
         'frozen_files':446,'terminal_files':len(terminal['files']),'operations':194,
         'protected':30,'runtime_source_inputs':198,'original_tests':106,
         'exact_unsigned_publication_artifacts':True,'actual_baseline':json.loads(run.stdout),
         'recovery_logs_verified':53,'management_permissions_agent_release_rules_unchanged':True,
         'actual_source_activation':False,'independent_review':'pending','full_goal_complete':False}
(OUT/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
