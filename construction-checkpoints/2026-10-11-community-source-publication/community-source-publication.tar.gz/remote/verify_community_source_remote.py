"""Verify owning source from a fresh public clone and run its real product check."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess

ACT=Path('/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity')
BASE=ACT/'output/ecosystem-construction/repository-split-2026-10-10/maker-manufacturing-extraction'
OUT=Path(__file__).parent
LOCAL=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-community')
CLONE=OUT/'community-public-source-recovery-v2'
REMOTE='redefine-digital-labs/soul-community'

def run(args, cwd=LOCAL, timeout=50):
    return subprocess.check_output(args,cwd=cwd,timeout=timeout).decode().strip()

def api(path):
    return json.loads(run(['gh','api',path]))

commit=run(['git','rev-parse','HEAD'])
assert api('repos/'+REMOTE+'/git/ref/heads/main')['object']['sha']==commit
assert not api('repos/'+REMOTE)['private']
assert api('repos/'+REMOTE+'/actions/permissions')['enabled'] is False
assert not CLONE.exists(), 'Never replace a source recovery directory'
subprocess.run(['git','clone','--quiet','--single-branch','--branch','main',
                'https://github.com/'+REMOTE+'.git',str(CLONE)],check=True,timeout=60)
assert run(['git','rev-parse','HEAD'],CLONE)==commit
assert run(['git','ls-tree','-r','HEAD'],CLONE)==run(['git','ls-tree','-r','HEAD'])
tree=json.loads(run(['gh','api','repos/'+REMOTE+'/git/trees/'+commit+'?recursive=1']))
assert tree['truncated'] is False
remote={x['path']:(x['mode'],x['type'],x['sha']) for x in tree['tree'] if x['type']!='tree'}
local={}
for row in run(['git','ls-tree','-r','HEAD']).splitlines():
    meta,name=row.split('\t',1);local[name]=tuple(meta.split())
assert remote==local
pins=json.loads((CLONE/'source-candidate-pins.json').read_text())
assert len(pins['inputs'])==198
for relative,digest in pins['inputs'].items():
    path=CLONE/relative
    assert path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
files=json.loads((BASE/'community-source-actual-activation-v2/explicit-public-source-files.json').read_text())
assert len(files)==215
for relative,row in files.items():
    data=(CLONE/relative).read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
assert not (CLONE/'.cas').exists()
env=os.environ.copy()
env['SUI_BINARY']=str(ACT/'output/contract-rebuild/local-ptb-2026-10-08/tooling/sui')
result=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/python3','scripts/ci.py','--product'],
                      cwd=CLONE,env=env,capture_output=True,timeout=60)
(OUT/'community-public-source-recovery-v2.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0, 'Fresh owning product check failed; see saved log'
lines=[json.loads(x) for x in result.stdout.decode().splitlines()]
assert lines[-1]['maintenance_contract']=='passed' and lines[-1]['product_checks']=='passed'
inner=json.loads(lines[0]['stdout']);assert inner['result']=='PASS'
assert inner['summary']=={'result':'OK','total':106,'passed':106,'failed':0}
proof=json.loads((CLONE/inner['evidence']).read_text())
assert proof['packages']==['MoveStdlib','SoulidityCommunity','Sui'] and proof['project_dependencies']==[]
assert proof['production_artifacts']==pins['production_artifacts']
assert run(['git','status','--porcelain'],CLONE)==''
assert run(['git','diff','--name-only'])=='' and run(['git','diff','--cached','--name-only'])==''
untracked=run(['git','ls-files','--others','--exclude-standard']).splitlines()
assert untracked and all(x.startswith('.cas/') for x in untracked)
receipt={'status':'PASS_FRESH_PUBLIC_SOURCE_RECOVERY','commit':commit,'public':True,'actions_enabled':False,
         'complete_git_tree_equal':True,'remote_main_equal':True,'explicit_source_evidence_files':215,
         'all_runtime_source_inputs':198,'framework_inputs':187,'fresh_registered_product_check':'PASS',
         'original_tests':106,'exact_four_artifacts':True,'project_dependencies':[],
         'fresh_clone_clean':True,'local_tracked_clean':True,'expected_untracked_recovery_journal':'.cas/',
         'keys_or_databases_in_clone':False,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope':'Independent Community source activation/recovery; remote semantic CI and original UI/full157/30 remain unfinished'}
(OUT/'community-source-remote.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
