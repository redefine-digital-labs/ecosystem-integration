from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, subprocess, tarfile, urllib.request

REPO = Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/ecosystem-integration')
CHECKPOINT = 'construction-checkpoints/2026-10-11-native-community-construction'
REMOTE = 'redefine-digital-labs/ecosystem-integration'
OUT = Path(__file__).parent

def run(argv):
    return subprocess.check_output(argv, cwd=REPO, timeout=50).decode().strip()

def api(path):
    return json.loads(run(['gh', 'api', path]))

def public_file(commit, name):
    url = 'https://raw.githubusercontent.com/'+REMOTE+'/'+commit+'/'+CHECKPOINT+'/'+name
    with urllib.request.urlopen(url, timeout=30) as response:
        assert response.status == 200
        return response.read()

commit = run(['git', 'rev-parse', 'HEAD'])
assert api('repos/'+REMOTE+'/git/ref/heads/main')['object']['sha'] == commit
local = {}
for entry in run(['git', 'ls-tree', '-r', 'HEAD']).splitlines():
    metadata, name = entry.split('\t', 1)
    mode, kind, oid = metadata.split()
    local[name] = {'mode': mode, 'type': kind, 'sha': oid}
remote_tree = api('repos/'+REMOTE+'/git/trees/'+commit+'?recursive=1')
assert remote_tree['truncated'] is False
remote = {x['path']: {k: x[k] for k in ('mode', 'type', 'sha')}
          for x in remote_tree['tree'] if x['type'] != 'tree'}
assert remote == local
manifest_bytes = public_file(commit, 'archive-manifest.json')
assert manifest_bytes == (REPO/CHECKPOINT/'archive-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
data = public_file(commit, manifest['archive'])
assert hashlib.sha256(data).hexdigest() == manifest['archive_sha256']
assert data == (REPO/CHECKPOINT/manifest['archive']).read_bytes()
actual = {}
with tarfile.open(fileobj=io.BytesIO(data)) as tar:
    for member in tar.getmembers():
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert member.name not in actual
        content = tar.extractfile(member).read()
        assert len(content) == member.size
        actual[member.name] = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': member.size}
assert actual == manifest['members']
assert len(actual) == manifest['member_count']
public = not api('repos/'+REMOTE)['private']
assert public
actions = api('repos/'+REMOTE+'/actions/permissions')['enabled']
assert actions is False
assert run(['git', 'status', '--porcelain']) == ''
primary = Path('/Users/naoer/Documents/Claude/Projects/soulidity/docs/codex/CURRENT.md')
assert hashlib.sha256(primary.read_bytes()).hexdigest() == '2c9cf369d720f5d9319613acf020c2d236c79f3dcbf90057cddc148c39430512'
receipt = {'status': 'PASS_FRESH_PUBLIC_RECOVERY', 'commit': commit,
           'archive_sha256': manifest['archive_sha256'], 'archive_bytes': len(data),
           'member_count': len(actual), 'every_member_sha_and_length_equal': True,
           'complete_git_tree_equal': True, 'remote_main_equal': True,
           'local_clean': True, 'primary_current_unchanged': True,
           'public': public, 'actions_enabled': actions,
           'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scope': 'Source/evidence backup; Native and Community candidates unactivated, unsigned publication v5 unapproved; full157/30 remains active'}
(OUT/'native-community-remote.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
