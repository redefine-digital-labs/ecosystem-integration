from pathlib import Path
import hashlib,json,re,shutil,difflib
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda name,value:(R/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
baseline=json.loads((R/'baseline.json').read_text());up=Path(baseline['authority'])/'stage';current={str(p.relative_to(R/'stage')):sha(p) for p in sorted((R/'stage').rglob('*')) if p.is_file()}
original=baseline['inputs'];delta={k:[original.get(k),current.get(k)] for k in original.keys()|current.keys() if original.get(k)!=current.get(k)}
assert set(delta)=={'move/soulidity_foundation/sources/economics.move','move/soulidity_maker_manufacturing/sources/maker_catalog.move','move/soulidity_v1/tests/maker_validation_atomic_tests.move'}
write('source-deltas.json',delta)
patch=''
for k in sorted(delta):patch+=''.join(difflib.unified_diff((up/k).read_text().splitlines(True) if (up/k).exists() else [],(R/'stage'/k).read_text().splitlines(True),fromfile='canonical/'+k,tofile='candidate/'+k))
(R/'source.patch').write_text(patch)
write('manifest.json',{'algorithm':'sha256','input_count':len(current),'inputs':current,'authority_manifest_sha256':baseline['manifest_sha256'],'activation':False,'source_iterations':2})
tests={k:h for k,h in original.items() if '/tests/' in k};assert len(tests)==750
assert all(current[k]==h for k,h in tests.items())
previous=json.loads((R.parent/'maker-issuer-snapshot-runtime-v1/test-preservation.json').read_text());run=json.loads((R/'runs/009-core-original1062/result.json').read_text());core_ids=set(previous['core1062_identities_preserved']);assert len(core_ids)==1062 and core_ids<=run['identities'].keys() and all(run['identities'][k]=='PASS' for k in core_ids)
pack=set(previous['pack57_identities_preserved']);assert len(pack)==57 and all(run['identities'][k]=='PASS' for k in pack)
write('test-preservation.json',{'all_original_test_files_exact':len(tests),'core_original_files_exact':sum(k.startswith('move/soulidity_v1/tests/') for k in tests),'original_tests_sha256':tests,'original_core1062_identities_pass':sorted(core_ids),'original_pack57_identities_pass':sorted(pack),'additional_tests':sorted(set(run['identities'])-core_ids),'original_loops_and_assertions_byte_exact':True,'core_execution':'1071PASS/0FAIL = original1062+new9','default_budget':True})
def functions(s):
 result={}
 for m in re.finditer(r'(?m)^([^\n]*?\bfun\s+(\w+)\s*[^\n]*?)\{',s):
  start=m.end();depth=1;i=start
  while depth:
   if s[i]=='{':depth+=1
   elif s[i]=='}':depth-=1
   i+=1
  result[m.group(2)]={'signature':m.group(1).strip(),'body_sha256':hashlib.sha256(s[start:i-1].encode()).hexdigest()}
 return result
ledger={}
for k in ['move/soulidity_foundation/sources/economics.move','move/soulidity_maker_manufacturing/sources/maker_catalog.move']:
 a=(up/k).read_text();b=(R/'stage'/k).read_text();fa=functions(a);fb=functions(b)
 assert set(fa)<=set(fb);assert all(fa[n]['signature']==fb[n]['signature'] for n in fa)
 layouts=lambda s:re.findall(r'public struct\s+\w+[^\{]*\{[^}]*\}',s)
 assert layouts(a)==layouts(b)
 ledger[k]={'all_existing_signatures_exact':True,'all_existing_struct_layouts_exact':True,'existing_struct_count':len(layouts(a)),'added_functions':{n:fb[n] for n in set(fb)-set(fa)},'changed_bodies':{n:{'before':fa[n],'after':fb[n]} for n in fa if fa[n]['body_sha256']!=fb[n]['body_sha256']},'existing_functions':len(fa)}
assert list(ledger['move/soulidity_maker_manufacturing/sources/maker_catalog.move']['changed_bodies'])==['begin_session_value']
assert not ledger['move/soulidity_foundation/sources/economics.move']['changed_bodies']
ledger['api_ledger']={'additive_public':['economics::quote_collect_primary','economics::quote_collect_manufacturing_primary'],'compatibility':'Unpublished target additive ABI; existing signatures and layouts exact. Not claimed old on-chain compatible. Old dependency packages require coherent rebuild/relink before activation.','actual_consumer':'maker_catalog::begin_session_value native_route true/false, reached by maker_factory::begin_native/begin_native_pack/begin/begin_pack and original test-only start wrappers. Returns actual receipt+net Coin; immediately deposits net into Product income.','non_session_callers':'Unchanged: access purchase, physical settlement and public quote/collect entry guards. Existing issuer/admission/factory sources byte exact.','pack_proof':'Private begin_pack_session_value only true callsite. Exact current writer role/Config snapshot check precedes immutable runtime pack reads. No Config mutation before continuation. Public non-Pack starts still call assert_current_writer.'}
write('abi-body-layout-map.json',ledger)
raw=lambda label:(R/'runs'/label/'raw.log').read_text()
gas=lambda label,name:int(re.search(r'\|'+re.escape(name)+r'\s*\|\s*[0-9.]+\s*\|\s*(\d+)',raw(label))) if False else next(int(re.findall(r'\d+',line)[-1]) for line in raw(label).splitlines() if '│ soulidity_v1::pack_soul_tests::'+name+' ' in line)
n='fresh_free_purchase_uses_exact_published_supply_and_returns_every_old_id';bound=50_000_000_000_000;capacity=5_000_000
cost={'formula':'reported = bound_MIST - remaining_raw_Gas; consumed_raw = capacity_raw - (bound_MIST-reported). Fixed statistic offset = bound_MIST-capacity_raw.','bound_MIST':bound,'test_gas_price_MIST':500,'computation_capacity_raw':capacity,'statistics_fixed_offset':bound-capacity,'cost_kind':'VM raw computation units; not actual chain GasCostSummary/MIST/SUI or acceptance','sources':{'cli':'https://raw.githubusercontent.com/MystenLabs/sui/671ba71e69c7/crates/sui-move/src/unit_test.rs','meter_v3':'https://raw.githubusercontent.com/MystenLabs/sui/671ba71e69c7/crates/sui-types/src/gas_model/gas_v3.rs','tables':'https://raw.githubusercontent.com/MystenLabs/sui/671ba71e69c7/crates/sui-types/src/gas_model/tables.rs','protocol':'https://raw.githubusercontent.com/MystenLabs/sui/671ba71e69c7/crates/sui-protocol-config/src/lib.rs'},'canonical':{'reported':49999999720785,'consumed_raw':4720785,'remaining_raw':279215,'negative11':'OOG/expected supply abort6 missing','iteration':'UNKNOWN'}}
for label in ['001-pack-private-writer','002-atomic-quote-collect']:
 reported=gas(label,n);cost[label]={'reported':reported,'consumed_raw':capacity-(bound-reported),'remaining_raw':bound-reported,'savings_vs_canonical_raw':49999999720785-reported,'result':json.loads((R/'runs'/label/'result.json').read_text())['summaries']}
write('costs.json',cost)
shutil.copytree(R/'stage',R/'frozen/inputs');shutil.copy2(R/'manifest.json',R/'frozen/manifest.json')
assert {str(p.relative_to(R/'frozen/inputs')):sha(p) for p in sorted((R/'frozen/inputs').rglob('*')) if p.is_file()}==current
for p in (R/'frozen').rglob('*'):
 if p.is_file():p.chmod(0o444)
write('final-evidence.json',{'manifest_sha256':sha(R/'manifest.json'),'frozen_manifest_sha256':sha(R/'frozen/manifest.json'),'frozen_inputs':len(current),'source_deltas':delta,'gates':{label:{k:json.loads((R/'runs'/label/'result.json').read_text())[k] for k in ['exit_code','summaries','raw_log_sha256','source_drift']} for label in ['002-atomic-quote-collect','004-maker49','008-focused-resources','006-core-production','007-market-production','009-core-original1062']},'guards':'Current197 exact; historical180 non-Python match, historical Python drift recorded separately/current Python exact. Canonical1680 preserved.','installed':False,'full_goal_complete':False})
print(json.dumps({'manifest_sha256':sha(R/'manifest.json'),'inputs':len(current),'original_tests':len(tests),'original_core_pass':len(core_ids),'changed_sources':list(delta),'abi_sha256':sha(R/'abi-body-layout-map.json')}))
