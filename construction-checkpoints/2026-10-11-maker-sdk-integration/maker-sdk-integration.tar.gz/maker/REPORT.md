# Maker cross-module validation result

**Scoped VM/build acceptance PASS; unactivated, independent review pending.** Original Pack57 passes57/57 at the unchanged default pinned CLI budget. Independent Maker49 passes49/49. Full Core1071 passes1071/1071: every original1062 identity plus9 additive controls. This does not close the full original product goal or prove real publication/old-chain authority.

Frozen source manifest: `ae46753969065c00edc443888eef11fb82a8333ab44eb68adc599baee1d85a39`,1681 inputs = canonical1680 plus one additive test file. Canonical authority remains historical-market-authority-fixture-v1 `cfc272524583a33daeb3b6cf894d64cdc80eccd694b9036a303838ee9a98ad4e`. The rejected issuer microcandidate is comparison evidence only; no issuer change was adopted.

## Concrete change and API consumption

Only two production source files change. `maker_catalog::begin_session_value` privately reuses the current Creator role check made by `begin_pack_session_value` immediately before its immutable Pack runtime checks. `pack_proof` is private and only that operation passes true. Config, role state and its commitment do not mutate between the original exact role/Config snapshot check and this continuation. All non-Pack session starts retain their independent writer check; all later live, expiry, source, adapter, access, quota and supply checks remain.

Foundation adds two public operations, `economics::quote_collect_primary` and `economics::quote_collect_manufacturing_primary`. Each accepts the actual mutable Config, private role witness/revision values, frozen published PrimaryPolicy, exact quote fields, actual Coin, Clock and TxContext. Each performs a fresh full Primary guard, builds the same receipt through the original private quote calculation, validates the current role, checks expiry and collects the exact Coin through the original private settlement. The returned net Coin is immediately deposited into the actual Product income by `maker_catalog::begin_session_value`; the receipt remains the actual Session receipt. No validation token, cross-transaction cache or prevalidated object is returned.

The same Config stays unchanged within the helper until actual income collection. Original native collection's pinned-role/type checks and manufacturing collection's type checks execute after quote validation, preserving original quote errors before role errors. The redundant catalog route checks were already established by the exact source/protocol checks earlier in the same begin operation; intervening `authorize_complete` mutates attempts/counts only. The newly generated receipt is routed to `object::id(p)`, preventing caller-supplied Product routing in the actual consumer.

Actual production callers are `maker_factory::begin`, `begin_pack`, `begin_native` and `begin_native_pack` through the existing Catalog session wrappers. This includes independent non-Soul manufacturing and Native Maker/Pack issuance/enhancement. Other access/physical/public quote and public collection paths are unchanged and retain their independent guards. Issuer, admission, factory, origin, publication, rights, receipt/income types and settlement implementation are byte-exact sources.

ABI ledger `abi-body-layout-map.json` binds164 existing economics signatures/32 public struct layouts and209 existing Catalog signatures/30 public struct layouts. All remain exact. Economics adds the two signatures; Catalog changes only private `begin_session_value` body. Existing public entry/body guards remain intact. These are additive APIs for an unpublished target, not a declaration of old published compatibility. Consumption requires rebuilding the exact Foundation→MakerManufacturing dependency closure and dependent roots coherently; activation/publication/linkage and actual old callable rejection remain separate coordinator work.

## Verification and limits

| Gate | Result | Evidence |
| --- | --- | --- |
| Unmodified original Pack57 |57/57 PASS|runs/002-atomic-quote-collect/result.json|
| Independent original Maker49 |49/49 PASS|runs/004-maker49/result.json|
| Additive focused controls |9/9 PASS|runs/008-focused-resources/result.json|
| Full Core |1071/1071 PASS, original1062 exact|runs/009-core-original1062/result.json|
| Production Core |196 modules PASS|runs/006-core-production/result.json|
| Production Market |175 modules PASS|runs/007-market-production/result.json|

All750 original selected test files, Core60 files and original positive10/negative11 loops/assertions stay byte exact. `test-preservation.json` independently maps every original1062 identity to PASS, and every original57 Pack identity to PASS. The supply rejection now reaches its expected MakerCatalog abort6 without moving the rejection earlier. No test-only fast path, budget override, original helper edit or supply shortcut was introduced.

Focused controls exercise the actual new Native API against foreign role witnesses; paired old/new quote-error versus role-error precedence; stale global package before quote/role errors; manufacturing API missing release identity; actual issuer session underpayment and overpayment; expiry before underpayment; stale revision before expiry and funding. Maker49 separately tests funded-session changed Config/expiry rejection, replay, wrong execution revision/target, native/manufacturing separation, real paid revenue and physical supply. Full Core covers quota/cap, source revision, original fees/receipts, all rights modes, original supply10 exhaustion and late protected failures.

Abort tests establish the expected VM diagnostic. They do not independently read back real-chain rollback after failure; Sui transaction atomicity is not a substitute for chain receipt/fund readback. Real old callable package paths, linkage, effective upgrade authority, actual receipts/rollback and release authorization remain unverified here and belong to the coordinator's separate chain gate.

Production Core196 and Market175 each change only `economics.mv` and `maker_catalog.mv`. All remaining194/173 module bytes, including Core issuer, match the canonical baseline. The exact per-module maps and hashes are in `production-byte-comparison.json`.

Two production body/API iterations were used. Iteration1 saved151,739 raw computation units and advanced failure from Config BCS to the actual supply lookup, but remained56/57. Iteration2 saved another108,825 and passed57/57. Two additive test-fixture compiler corrections fixed lexical spacing/resource cleanup only; initial failed logs are retained, not counted as business rejections. No further production source changes followed the passing gate.

## Actual cost semantics

The CLI statistics are not consumed MIST/SUI. Pinned CLI `unit_test.rs::used_gas` subtracts remaining raw Gas units from the MIST execution bound. The test meter uses gas price500 and caps computation at `max_gas_computation_bucket *500`; `GasStatus::new` divides that budget by500. The effective raw computation capacity is5,000,000. Therefore `consumed_raw =5,000,000 -(50,000,000,000,000 -reported)`. The fixed statistic offset is49,999,995,000,000. Formula and pinned primary-source URLs are in `costs.json`.

| Same graph | Reported statistic | Actual raw consumed | Raw remaining |
| --- | ---:| ---:| ---:|
| Canonical positive10 |49,999,999,720,785|4,720,785|279,215|
| Private Pack continuation |49,999,999,569,046|4,569,046|430,954|
| Selected atomic quote/collect |49,999,999,460,221|4,460,221|539,779|

Selected savings are260,564 raw computation units against the exact canonical graph. This is neither actual chain gas cost nor publication acceptance. The exact historical negative failure iteration remains UNKNOWN; the function-only tracer panicked before the original test outcome and is not business evidence.

All runs used Sui1.80.1-671ba71e69c7 SHA `1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3`, fixed read-only dependencies, denied network and writes isolated to run outputs/cache. Compiler protocol137 fallback is compiler context only. Current197 installed/runtime guards and canonical1680 guards stayed exact. Historical181 classification remains154 Move+24 config/lock+Sui+primary CURRENT+Python;180 historical non-Python pins match, historical Python drift is retained separately and current Python is pinned exactly. No misleading181-source or181-historical-PASS claim.

Rollback is to ignore the uninstalled candidate and use canonical cfc272 stage. Installed sources, frozen predecessors, primary CURRENT, remotes and chain were untouched. Continue independent review of frozen1681 and real-chain/source activation only under the coordinator's existing authorization. Full goal remains ACTIVE.
