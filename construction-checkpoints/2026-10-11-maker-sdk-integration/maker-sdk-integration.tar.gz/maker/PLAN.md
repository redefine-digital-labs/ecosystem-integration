# Plan

1. Map exact issuer/catalog/economics/admission/settlement paths and CLI cost semantics.
2. Private Pack-session continuation eliminating provably redundant writer integrity only.
3. If needed, concrete quote-and-Coin-settlement helper with fresh authority validation and public API ledger.
4. Freeze selected candidate and complete original tests/source preservation, affected tests, production byte mapping and durable handoff.
