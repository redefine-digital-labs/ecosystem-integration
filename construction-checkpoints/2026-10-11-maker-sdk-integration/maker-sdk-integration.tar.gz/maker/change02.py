from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'stage/move/soulidity_foundation/sources/economics.move';s=p.read_text()
anchor='public fun primary_receipt_policy(r:&PrimaryReceipt):PrimaryPolicy{r.policy}'
new='''/// Concrete atomic quote and Coin collection. The quote and role/receipt checks
/// share this unchanged Config before collect_primary_value mutates income.
/// No authority token or partially validated quote escapes this invocation.
public fun quote_collect_primary<C,W:drop,R:drop>(c:&mut Config<C>,_w:W,_r:R,p:&PrimaryPolicy,gross:u64,fixed:bool,beneficiary:address,subject:ID,commitment:vector<u8>,actor:address,attempt:vector<u8>,expiry:u64,product:ID,payment:Coin<C>,clock:&Clock,ctx:&mut TxContext):(PrimaryReceipt,Coin<C>){
    assert_primary(c);
    let receipt=route_primary(primary_quote_value(p,c,gross,fixed,beneficiary,subject,commitment,actor,attempt,expiry),product);
    // Original collect_primary's assert_business continuation, after the same
    // full Primary guard and before any Config mutation. Preserve quote errors first.
    assert!(package_roles::pinned(&package_roles::role(&c.roles,2)),EPolicy);package_roles::assert_types<W,R>(&c.roles,2);
    assert_live_fields(c,receipt.operational_revision,receipt.expiry,clock);
    let net=collect_primary_value(c,receipt,payment,ctx);(receipt,net)
}
public fun quote_collect_manufacturing_primary<C,W:drop,R:drop>(c:&mut Config<C>,_w:W,_r:R,p:&PrimaryPolicy,gross:u64,fixed:bool,beneficiary:address,subject:ID,commitment:vector<u8>,actor:address,attempt:vector<u8>,expiry:u64,product:ID,payment:Coin<C>,clock:&Clock,ctx:&mut TxContext):(PrimaryReceipt,Coin<C>){
    assert_manufacturing_primary(c);
    let receipt=route_primary(primary_quote_value(p,c,gross,fixed,beneficiary,subject,commitment,actor,attempt,expiry),product);
    package_roles::assert_types<W,R>(&c.roles,2);
    assert_live_fields(c,receipt.operational_revision,receipt.expiry,clock);
    let net=collect_primary_value(c,receipt,payment,ctx);(receipt,net)
}
'''
assert s.count(anchor)==1;s=s.replace(anchor,new+anchor);p.write_text(s)
p=r/'stage/move/soulidity_maker_manufacturing/sources/maker_catalog.move';s=p.read_text()
old=''' let version=published(p,v);let receipt=economics::route_primary(if(native_route)economics::primary_quote(&version.primary.destroy_some(),cfg,price,fixed,version.beneficiary,object::id(target),hash,ctx.sender(),origin::attempt(&snapshot),origin::expiry(&snapshot)) else economics::manufacturing_primary_quote(&version.primary.destroy_some(),cfg,price,fixed,version.beneficiary,object::id(target),hash,ctx.sender(),origin::attempt(&snapshot),origin::expiry(&snapshot)),object::id(p));
 collect_primary_value(p,cfg,receipt,payment,clock,ctx,native_route);let completion'''
new=''' // Source/Config equality was checked above; authorize_complete changes only
 // attempts/counts. Route this actual Product and immediately deposit its net Coin.
 let version=published(p,v);let(receipt,net)=if(native_route)economics::quote_collect_primary<C,CreatorAuthority1,CreatorRevision3>(cfg,CreatorAuthority1{},CreatorRevision3{},&version.primary.destroy_some(),price,fixed,version.beneficiary,object::id(target),hash,ctx.sender(),origin::attempt(&snapshot),origin::expiry(&snapshot),object::id(p),payment,clock,ctx) else economics::quote_collect_manufacturing_primary<C,CreatorAuthority1,CreatorRevision3>(cfg,CreatorAuthority1{},CreatorRevision3{},&version.primary.destroy_some(),price,fixed,version.beneficiary,object::id(target),hash,ctx.sender(),origin::attempt(&snapshot),origin::expiry(&snapshot),object::id(p),payment,clock,ctx);
 revenue::deposit(&p.id,&mut p.income,net);let completion'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
(r/'attempt-sources/02').mkdir()
for p in [r/'stage/move/soulidity_foundation/sources/economics.move',r/'stage/move/soulidity_maker_manufacturing/sources/maker_catalog.move']:(r/'attempt-sources/02'/p.name).write_bytes(p.read_bytes())
