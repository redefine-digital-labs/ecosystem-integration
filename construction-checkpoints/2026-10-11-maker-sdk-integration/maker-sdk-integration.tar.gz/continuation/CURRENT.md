# Soulidity Current Phase

- Status: in-progress; full original157 responsibilities/30 duties contract and user-journey goal ACTIVE.
- Worktree: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity`; branch `codex/soul-dof-v1-contracts`; base `0cfb60a29b2b378dd9fbf31970b324b2ef2e301e`.
- Stable memory: `docs/codex/PROJECT_MEMORY.md`.
- Latest handoff: `docs/codex/handoffs/20261011-maker-sdk-actual-integration.md`.
- Maker candidate ae467539/1681: originalPack57/57, Maker49/49, focused9/9, Core1071/1071 PASS. Original750 testfiles retained; only economics+maker_catalog production bytes differ. Independent scoped review fde61078 PASS. Maker source activation and chain proof remain pending.
- Pure SDK utility code active in owning soul-sdk repository. Actual287 tests, fresh build/public11 exports and disposable restore/reapply pass independent actual review57c7b7ae. Original277 identities, ten sources/links and SDK105 unchanged. npm/independent release and business SDK activation remain pending.
- Market64/64 plus3 proofs pass; historical canonical production175/196 exact. Offline19 roots/74 own modules pass on prior1680 sources with synthetic dependency metadata only.
- Retained isolated chain ae60751d/protocol137 verified; public package/cap custody including embedded Walrus UpgradeCap readback PASS. No new19 package publication/linkage/signature yet. Revalidate live process/RPC before use.
- Next: verified public backup of current increment; actual-publication-preparation-v1 guarded19-root candidate and independent review, then authorized isolated publication/linkage and coherent source activation.
- Remaining: Gate0 D26/effective authority/oldcallable rejection, Channel, source/type-origin migration, original UI/recovery/full157/30, independent releases and actual CI/forms/agents. Vault deferred; original Owners/roadmap unchanged.
- Constraints: no production/real wallets/funds/PR/AgentPass/irreversible authority or DB deletion. Retained isolated Genesis/virtualgas authorized. Public backup commits/pushes and English active materials authorized.
- Primary CURRENT SHA remains2c9cf369d720f5d9319613acf020c2d236c79f3dcbf90057cddc148c39430512. Historical180 non-Python guards preserved; external Python/Node hash drift recorded separately. Frozen historical receipts are not rebased.
- Previous verified public Integration checkpoint fbd2b5657d477a467928e180ba442895a20ece68/4045 members; newest increment backup pending verification. SDK new source commit6877c47 pushed, fresh public verification running.

Read only the linked handoff. Helper generated it without updating CURRENT; Root updated this actual pointer, primary untouched. Repository/channel counts are not independent release/product acceptance.
