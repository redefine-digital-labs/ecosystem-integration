// Copyright (c) Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

module sui::display_registry;

use std::string::String;
use sui::derived_object;
use sui::display::Display as LegacyDisplay;
use sui::package::Publisher;
use sui::vec_map::{Self, VecMap};

/// This is a multi-sig address responsible for the migration of V1 displays into V2.
const SYSTEM_MIGRATION_ADDRESS: address =
    @0x80e8249451c1a94b0d4ec317d9dd040f11344dcce6f917218086caf2bb1d7bdd;

#[error(code = 0)]
const ENotSystemAddress: vector<u8> = b"This is only callable from system address.";
#[error(code = 1)]
const EDisplayAlreadyExists: vector<u8> = b"Display for the supplied type already exists.";
#[error(code = 2)]
const ECapAlreadyClaimed: vector<u8> = b"Cap for this display object has already been claimed.";
#[error(code = 3)]
const ENotValidPublisher: vector<u8> = b"The publisher is not valid for the supplied type.";
#[error(code = 4)]
const EFieldDoesNotExist: vector<u8> = b"Field does not exist in the display.";
#[error(code = 5)]
const ECapNotClaimed: vector<u8> =
    b"Cap for this display object has not been claimed so you cannot delete the legacy display yet.";

/// The root of display, to enable derivation of addresses.
/// The address is system-generated at `0xd`
public struct DisplayRegistry has key { id: UID }

/// A singleton capability object to enable migrating all V1 displays into V2.
public struct SystemMigrationCap has key { id: UID }

/// This is the struct that holds the display values for a type T.
public struct Display<phantom T> has key {
    id: UID,
    /// All the (key,value) entries for a given display object.
    fields: VecMap<String, String>,
    /// The capability object ID. It's `Option` because legacy Displays will need claiming.
    cap_id: Option<ID>,
}

/// The capability object that is used to manage the display.
public struct DisplayCap<phantom T> has key, store { id: UID }

/// The key used for deriving the instance of `Display`.
public struct DisplayKey<phantom T>() has copy, drop, store;

/// Create a new Display object for a given type `T` using `internal::Permit` to
/// prove type ownership.
public fun new<T>(
    registry: &mut DisplayRegistry,
    _: internal::Permit<T>,
    ctx: &mut TxContext,
): (Display<T>, DisplayCap<T>) {
    let (display, cap) = new_display<T>(registry, ctx);
    (display, cap)
}

/// Create a new display object using the `Publisher` object.
public fun new_with_publisher<T>(
    registry: &mut DisplayRegistry,
    publisher: &mut Publisher,
    ctx: &mut TxContext,
): (Display<T>, DisplayCap<T>) {
    assert!(publisher.from_package<T>(), ENotValidPublisher);
    let (display, cap) = new_display<T>(registry, ctx);
    (display, cap)
}

/// Unset a key from display.
public fun unset<T>(display: &mut Display<T>, _: &DisplayCap<T>, name: String) {
    assert!(display.fields.contains(&name), EFieldDoesNotExist);
    display.fields.remove(&name);
}

/// Set a value for the specified key, replaces existing value if it exists.
public fun set<T>(display: &mut Display<T>, _: &DisplayCap<T>, name: String, value: String) {
    if (display.fields.contains(&name)) {
        display.fields.remove(&name);
    };
    display.fields.insert(name, value);
}

/// Clear the display vec_map, allowing a fresh re-creation of fields
public fun clear<T>(display: &mut Display<T>, _: &DisplayCap<T>) {
    display.fields = vec_map::empty();
}

/// Share the `Display` object to finalize the creation.
public fun share<T>(display: Display<T>) {
    transfer::share_object(display)
}

/// Allow a legacy Display holder to claim the capability object.
public fun claim<T: key>(
    display: &mut Display<T>,
    legacy: LegacyDisplay<T>,
    ctx: &mut TxContext,
): DisplayCap<T> {
    assert!(display.cap_id.is_none(), ECapAlreadyClaimed);
    let cap = DisplayCap<T> { id: object::new(ctx) };
    display.cap_id.fill(cap.id.to_inner());
    legacy.destroy();
    cap
}

/// Allow claiming a new display using `Publisher` as proof of ownership.
public fun claim_with_publisher<T: key>(
    display: &mut Display<T>,
    publisher: &mut Publisher,
    ctx: &mut TxContext,
): DisplayCap<T> {
    assert!(display.cap_id.is_none(), ECapAlreadyClaimed);
    assert!(publisher.from_package<T>(), ENotValidPublisher);
    let cap = DisplayCap<T> { id: object::new(ctx) };
    display.cap_id.fill(cap.id.to_inner());
    cap
}

/// Allow the `SystemMigrationCap` holder to create display objects with supplied
/// values. The migration is performed once on launch of the DisplayRegistry,
/// further migrations will have to be performed for each object, and will only
/// be possible until legacy `display` methods are finally deprecated.
public fun system_migration<T: key>(
    registry: &mut DisplayRegistry,
    _: &SystemMigrationCap,
    keys: vector<String>,
    values: vector<String>,
    _ctx: &mut TxContext,
) {
    let key = DisplayKey<T>();

    // Gracefully return to avoid batching issues if someone migrates before our script.
    if (derived_object::exists(&registry.id, key)) return;

    transfer::share_object(Display<T> {
        id: derived_object::claim(&mut registry.id, key),
        fields: vec_map::from_keys_values(keys, values),
        cap_id: option::none(),
    });
}

/// Enables migrating legacy display into the new one,
/// if a new one has not yet been created.
public fun migrate_v1_to_v2<T: key>(
    registry: &mut DisplayRegistry,
    legacy: LegacyDisplay<T>,
    ctx: &mut TxContext,
): (Display<T>, DisplayCap<T>) {
    let (mut display, cap) = new_display<T>(registry, ctx);
    display.fields = *legacy.fields();
    legacy.destroy();

    (display, cap)
}

/// Destroy the `SystemMigrationCap` after successfully migrating all V1 instances.
entry fun destroy_system_migration_cap(cap: SystemMigrationCap) {
    let SystemMigrationCap { id } = cap;
    id.delete();
}

entry fun transfer_migration_cap(cap: SystemMigrationCap, recipient: address) {
    transfer::transfer(cap, recipient);
}

/// Allow deleting legacy display objects, as long as the cap has been claimed first.
public fun delete_legacy<T: key>(display: &Display<T>, legacy: LegacyDisplay<T>) {
    assert!(display.cap_id.is_some(), ECapNotClaimed);
    legacy.destroy();
}

/// Get a reference to the fields of display.
public fun fields<T>(display: &Display<T>): &VecMap<String, String> {
    &display.fields
}

/// Get the cap ID for the display.
public fun cap_id<T>(display: &Display<T>): Option<ID> {
    display.cap_id
}

public(package) fun migration_cap_receiver(): address {
    SYSTEM_MIGRATION_ADDRESS
}

fun new_display<T>(
    registry: &mut DisplayRegistry,
    ctx: &mut TxContext,
): (Display<T>, DisplayCap<T>) {
    let key = DisplayKey<T>();
    assert!(!derived_object::exists(&registry.id, key), EDisplayAlreadyExists);
    let cap = DisplayCap<T> { id: object::new(ctx) };
    let display = Display<T> {
        id: derived_object::claim(&mut registry.id, key),
        fields: vec_map::empty(),
        cap_id: option::some(cap.id.to_inner()),
    };
    (display, cap)
}

#[allow(unused_function)]
/// Create a new display registry object callable only from 0x0 (end of epoch)
fun create(ctx: &mut TxContext) {
    assert!(ctx.sender() == @0x0, ENotSystemAddress);

    transfer::share_object(DisplayRegistry {
        id: object::sui_display_registry_object_id(),
    });

    transfer::transfer(
        SystemMigrationCap { id: object::new(ctx) },
        SYSTEM_MIGRATION_ADDRESS,
    );
}

#[test_only]
public(package) fun create_for_testing(ctx: &mut TxContext) {
    create(ctx);
}
