// Copyright (c) Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

#[defines_primitive(u32)]
module std::u32;

use std::string::String;

/// Returns the bitwise not of the value.
/// Each bit that is 1 becomes 0. Each bit that is 0 becomes 1.
public fun bitwise_not(x: u32): u32 {
    x ^ max_value!()
}

/// Return the larger of `x` and `y`
public fun max(x: u32, y: u32): u32 {
    std::macros::num_max!(x, y)
}

/// Return the smaller of `x` and `y`
public fun min(x: u32, y: u32): u32 {
    std::macros::num_min!(x, y)
}

/// Return the absolute value of x - y
public fun diff(x: u32, y: u32): u32 {
    std::macros::num_diff!(x, y)
}

/// Calculate `x * y / z`, upcasting intermediate values to avoid overflow when possible.
/// Aborts if `z` is `0`.
/// Aborts if the result is larger than `MAX`.
public fun mul_div(x: u32, y: u32, z: u32): u32 {
    std::macros::num_mul_div!<_, u64>(x, y, z)
}

/// Calculate `x * y / z`, upcasting intermediate values to avoid overflow when possible.
/// Rounds up the result if there is a remainder.
/// Aborts if `z` is `0`.
/// Aborts if the result is larger than `MAX`.
public fun mul_div_ceil(x: u32, y: u32, z: u32): u32 {
    std::macros::num_mul_div_ceil!<_, u64>(x, y, z)
}

/// Calculate x / y, but round up the result.
public fun div_ceil(x: u32, y: u32): u32 {
    std::macros::num_div_ceil!(x, y)
}

/// Return the value of a base raised to a power
public fun pow(base: u32, exponent: u8): u32 {
    std::macros::num_pow!(base, exponent)
}

/// Get a nearest lower integer Square Root for `x`. Given that this
/// function can only operate with integers, it is impossible
/// to get perfect (or precise) integer square root for some numbers.
///
/// Example:
/// ```
/// math::sqrt(9) => 3
/// math::sqrt(8) => 2 // the nearest lower square root is 4;
/// ```
///
/// In integer math, one of the possible ways to get results with more
/// precision is to use higher values or temporarily multiply the
/// value by some bigger number. Ideally if this is a square of 10 or 100.
///
/// Example:
/// ```
/// math::sqrt(8) => 2;
/// math::sqrt(8 * 10000) => 282;
/// // now we can use this value as if it was 2.82;
/// // but to get the actual result, this value needs
/// // to be divided by 100 (because sqrt(10000)).
///
///
/// math::sqrt(8 * 1000000) => 2828; // same as above, 2828 / 1000 (2.828)
/// ```
public fun sqrt(x: u32): u32 {
    std::macros::num_sqrt!<u32, u64>(x, 32)
}

/// Try to convert a `u32` to a `u8`. Returns `None` if the value is too large.
public fun try_as_u8(x: u32): Option<u8> {
    std::macros::try_as_u8!(x)
}

/// Try to convert a `u32` to a `u16`. Returns `None` if the value is too large.
public fun try_as_u16(x: u32): Option<u16> {
    std::macros::try_as_u16!(x)
}

public fun to_string(x: u32): String {
    std::macros::num_to_string!(x)
}

/// Try to add `x` and `y`.
/// Returns `None` if the addition would overflow.
public fun checked_add(x: u32, y: u32): Option<u32> {
    std::macros::num_checked_add!(x, y, max_value!())
}

/// Try to subtract `y` from `x`.
/// Returns `None` if `y > x`.
public fun checked_sub(x: u32, y: u32): Option<u32> {
    std::macros::num_checked_sub!(x, y)
}

/// Try to multiply `x` and `y`.
/// Returns `None` if the multiplication would overflow.
public fun checked_mul(x: u32, y: u32): Option<u32> {
    std::macros::num_checked_mul!(x, y, max_value!())
}

/// Try to divide `x` by `y`.
/// Returns `None` if `y` is zero.
public fun checked_div(x: u32, y: u32): Option<u32> {
    std::macros::num_checked_div!(x, y)
}

/// Add `x` and `y`, saturating at the maximum value instead of overflowing.
public fun saturating_add(x: u32, y: u32): u32 {
    std::macros::num_saturating_add!(x, y, max_value!())
}

/// Subtract `y` from `x`, saturating at `0` instead of underflowing.
public fun saturating_sub(x: u32, y: u32): u32 {
    std::macros::num_saturating_sub!(x, y)
}

/// Multiply `x` and `y`, saturating at the maximum value instead of overflowing.
public fun saturating_mul(x: u32, y: u32): u32 {
    std::macros::num_saturating_mul!(x, y, max_value!())
}

/// Shifts `x` left by `shift` bits.
/// Returns `None` if the shift is greater than or equal to the bit size of 32.
public fun checked_shl(x: u32, shift: u8): Option<u32> {
    std::macros::num_checked_shl!(x, shift, 32)
}

/// Shifts `x` right by `shift` bits.
/// Returns `None` if the shift is greater than or equal to the bit size of 32.
public fun checked_shr(x: u32, shift: u8): Option<u32> {
    std::macros::num_checked_shr!(x, shift, 32)
}

/// Shifts `x` left by `shift` bits.
/// Returns `None` if the shift is larger than or equal to the bit size of 32, or if the shift would
/// lose any bits (if the operation is not reversible).
public fun lossless_shl(x: u32, shift: u8): Option<u32> {
    std::macros::num_lossless_shl!(x, shift, 32)
}

/// Shifts `x` right by `shift` bits.
/// Returns `None` if the shift is larger than or equal to the bit size of 32, or if the shift would
/// lose any bits (if the operation is not reversible).
public fun lossless_shr(x: u32, shift: u8): Option<u32> {
    std::macros::num_lossless_shr!(x, shift, 32)
}

/// Divides `x` by `y`.
/// Returns `None` if `y` is zero or if there is a non-zero remainder (if `x % y != 0`). In other
/// words, it returns `None` if the operation is not reversible.
public fun lossless_div(x: u32, y: u32): Option<u32> {
    std::macros::num_lossless_div!(x, y)
}

/// Maximum value for a `u32`
public macro fun max_value(): u32 {
    0xFFFF_FFFF
}

/// Loops applying `$f` to each number from `$start` to `$stop` (exclusive)
public macro fun range_do<$R: drop>($start: u32, $stop: u32, $f: |u32| -> $R) {
    std::macros::range_do!($start, $stop, $f)
}

/// Loops applying `$f` to each number from `$start` to `$stop` (inclusive)
public macro fun range_do_eq<$R: drop>($start: u32, $stop: u32, $f: |u32| -> $R) {
    std::macros::range_do_eq!($start, $stop, $f)
}

/// Loops applying `$f` to each number from `0` to `$stop` (exclusive)
public macro fun do<$R: drop>($stop: u32, $f: |u32| -> $R) {
    std::macros::do!($stop, $f)
}

/// Loops applying `$f` to each number from `0` to `$stop` (inclusive)
public macro fun do_eq<$R: drop>($stop: u32, $f: |u32| -> $R) {
    std::macros::do_eq!($stop, $f)
}

// === Deprecated ===

#[deprecated(note = b"Renamed to `div_ceil` for consistency")]
public fun divide_and_round_up(x: u32, y: u32): u32 {
    x.div_ceil(y)
}
