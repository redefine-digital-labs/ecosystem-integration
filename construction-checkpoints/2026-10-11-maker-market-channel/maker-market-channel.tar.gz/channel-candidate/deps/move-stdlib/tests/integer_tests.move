// Copyright (c) Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

// helpers for integer tests
#[test_only]
module std::integer_tests;

use std::unit_test::assert_eq;

/// Calls `$f` for all N³ permutations of cases.
public(package) macro fun exhaustive_cases($cases: vector<_>, $f: |_, _, _|) {
    let cases = $cases;
    let len = cases.length();
    len.do!(|i| {
        len.do!(|j| {
            len.do!(|k| {
                $f(cases[i], cases[j], cases[k]);
            });
        });
    });
}

/// Iterate over cases and apply `$f(a, b, c)`.
public(package) macro fun cases($max: _, $cases: vector<_>, $f: |_, _, _|) {
    let cases = $cases;
    let max_pred = $max - 1;
    cases.destroy!(|case| {
        let case_pred = case.max(1) - 1;
        let case_succ = case.min(max_pred) + 1;
        $f(case_pred, case, case_succ);
    });
}

public(package) macro fun test_bitwise_not($max: _, $cases: vector<_>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.bitwise_not(), 0);
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case_pred.bitwise_not().bitwise_not(), case_pred);
        assert_eq!(case_pred.bitwise_not() | case_pred, max);
        assert_eq!(case_pred.bitwise_not() ^ case_pred, max);
        assert_eq!(case_pred.bitwise_not() & case_pred, 0);

        assert_eq!(case.bitwise_not().bitwise_not(), case);
        assert_eq!(case.bitwise_not() | case, max);
        assert_eq!(case.bitwise_not() ^ case, max);
        assert_eq!(case.bitwise_not() & case, 0);

        assert_eq!(case_succ.bitwise_not().bitwise_not(), case_succ);
        assert_eq!(case_succ.bitwise_not() | case_succ, max);
        assert_eq!(case_succ.bitwise_not() ^ case_succ, max);
        assert_eq!(case_succ.bitwise_not() & case_succ, 0);
    })
}

public(package) macro fun test_max($max: _, $cases: vector<_>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.max(max), max);
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(max.max(case), max);
        assert_eq!(case.max(max), max);
        assert_eq!(case.max(case), case);
        assert_eq!(case_pred.max(case), case);
        assert_eq!(case_succ.max(case), case_succ);
    })
}

public(package) macro fun test_min($max: _, $cases: vector<_>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.min(max), max);
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(max.min(case), case);
        assert_eq!(case.min(max), case);
        assert_eq!(case.min(case), case);
        assert_eq!(case_pred.min(case), case_pred);
        assert_eq!(case_succ.min(case), case);
    })
}

public(package) macro fun test_diff($max: _, $cases: vector<_>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.diff(max), 0);
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(max.diff(case), max - case);
        assert_eq!(case.diff(max), max - case);
        assert_eq!(case.diff(case), 0);
        assert_eq!(case_pred.diff(case), case - case_pred);
        assert_eq!(case.diff(case_pred), case - case_pred);
        assert_eq!(case_succ.diff(case), case_succ - case);
        assert_eq!(case.diff(case_succ), case_succ - case);
    })
}

public(package) macro fun check_div_ceil($x: _, $y: _) {
    let x = $x;
    let y = $y;
    if (y == 0) return;
    let r = x.div_ceil(y);
    assert_eq!(r, (x / y) + (x % y).min(1));
    assert_eq!(r, x.divide_and_round_up(y));
}

public(package) macro fun test_div_ceil($max: _, $cases: vector<_>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.div_ceil(max), 1);
    assert_eq!(max.divide_and_round_up(max), 1);
    check_div_ceil!(max, max);
    cases!(max, cases, |case_pred, case, case_succ| {
        check_div_ceil!(max, case);
        check_div_ceil!(case, max);
        check_div_ceil!(case, case);
        check_div_ceil!(case_pred, case);
        check_div_ceil!(case, case_pred);
        check_div_ceil!(case_succ, case);
        check_div_ceil!(case, case_succ);
    })
}

public(package) macro fun check_mul_div<$T, $U>($max: $T, $x: $T, $y: $T, $z: $T) {
    let max = $max;
    let x = $x;
    let y = $y;
    let z = $z;

    // Div by zero is tested separately
    if (z == 0) return;

    // Overflows are tested separately
    let zu = z as $U;
    if ((x as $U) * (y as $U) >= ((max as $U) + 1) * zu) return;

    // Test for commutativity
    assert_eq!(x.mul_div(y, z), y.mul_div(x, z));

    // Test for precision: (x/z)*y loses floor(x%z * y / z)
    if ((x as $U) % zu * (y as $U) >= zu) {
        assert!((x / z) * y < x.mul_div(y, z));
    } else {
        assert_eq!((x / z) * y, x.mul_div(y, z));
    };
    // Test for precision: x*(y/z) loses floor(x * y%z / z)
    if ((y as $U) % zu * (x as $U) >= zu) {
        assert!(x * (y / z) < x.mul_div(y, z));
    } else {
        assert_eq!(x * (y / z), x.mul_div(y, z));
    };
}

public(package) macro fun check_mul_div_ceil<$T, $U>($max: $T, $x: $T, $y: $T, $z: $T) {
    let max = $max;
    let x = $x;
    let y = $y;
    let z = $z;

    // Div by zero is tested separately
    if (z == 0) return;

    // Overflows are tested separately
    let zu = z as $U;
    if ((x as $U) * (y as $U) > (max as $U) * zu) return;

    // Test for commutativity
    assert_eq!(x.mul_div_ceil(y, z), y.mul_div_ceil(x, z));

    // Test for precision: ceil == floor + 1 when x*y is not divisible by z
    let xyu = (x as $U) * (y as $U);
    if (xyu % zu != 0) {
        assert_eq!((x.mul_div(y, z) as $U) + 1, x.mul_div_ceil(y, z) as $U);
    } else {
        assert_eq!(x.mul_div(y, z), x.mul_div_ceil(y, z));
    };
}

public(package) macro fun test_mul_div<$T, $U>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.mul_div(max, max.max(1)), max);
    cases!(max, cases, |case_pred, case, case_succ| {
        check_mul_div!<$T, $U>(max, case_pred, case, case_succ);
    });
    check_mul_div!<$T, $U>(max, max, max, max);
}

public(package) macro fun test_mul_div_ceil<$T, $U>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    assert_eq!(max.mul_div(max, max.max(1)), max);
    cases!(max, cases, |case_pred, case, case_succ| {
        check_mul_div_ceil!<$T, $U>(max, case_pred, case, case_succ);
    });
    check_mul_div_ceil!<$T, $U>(max, max, max, max);
}

public(package) macro fun slow_pow($base: _, $exp: u8): _ {
    let base = $base;
    let mut exp = $exp;
    let mut result = 1;
    while (exp > 0) {
        result = result * base;
        exp = exp - 1;
    };
    result
}

public(package) macro fun test_pow<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case_pred.pow(0), 1);
        assert_eq!(case_pred.pow(1), case_pred);
        assert_eq!(case.pow(0), 1);
        assert_eq!(case.pow(1), case);
        assert_eq!(case_succ.pow(0), 1);
        assert_eq!(case_succ.pow(1), case_succ);
    });
    assert_eq!((0: $T).pow(2), 0);
    assert_eq!((1: $T).pow(255), 1);
    assert_eq!((2: $T).pow(7), slow_pow!((2: $T), 7));
    assert_eq!((3: $T).pow(5), slow_pow!((3: $T), 5));
}

public(package) macro fun test_sqrt<$T>(
    $max: $T,
    $bound_cases: vector<$T>,
    $reflexive_cases: vector<$T>,
) {
    let max = $max;
    let cases = $bound_cases;
    // logical bounds cases
    let max_sqrt = max.sqrt();
    cases!(max, cases, |case_pred, case, case_succ| {
        let sqrt_pred = case_pred.sqrt();
        assert!(sqrt_pred * sqrt_pred <= case_pred);
        let sqrt = case.sqrt();
        assert!(sqrt * sqrt <= case);
        let sqrt_succ = case_succ.sqrt();
        assert!(sqrt_succ * sqrt_succ <= case_succ);

        if (sqrt_pred >= max_sqrt) return;
        assert!((sqrt_pred + 1) * (sqrt_pred + 1) > case_pred);

        if (sqrt >= max_sqrt) return;
        assert!((sqrt + 1) * (sqrt + 1) > case);

        if (sqrt_succ >= max_sqrt) return;
        assert!((sqrt_succ + 1) * (sqrt_succ + 1) > case_succ);
    });

    // simple reflexive cases
    let cases: vector<$T> = $reflexive_cases;
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!((case_pred * case_pred).sqrt(), case_pred);
        assert_eq!((case * case).sqrt(), case);
        assert_eq!((case_succ * case_succ).sqrt(), case_succ);
    });

    // test that the square of a non perfect square is the most recent square root perfect
    // square, rounding down
    let mut cases: vector<$T> = vector[2, 3, 4, 5, 6];
    while (!cases.is_empty()) {
        let case = cases.pop_back();
        let prev = case - 1;
        let square = case * case;
        let prev_suare = prev * prev;
        let mut i = prev_suare;
        while (i < square) {
            assert_eq!(i.sqrt(), prev);
            i = i + 1;
        }
    }
}

public(package) macro fun test_try_as_u8<$T>($max: $T) {
    assert_eq!((0: $T).try_as_u8(), option::some(0));
    assert_eq!((1: $T).try_as_u8(), option::some(1));
    assert_eq!((0xFF: $T).try_as_u8(), option::some(0xFF));
    assert_eq!((0xFF + 1: $T).try_as_u8(), option::none());
    let max = $max;
    assert_eq!(max.try_as_u8(), option::none());
}

public(package) macro fun test_try_as_u16<$T>($max: $T) {
    assert_eq!((0: $T).try_as_u16(), option::some(0));
    assert_eq!((1: $T).try_as_u16(), option::some(1));
    assert_eq!((0xFFFF: $T).try_as_u16(), option::some(0xFFFF));
    assert_eq!((0xFFFF + 1: $T).try_as_u16(), option::none());
    let max = $max;
    assert_eq!(max.try_as_u16(), option::none());
}

public(package) macro fun test_try_as_u32<$T>($max: $T) {
    assert_eq!((0: $T).try_as_u32(), option::some(0));
    assert_eq!((1: $T).try_as_u32(), option::some(1));
    assert_eq!((0xFFFF_FFFF: $T).try_as_u32(), option::some(0xFFFF_FFFF));
    assert_eq!((0xFFFF_FFFF + 1: $T).try_as_u32(), option::none());
    let max = $max;
    assert_eq!(max.try_as_u32(), option::none());
}

public(package) macro fun test_try_as_u64<$T>($max: $T) {
    assert_eq!((0: $T).try_as_u64(), option::some(0));
    assert_eq!((1: $T).try_as_u64(), option::some(1));
    assert_eq!((0xFFFF_FFFF_FFFF_FFFF: $T).try_as_u64(), option::some(0xFFFF_FFFF_FFFF_FFFF));
    assert_eq!((0xFFFF_FFFF_FFFF_FFFF + 1: $T).try_as_u64(), option::none());
    let max = $max;
    assert_eq!(max.try_as_u64(), option::none());
}

public(package) macro fun test_try_as_u128<$T>($max: $T) {
    assert_eq!((0: $T).try_as_u128(), option::some(0));
    assert_eq!((1: $T).try_as_u128(), option::some(1));
    assert_eq!(
        (0xFFFF_FFFF_FFFF_FFFF_FFFF_FFFF_FFFF_FFFF: $T).try_as_u128(),
        option::some(0xFFFF_FFFF_FFFF_FFFF_FFFF_FFFF_FFFF_FFFF),
    );
    assert_eq!((0xFFFF_FFFF_FFFF_FFFF_FFFF_FFFF_FFFF_FFFF + 1: $T).try_as_u128(), option::none());
    let max = $max;
    assert_eq!(max.try_as_u128(), option::none());
}

public(package) macro fun sum_range<$T>($n: $T): $T {
    let n = $n;
    (n * (n + 1)) / 2
}

public(package) macro fun test_to_string<$T>() {
    assert_eq!((0: $T).to_string(), b"0".to_string());
    assert_eq!((1: $T).to_string(), b"1".to_string());
    assert_eq!((10: $T).to_string(), b"10".to_string());
    assert_eq!((11: $T).to_string(), b"11".to_string());
    assert_eq!((100: $T).to_string(), b"100".to_string());
    assert_eq!((111: $T).to_string(), b"111".to_string());
}

public(package) macro fun test_dos_case<$T>($case: $T) {
    let case = $case;
    let mut sum: $T = 0;
    case.do!(|i| sum = sum + i);
    assert_eq!(sum, sum_range!(case - 1));

    sum = 0;
    case.do_eq!(|i| sum = sum + i);
    assert_eq!(sum, sum_range!(case));

    let half = case / 2;

    sum = 0;
    half.range_do!(case, |i| sum = sum + i);
    assert_eq!(sum, sum_range!(case - 1) - sum_range!(half - 1));

    sum = 0;
    half.range_do_eq!(case, |i| sum = sum + i);
    assert_eq!(sum, sum_range!(case) - sum_range!(half - 1));
}

public(package) macro fun test_dos<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // test bounds/invalid ranges
    (0: $T).do!(|_| assert!(false));
    cases!(max, cases, |case_pred, case, case_succ| {
        if (case == 0) return;
        case.range_do!(0, |_| assert!(false));
        case.range_do_eq!(0, |_| assert!(false));

        if (case == max) return;
        case.range_do!(case_pred, |_| assert!(false));
        case_succ.range_do!(case, |_| assert!(false));
        case.range_do_eq!(case_pred, |_| assert!(false));
        case_succ.range_do_eq!(case, |_| assert!(false));
    });

    // test upper bound being max
    let max_pred = max - 1;
    max_pred.range_do_eq!(max, |_| ());

    // test iteration numbers
    let cases: vector<$T> = vector[3, 5, 8, 11, 14];
    cases!(max, cases, |case_pred, case, case_succ| {
        test_dos_case!(case_pred);
        test_dos_case!(case);
        test_dos_case!(case_succ);
    });
}

public(package) macro fun test_checked_add<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).checked_add(0), option::some(0));
    assert_eq!((0: $T).checked_add(1), option::some(1));
    assert_eq!((1: $T).checked_add(0), option::some(1));
    assert_eq!((0: $T).checked_add(max), option::some(max));
    assert_eq!(max.checked_add(0), option::some(max));
    // overflow cases
    assert_eq!(max.checked_add(1), option::none());
    assert_eq!((1: $T).checked_add(max), option::none());
    assert_eq!(max.checked_add(max), option::none());
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case.checked_add(0), option::some(case));
        assert_eq!((0: $T).checked_add(case), option::some(case));
        if (case <= max - 1) {
            assert_eq!(case.checked_add(1), option::some(case + 1));
        } else {
            assert_eq!(case.checked_add(1), option::none());
        };
        if (case <= max - case) {
            assert_eq!(case.checked_add(case), option::some(case + case));
        } else {
            assert_eq!(case.checked_add(case), option::none());
        };
        if (case_pred <= max - case_succ) {
            assert_eq!(case_pred.checked_add(case_succ), option::some(case_pred + case_succ));
        } else {
            assert_eq!(case_pred.checked_add(case_succ), option::none());
        };
    });
}

public(package) macro fun test_checked_sub<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).checked_sub(0), option::some(0));
    assert_eq!((1: $T).checked_sub(0), option::some(1));
    assert_eq!((1: $T).checked_sub(1), option::some(0));
    assert_eq!(max.checked_sub(0), option::some(max));
    assert_eq!(max.checked_sub(max), option::some(0));
    // underflow cases
    assert_eq!((0: $T).checked_sub(1), option::none());
    assert_eq!((0: $T).checked_sub(max), option::none());
    assert_eq!((1: $T).checked_sub(2), option::none());
    assert_eq!((1: $T).checked_sub(max), option::none());
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case.checked_sub(0), option::some(case));
        assert_eq!(case.checked_sub(case), option::some(0));
        assert_eq!(case_succ.checked_sub(case), option::some(case_succ - case));
        assert_eq!(case_succ.checked_sub(case_pred), option::some(case_succ - case_pred));
        assert_eq!(case.checked_sub(case_pred), option::some(case - case_pred));
        assert_eq!(case_pred.checked_sub(case_succ), option::none());
    });
}

public(package) macro fun test_checked_mul<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).checked_mul(0), option::some(0));
    assert_eq!((0: $T).checked_mul(1), option::some(0));
    assert_eq!((1: $T).checked_mul(0), option::some(0));
    assert_eq!((1: $T).checked_mul(1), option::some(1));
    assert_eq!((0: $T).checked_mul(max), option::some(0));
    assert_eq!(max.checked_mul(0), option::some(0));
    assert_eq!(max.checked_mul(1), option::some(max));
    assert_eq!((1: $T).checked_mul(max), option::some(max));
    // overflow cases
    assert_eq!(max.checked_mul(2), option::none());
    assert_eq!((2: $T).checked_mul(max), option::none());
    assert_eq!(max.checked_mul(max), option::none());
    // case iteration
    cases!(max, cases, |_case_pred, case, _case_succ| {
        assert_eq!(case.checked_mul(0), option::some(0));
        assert_eq!((0: $T).checked_mul(case), option::some(0));
        assert_eq!(case.checked_mul(1), option::some(case));
        assert_eq!((1: $T).checked_mul(case), option::some(case));
        if (case != 0 && case <= max / 2) {
            assert_eq!(case.checked_mul(2), option::some(case * 2));
        } else if (case != 0) {
            assert_eq!(case.checked_mul(2), option::none());
        };
        if (case != 0 && case <= max / case) {
            assert_eq!(case.checked_mul(case), option::some(case * case));
        } else if (case != 0) {
            assert_eq!(case.checked_mul(case), option::none());
        };
    });
}

public(package) macro fun test_checked_div<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).checked_div(1), option::some(0));
    assert_eq!((1: $T).checked_div(1), option::some(1));
    assert_eq!(max.checked_div(1), option::some(max));
    assert_eq!(max.checked_div(max), option::some(1));
    // division by zero cases
    assert_eq!((0: $T).checked_div(0), option::none());
    assert_eq!((1: $T).checked_div(0), option::none());
    assert_eq!(max.checked_div(0), option::none());
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        if (case != 0) {
            assert_eq!(case.checked_div(case), option::some(1));
            assert_eq!((0: $T).checked_div(case), option::some(0));
            assert_eq!(case_succ.checked_div(case), option::some(case_succ / case));
        };
        assert_eq!(case.checked_div(0), option::none());
        assert_eq!(case_pred.checked_div(0), option::none());
        assert_eq!(case_succ.checked_div(0), option::none());
    });
}

public(package) macro fun test_saturating_add<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).saturating_add(0), 0);
    assert_eq!((0: $T).saturating_add(1), 1);
    assert_eq!((1: $T).saturating_add(0), 1);
    assert_eq!((0: $T).saturating_add(max), max);
    assert_eq!(max.saturating_add(0), max);
    // saturation cases
    assert_eq!(max.saturating_add(1), max);
    assert_eq!((1: $T).saturating_add(max), max);
    assert_eq!(max.saturating_add(max), max);
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case.saturating_add(0), case);
        assert_eq!((0: $T).saturating_add(case), case);
        if (case <= max - 1) {
            assert_eq!(case.saturating_add(1), case + 1);
        } else {
            assert_eq!(case.saturating_add(1), max);
        };
        if (case <= max - case) {
            assert_eq!(case.saturating_add(case), case + case);
        } else {
            assert_eq!(case.saturating_add(case), max);
        };
        if (case_pred <= max - case_succ) {
            assert_eq!(case_pred.saturating_add(case_succ), case_pred + case_succ);
        } else {
            assert_eq!(case_pred.saturating_add(case_succ), max);
        };
    });
}

public(package) macro fun test_saturating_sub<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).saturating_sub(0), 0);
    assert_eq!((1: $T).saturating_sub(0), 1);
    assert_eq!((1: $T).saturating_sub(1), 0);
    assert_eq!(max.saturating_sub(0), max);
    assert_eq!(max.saturating_sub(max), 0);
    // saturation cases
    assert_eq!((0: $T).saturating_sub(1), 0);
    assert_eq!((0: $T).saturating_sub(max), 0);
    assert_eq!((1: $T).saturating_sub(2), 0);
    assert_eq!((1: $T).saturating_sub(max), 0);
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case.saturating_sub(0), case);
        assert_eq!(case.saturating_sub(case), 0);
        assert_eq!(case_succ.saturating_sub(case), case_succ - case);
        assert_eq!(case_succ.saturating_sub(case_pred), case_succ - case_pred);
        assert_eq!(case.saturating_sub(case_pred), case - case_pred);
        assert_eq!(case_pred.saturating_sub(case_succ), 0);
    });
}

public(package) macro fun test_saturating_mul<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).saturating_mul(0), 0);
    assert_eq!((0: $T).saturating_mul(1), 0);
    assert_eq!((1: $T).saturating_mul(0), 0);
    assert_eq!((1: $T).saturating_mul(1), 1);
    assert_eq!((0: $T).saturating_mul(max), 0);
    assert_eq!(max.saturating_mul(0), 0);
    assert_eq!(max.saturating_mul(1), max);
    assert_eq!((1: $T).saturating_mul(max), max);
    // saturation cases
    assert_eq!(max.saturating_mul(2), max);
    assert_eq!((2: $T).saturating_mul(max), max);
    assert_eq!(max.saturating_mul(max), max);
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        assert_eq!(case.saturating_mul(0), 0);
        assert_eq!((0: $T).saturating_mul(case), 0);
        assert_eq!(case.saturating_mul(1), case);
        assert_eq!((1: $T).saturating_mul(case), case);
        if (case != 0 && case <= max / 2) {
            assert_eq!(case.saturating_mul(2), case * 2);
        } else if (case != 0) {
            assert_eq!(case.saturating_mul(2), max);
        };
        if (case != 0 && case <= max / case) {
            assert_eq!(case.saturating_mul(case), case * case);
        } else if (case != 0) {
            assert_eq!(case.saturating_mul(case), max);
        };
        if (case_pred != 0 && case_succ <= max / case_pred) {
            assert_eq!(case_pred.saturating_mul(case_succ), case_pred * case_succ);
        } else if (case_pred != 0) {
            assert_eq!(case_pred.saturating_mul(case_succ), max);
        };
    });
}

public(package) macro fun test_checked_shl<$T>($max: $T, $bit_size: u8) {
    let max = $max;
    let bit_size = $bit_size;
    // valid shifts
    assert_eq!((0: $T).checked_shl(0), option::some(0));
    assert_eq!((1: $T).checked_shl(0), option::some(1));
    assert_eq!((1: $T).checked_shl(1), option::some(2));
    assert_eq!((1: $T).checked_shl(bit_size - 1), option::some(1 << (bit_size - 1)));
    assert_eq!(max.checked_shl(0), option::some(max));
    // invalid shifts (>= bit_size)
    assert_eq!((0: $T).checked_shl(bit_size), option::none());
    assert_eq!((1: $T).checked_shl(bit_size), option::none());
    assert_eq!(max.checked_shl(bit_size), option::none());
    assert_eq!((1: $T).checked_shl(bit_size + 1), option::none());
}

public(package) macro fun test_checked_shr<$T>($max: $T, $bit_size: u8) {
    let max = $max;
    let bit_size = $bit_size;
    // valid shifts
    assert_eq!((0: $T).checked_shr(0), option::some(0));
    assert_eq!((1: $T).checked_shr(0), option::some(1));
    assert_eq!((2: $T).checked_shr(1), option::some(1));
    assert_eq!(max.checked_shr(0), option::some(max));
    assert_eq!(max.checked_shr(bit_size - 1), option::some(1));
    // invalid shifts (>= bit_size)
    assert_eq!((0: $T).checked_shr(bit_size), option::none());
    assert_eq!((1: $T).checked_shr(bit_size), option::none());
    assert_eq!(max.checked_shr(bit_size), option::none());
    assert_eq!((1: $T).checked_shr(bit_size + 1), option::none());
}

public(package) macro fun test_lossless_shl<$T>($max: $T, $bit_size: u8) {
    let max = $max;
    let bit_size = $bit_size;
    // exact shifts (no bits lost)
    assert_eq!((0: $T).lossless_shl(0), option::some(0));
    assert_eq!((0: $T).lossless_shl(bit_size - 1), option::some(0));
    assert_eq!((1: $T).lossless_shl(0), option::some(1));
    assert_eq!((1: $T).lossless_shl(1), option::some(2));
    assert_eq!((1: $T).lossless_shl(bit_size - 1), option::some(1 << (bit_size - 1)));
    // inexact shifts (bits lost)
    assert_eq!((0: $T).lossless_shl(bit_size), option::none());
    assert_eq!((1: $T).lossless_shl(bit_size), option::none());
    assert_eq!(max.lossless_shl(bit_size), option::none());
    assert_eq!((1: $T).lossless_shl(bit_size + 1), option::none());
    assert_eq!((1 << (bit_size - 1): $T).lossless_shl(1), option::none());
    // high bit set, any shift loses it
    let high_bit = (1: $T) << (bit_size - 1);
    assert_eq!(high_bit.lossless_shl(1), option::none());
}

public(package) macro fun test_lossless_shr<$T>($max: $T, $bit_size: u8) {
    let max = $max;
    let bit_size = $bit_size;
    // exact shifts (no bits lost)
    assert_eq!((0: $T).lossless_shr(0), option::some(0));
    assert_eq!((0: $T).lossless_shr(bit_size - 1), option::some(0));
    assert_eq!((1: $T).lossless_shr(0), option::some(1));
    assert_eq!((2: $T).lossless_shr(1), option::some(1));
    assert_eq!((4: $T).lossless_shr(2), option::some(1));
    let high_bit = (1: $T) << (bit_size - 1);
    assert_eq!(high_bit.lossless_shr(bit_size - 1), option::some(1));
    // inexact shifts (bits lost)
    assert_eq!((0: $T).lossless_shr(bit_size), option::none());
    assert_eq!((1: $T).lossless_shr(bit_size), option::none());
    assert_eq!(max.lossless_shr(bit_size), option::none());
    assert_eq!((1: $T).lossless_shr(bit_size + 1), option::none());
    // low bit set, any shift loses it
    assert_eq!((1: $T).lossless_shr(1), option::none());
    assert_eq!((3: $T).lossless_shr(1), option::none())
}

public(package) macro fun test_lossless_div<$T>($max: $T, $cases: vector<$T>) {
    let max = $max;
    let cases = $cases;
    // basic cases
    assert_eq!((0: $T).lossless_div(1), option::some(0));
    assert_eq!((1: $T).lossless_div(1), option::some(1));
    assert_eq!((4: $T).lossless_div(2), option::some(2));
    assert_eq!((6: $T).lossless_div(3), option::some(2));
    // division with remainder
    assert_eq!((1: $T).lossless_div(2), option::none());
    assert_eq!((3: $T).lossless_div(2), option::none());
    assert_eq!((5: $T).lossless_div(3), option::none());

    assert_eq!(max.lossless_div(2), option::none());
    // case iteration
    cases!(max, cases, |case_pred, case, case_succ| {
        if (case == 0) return;

        // basic cases
        assert_eq!(case.lossless_div(0), option::none());
        assert_eq!((0: $T).lossless_div(case), option::some(0));
        assert_eq!(case.lossless_div(1), option::some(case));
        assert_eq!(case.lossless_div(case), option::some(1));

        // case * i / i should be lossless if case * i doesn't overflow
        (2: $T).range_do!(10, |i| {
            if (case <= max / i) {
                let res = (case * i).lossless_div(i);
                assert_eq!(res, option::some(case));
                assert_eq!(res.destroy_some() * i, case * i);
            }
        });
        if (case_pred != case && case_pred != 0) {
            assert_eq!(case_pred.lossless_div(case), option::none());
        };
        if (case_succ != case) {
            assert_eq!(case.lossless_div(case_succ), option::none());
        };
    });
}
