#!/usr/bin/env python3
"""Offline production build, semantic VM tests and precise foreign refusals."""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys

ROOT = Path(__file__).resolve().parent
PIN = json.loads((ROOT / 'runtime-pin.json').read_text())
CLI = Path(PIN['cli'])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CLI) == PIN['sha256'] == '1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3'
HOME = ROOT / 'verification/home'
CONFIG = HOME / '.sui/sui_config'
CONFIG.mkdir(parents=True, exist_ok=True)
(CONFIG / 'empty.keystore').write_text('[]\n')
(CONFIG / 'client.yaml').write_text(f'keystore:\n  File: {CONFIG / "empty.keystore"}\nenvs:\n  - alias: testnet\n    rpc: http://127.0.0.1:9\nactive_env: testnet\nactive_address: ~\n')
ENV = os.environ.copy()
ENV.update(HOME=str(HOME), MOVE_HOME=str(HOME / '.move'), XDG_CONFIG_HOME=str(HOME / '.config'))
PREFIX = ['/usr/bin/sandbox-exec', '-p', '(version 1)(allow default)(deny network*)']
LOGS = ROOT / 'verification/logs'
LOGS.mkdir(parents=True, exist_ok=True)
def execute(name, args):
    result = subprocess.run(PREFIX + args, cwd=ROOT, env=ENV, capture_output=True, timeout=300)
    out = result.stdout + result.stderr
    # Never publish a secret accidentally emitted by CLI initialization.
    assert b'secret recovery phrase' not in out and b'Generated new keypair' not in out
    log = LOGS / (name + '.log'); log.write_bytes(out)
    return {'exit_code': result.returncode, 'log': str(log.relative_to(ROOT)), 'sha256': sha(log)}, out

production, _ = execute('production', [str(CLI), 'move', 'build', '--path', str(ROOT/'channel'), '--install-dir', str(ROOT/'verification/production')])
tests, output = execute('semantic-tests', [str(CLI), 'move', 'test', '--path', str(ROOT/'channel'), '--install-dir', str(ROOT/'verification/tests')])
summary = re.search(rb'Test result: (\w+)\. Total tests: (\d+); passed: (\d+); failed: (\d+)', output)
assert summary, output.decode()

PROBES = {
 'forge_authorization': '''public fun forge<S,C,A,R>(): Authorization<S,C,A,R> {
    Authorization { instance: object::id_from_address(@0x1), instance_generation: 0,
    agreement: object::id_from_address(@0x2), generation: 0, terms: vector[], actor: @0x3,
    intent: vector[], quantity: 1, expires_epoch: 99 }
 }''',
 'drop_obligation': 'public fun discard<S,C,A,R>(ticket: Authorization<S,C,A,R>) {}',
 'copy_obligation': 'public fun duplicate<S,C,A,R>(ticket:Authorization<S,C,A,R>): (Authorization<S,C,A,R>,Authorization<S,C,A,R>) { (copy ticket,ticket) }',
 'drop_source_state': 'public fun discard<S,A>(state:SourceState<S,A>) {}',
 'store_obligation': 'public struct Carrier<phantom S,phantom C,phantom A,phantom R> has key { id: UID, ticket: Authorization<S,C,A,R> }',
 'forge_source_state': '''public fun forge<S,A>(): SourceState<S,A> {
    SourceState { source: object::id_from_address(@0x1), version: 1, generation: 0, principal: @0x1 }
 }''',
 'reuse_obligation': '''public fun reuse<S:key,C,A,R>(i:&Instance<C>,a:&mut Agreement<S,C,A,R>,s:&S,
    ticket:Authorization<S,C,A,R>,x:Completion<S,R>,y:Completion<S,R>,ctx:&TxContext) {
    agreement::complete(i,a,s,ticket,x,ctx); agreement::complete(i,a,s,ticket,y,ctx)
 }''',
 'wrong_coin_type': '''public fun wrong<S:key,C,A,R>(i:&mut Instance<C>,a:&mut Agreement<S,C,A,R>,s:&S,
    state:SourceState<S,A>,payment:sui::coin::Coin<sui::sui::SUI>,ctx:&mut TxContext): (Authorization<S,C,A,R>,sui::coin::Coin<C>) {
    agreement::authorize(i,a,s,state,vector[],1,1,vector[],payment,ctx)
 }''',
 'wrong_completion_type': '''public struct Other has drop {}
 public fun wrong<S:key,C,A,R>(i:&Instance<C>,a:&mut Agreement<S,C,A,R>,s:&S,
    ticket:Authorization<S,C,A,R>,x:Completion<S,Other>,ctx:&TxContext) {
    agreement::complete(i,a,s,ticket,x,ctx)
 }''',
}
EXPECTED = {'forge_authorization':'EC04001','forge_source_state':'EC04001',
 'drop_obligation':'EC06001','copy_obligation':'EC05001','drop_source_state':'EC06001','store_obligation':'EC05001','reuse_obligation':'EC06002',
 'wrong_coin_type':'EC04007','wrong_completion_type':'EC04007'}
refusals = []
for name, body in PROBES.items():
    package = ROOT / 'probes' / name; (package/'sources').mkdir(parents=True, exist_ok=True)
    (package/'Move.toml').write_text('[package]\nname = "ChannelRefusal"\nedition = "2024"\n[dependencies]\nSoulChannelCandidate = { local = "../../channel" }\nSui = { local = "../../deps/sui-framework", override = true }\n[addresses]\nforeign = "0x42"\n')
    source = package/'sources/probe.move'
    source.write_text('module foreign::probe;\nuse soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};\n'+body+'\n')
    row, out = execute(name, [str(CLI),'move','build','--path',str(package),'--install-dir',str(ROOT/'verification/probes'/name)])
    plain = re.sub(rb'\x1b\[[0-9;]*m', b'', out)
    codes = re.findall(rb'error\[([^\]]+)\]', plain)
    first = codes[0].decode() if codes else None
    row.update(name=name, source=str(source.relative_to(ROOT)), source_sha256=sha(source), first_error=first,
               expected_first_error=EXPECTED[name], refused=row['exit_code']!=0 and first==EXPECTED[name] and b'probe.move:' in plain)
    refusals.append(row)
artifacts = {p.name: sha(p) for p in (ROOT/'verification/production/build/SoulChannelCandidate/bytecode_modules').glob('*.mv')}
passed = production['exit_code']==0 and tests['exit_code']==0 and summary[1]==b'OK' and int(summary[2])==36 and int(summary[4])==0 and all(x['refused'] for x in refusals) and set(artifacts)=={'agreement.mv'}
result = {'result':'PASS' if passed else 'FAIL', 'production':production,'tests':tests,
 'test_summary':{'result':summary[1].decode(),'total':int(summary[2]),'passed':int(summary[3]),'failed':int(summary[4])},
 'foreign_refusals':refusals,'production_artifacts':artifacts,'cli_sha256':sha(CLI),
 'framework_revision':PIN['framework_revision'],'network_policy':PREFIX,'source_project_dependencies':[],
 'scope':'Channel agreement/settlement VM candidate; producer fixture is test-only; not production Maker/Market issuance',
 'activation':False,'chain_transactions':0,'remote_operations':0,'original_scope':[157,30,1528,15],
 'budget':'default; no overrides','keyless_config':{'keystore_entries':0,'rpc':'loopback port 9, blocked by sandbox'}}
(ROOT/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'result':result['result'],'tests':result['test_summary'],'refusals':[(x['name'],x['first_error'],x['refused']) for x in refusals]}))
sys.exit(0 if passed else 1)
