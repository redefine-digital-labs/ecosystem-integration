# Product engineering review attachment

Original record references/owners are preserved in `original-record-attachment.json`.
This local attachment follows the existing handbook template; it is not an
external card update. Handbook v1.0 sections 1–5, 6 payment applicability, 7,
8.3–8.4, 9 and 12 apply; Operating Model §8 remains the sole stage loop.

| Domain | Conclusion and evidence | Remaining |
| --- | --- | --- |
| Product / Agile | Candidate fulfills a bounded optional-channel protocol; SPEC records original gaps | Production Maker/Market and original four paths; original acceptance owners |
| Build / Test | See pinned CLI, contained two-package Sui closure, production artifact and VM/compiler result.json | Independent reproduction/review; no release or hosted CI claim |
| Funds | Real Coin split and Balance-backed income; exact Coin amount and small FLOOR boundary tested | Confirm proposed commission policy; original Maker payment composition; regulated Coin restrictions |
| Contract security | Sealed typed issuer roles, linear obligations, instance/source/generation/intent checks and refusals | Real issuer constructors/control and final business audit; qualified review |
| Sui | Production UID allocated directly in defining constructors; linear values cannot store/drop/copy/replay | Actual PTB finalization, type origins, publisher/upgrade and old-callable tests |
| Governance | Bound owner+AdminCap; source-less service pause, generation-changing handover; live income exit | Actual Cap custody/readback and loss/compromise drill; no deployed multisig/timelock |
| EVM / DeFi | N/A: no EVM, token issuance, lending, AMM, shares or financial model | No new roadmap implied |
| Operations / recovery | Revocation/expiry/withdrawal stay reachable during pause; each suspension reason independent | Actual service monitor/reconciliation/SDK/UI and source handover semantics |

Assets are agreements, source adapter statements, paid Coins and service Balance.
Principal accepts exact terms, service owner offers/executes, source issuer proves
actual control and final business closure. A/R witness constructors remain part
of the trusted producer boundary; same-module identity is not a code audit.
Commission is candidate FLOOR(gross × BPS / 10000), no new refunds or asset locks.
Authorization and producer net payment are one atomic transaction; abandoning a
linear obligation fails compilation/transaction finalization. Unit refusal
evidence is VM-level, not post-abort retained-chain state readback.

No deployment, signature, spending, source activation or independent release
was performed. Existing key/config/DB resources were not changed. Pinned CLI's
initial empty-home VM run generated an unused key only inside a private candidate
runtime directory; that directory is excluded from freeze and diagnostics were
sanitized before freeze. Reproduction uses an explicit empty keystore, loopback
RPC and enforced network denial. No key creation occurs in final verification.

Recovery point: candidate remains entirely unactivated; owning code and historical
evidence stay authoritative. Freeze is the review identity. Next: root read-only
review, then resolve source-adapter/payment ABI and policy choices with original
owners before any owning-source or chain activation.
