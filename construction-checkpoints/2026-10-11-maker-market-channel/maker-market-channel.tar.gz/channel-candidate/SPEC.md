# Optional Channel agreement candidate v1

This isolated, unpublished candidate implements Channel's own agreements,
generations, selected-instance quotas and genuine Coin service income. Maker
manufacture, publication, distribution and Soul admission remain distinct.
Maker and Soul remain independent; selecting Channel is explicit consent to
the exact service terms. This is a proposed runtime contract, not activation of
the historical Channel scaffold or acceptance of all original journeys.

Authoritative inputs are pinned in `input-pins.json`: interoperability CHANNEL
F09/F16/F11 and boundary decisions D27–D29. Original 157 records, 30 duties,
1528 production queue entries, 15 retained units and originalOwners stay intact.
`original-record-attachment.json` preserves the existing references and roles;
no external record was edited and no competing board was created.

## Runtime acceptance

| Requirement | Concrete implementation / evidence |
| --- | --- |
| Explicit exact consent | Owner offers; source principal accepts SHA-256 BCS of every typed term, including selected Source/Coin/authority/completion types, instance/source IDs and generations, parties, action, quota, gross, rate and epoch interval |
| Lifecycle | Offered → Accepted → Revoked / Expired / Suspended; each party clears only its own suspension reason; ended agreements cannot resume or accept again; a new offer requires fresh exact consent |
| Current authority | Bound AdminCap + live sender; handover rotates instance generation, invalidating all old agreements; actual source issuer witnesses must belong to Source's original package and defining module; authority and completion roles must differ |
| Selected quota | `used` is only this agreement's channel allocation; persistent intent replay refusal; actual producer cap/supply remains sole source authority |
| Funded obligation | Exact `Coin<C>` gross split into actual `Balance<C>` commission + actual producer `Coin<C>`; linear Authorization forces a selected producer completion in the same transaction |
| Final closure | Completion must match source ID, business version/generation, actor, beneficiary, action, quantity and intent; service/agreement state, terms, generation and epoch rechecked after the business call |
| Recovery / exits | Service pause blocks new offer/accept/authorization; revoke, permissionless expiry and current service authority income withdrawal remain available; multi-reason resume cannot clear another party's reason |
| Honest evidence | Production build + focused VM positive/refusal tests + exact primary foreign compiler diagnostics; no chain publication or production issuance claim |

## Candidate choices requiring review before activation

No existing Channel production code or approved numeric commission policy was
found. V1 therefore explicitly proposes immutable per-agreement terms: arbitrary
u64 positive quota, fixed gross per unit, rate in basis points from 0–10000,
and FLOOR(gross × rate / 10000) service commission. BPS=10000 is a denominator,
not an inherited Maker royalty cap. Zero commission is allowed. Payment must
equal gross exactly; quote changes require a fresh agreement. No refunds,
price caps, 50-BPS steps or renewal promise are invented. These choices are
recommendations in this unactivated candidate, not newly accepted business
policy. They do not replace original Maker additive-CEIL components or native
gross-FLOOR obligations. A real adapter must ensure the actual producer remainder
pays every original obligation according to the producer's canonical quote.

Epoch windows are explicit [starts_epoch, expires_epoch); these terms promise
epoch resolution, not exact wall-clock deadlines. Source `version` means the
producer's business version, not a fabricated Sui object-version read. The
current owner is also the offered agent; delegated service operators are outside
this bounded ABI. Source-defining-module witnesses are an intentionally strict
candidate authority boundary, not a general callback registry.

## Precise production integration gap

`SourceState<S,A>` and `Completion<S,R>` are linear producer statements. Channel
checks their exact sealed types and bindings; it cannot introspect arbitrary
Source's private control/state or verify business semantics inside an issuer's
code. The actual Source defining module must expose narrowly protected A/R
constructors: A after real source control/current generation validation, R only
after the actual business call, original payment and resulting asset/delivery
close. Review must reject public unconditional A/R constructors. This core does
not grant any rights to a Source merely by reading its ID.

The actual owning `maker-protocol` repository currently contains Terms,
Publication and Soul-specific Admission packages. Its pinned Admission manifest
still imports Standard and exposes no selected Channel consumer. The inspected
manufacturing source snapshot's `maker_factory.begin/finish` requires a canonical
Product, Config, certified publication/Walrus System, origin Snapshot and typed
issuer/revision witnesses. Its actual finish returns the origin protocol's
`CompletionAuthorization`; it currently exposes no Source-defining-module R
for Channel, no selected Channel payment consumer and no joint terminal closure.
Adding that genuine consumer is required before claiming Channel→Maker issuance.
`channel/tests/producer_fixture.move` is a test-only, separately identified
minimal producer that proves protocol composition and its own cap/payment
refusals. It is not the production Maker, does not substitute for original Maker
tests, and is absent from production bytecode. Market action is a typed adapter
target only; no real Market trade or Channel→Market acceptance is claimed.

Free transfer of production sources, controlled handover, A→B→A, existing
rights, original revenue ledgers, actual upgrade/old-callable rejection,
regulated Coin controls, source activation, chain proof, SDK/UI, four original
issuance/market paths and qualified independent acceptance remain required.
No universal transfer revocation, deployed multisig/timelock, immutability or
key-loss recovery is claimed. No Standard/Core/Maker/Market dependency is added
to this core and no source, remote, key, DB or retained chain state is activated.
