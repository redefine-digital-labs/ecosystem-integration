# Bounded implementation plan

1. Read current ACT memory/handoff and primary handbook v1.0, interoperability
   and boundary contracts. Pin applicable source inputs and existing record
   references. Preserve originalOwners, full scope and CURRENT pointers.
2. Build a Sui-only optional Channel core in this exclusive new directory.
   Commit all typed agreement terms; implement state/generation/epoch guards,
   selected quota, replay prevention, Coin split and linear fulfillment closure.
3. Exercise positive consent/settlement/renewed agreement/recovery and focused
   refusals with an explicitly test-only producer. Keep production integration
   gaps visible. Use production build and primary foreign compiler failures.
4. Freeze source, dependency inputs, logs, artifacts and review documents.
   Hand root the exact candidate for independent read-only review. No source
   activation, commit, push, remote, signing, DB/key/runtime reset or CURRENT edit.

Current delivery stage: Test. Status: candidate, independent acceptance pending.
Build/Test evidence is `result.json`; Release/Deploy/Operate/Monitor exit criteria
remain unfulfilled. This increment does not close the full project goal.
