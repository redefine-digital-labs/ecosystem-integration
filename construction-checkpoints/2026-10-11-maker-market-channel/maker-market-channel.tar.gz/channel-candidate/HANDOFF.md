# Bounded prepared-candidate handoff

ACT: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity`.
Exclusive output: this `channel-agreement-runtime-candidate-v1` directory.
Root coordinates the project CURRENT/handoff; this agent did not edit either.

State: prepared, unactivated candidate; local production build + 36 VM tests +
9 precise foreign refusals pass. Read SPEC, REPORT and result.json against the
terminal frozen-manifest, then perform independent read-only review. The freeze
contains source, dependencies, tests/probes, exact logs/artifact, actual owning
module/management snapshot and applicable external-input SHA pins. Runtime homes
and disposable build output are excluded; one initial CLI-generated unused private
keystore stays outside the review/public closure and is not a signing resource.

Public core is optional: explicit exact offered terms → actual source principal
consent → agent executes a funded linear authorization → selected producer's
actual fulfillment statement → final Channel closure. Channel only owns its
service quota/income; it cannot issue assets or override producer total supply.

Next: root's separate independent review; resolve actual Source-defining-module
Maker A/R adapter and canonical producer quote/payment composition, then test
the real producer/Market consumer before any source activation. Current owning
Maker has no Channel consumer; fixture evidence does not prove original issuance.
Policy recommendations and all original gaps stay as listed in SPEC. Owning
repositories, originals, records/Owners, primary CURRENT and retained runtime
resources remain unchanged. Candidate code is unpublished; rollback is to leave
it unactivated, with no on-chain rollback implied.
