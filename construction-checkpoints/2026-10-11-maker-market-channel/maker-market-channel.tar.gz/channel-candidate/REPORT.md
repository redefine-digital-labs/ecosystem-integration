# Prepared Channel runtime candidate

Implemented a new standalone Sui-only agreement core; the owning `soul-channel`
repository remains read-only and unactivated. Its actual `module.json` and
management/owner references are pinned and copied exactly. Historical MODULE.md
`['mandatory MARKET']` is a prohibited dependency marker, not a mandatory link.

Production build PASS. The sole production module `agreement.mv` SHA-256 is
`c0209050b42986f6b1ee2580aff83f8fbc35b06c77d8bd45f2904ce54491b349`.
All 36 focused VM tests PASS. All nine foreign compiler refusals PASS with exact
source SHA, primary diagnostic and first source position in `result.json`:
forging Authorization/SourceState EC04001; dropping obligations/SourceState
EC06001; copying/storing Authorization EC05001; reusing a moved Authorization
EC06002; wrong Coin/completion type EC04007. The test-only producer is absent
from production bytecode.

Verified behavior includes exact typed terms consent, offered/accepted/revoked/
expired/suspended states, separate suspension reasons, source/service/agreement
generation refusal, authority mismatch, start/expiry boundaries, actual Coin
split and income exit, selected quota and intent replay refusal, final intent/
beneficiary closure, same-operation revocation/source rotation refusal, and an
independent producer cap that Channel quota cannot bypass. Direct fixture
manufacturing has no Channel fee or Channel quota mutation.

Reproduce with `python3 verify.py` from this directory; it enforces CLI SHA
`1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3`, framework
revision `2a0becb2fcc6989e492981104af67f62f2c9511a`, contained Sui/MoveStdlib
dependencies, keyless local configuration and macOS network denial. Defaults
are unchanged. Final verification emitted no new-key or recovery-phrase lines.

Historical failed attempts remain diagnostic evidence: unsupported old CLI
flag, wrong hash module, unavailable enum constructor, fixture sender/ID reuse,
and a verifier's initially incorrect expected moved-variable code. None are
relabeled successful. Their fixes did not weaken business guards.

Candidate commission/price/epoch and source-module-witness choices are explicit
recommendations in SPEC; they are not activated policy. Genuine production
Maker/Market adapters, original payment/revenue obligations, original journeys,
chain/upgrade/governance evidence, independent review/release and SDK/UI remain
pending. No source activation, commit/push, remote action, signature, spending,
CURRENT edit, retained chain/key/config/DB change or project-goal closure occurred.
Original scope 157/30/1528/15 and originalOwners are preserved.
