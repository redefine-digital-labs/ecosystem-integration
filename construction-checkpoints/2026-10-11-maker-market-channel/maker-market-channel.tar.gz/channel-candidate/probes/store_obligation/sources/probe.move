module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public struct Carrier<phantom S,phantom C,phantom A,phantom R> has key { id: UID, ticket: Authorization<S,C,A,R> }
