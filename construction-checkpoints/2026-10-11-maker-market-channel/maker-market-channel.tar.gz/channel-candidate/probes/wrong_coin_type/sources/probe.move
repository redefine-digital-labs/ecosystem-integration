module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public fun wrong<S:key,C,A,R>(i:&mut Instance<C>,a:&mut Agreement<S,C,A,R>,s:&S,
    state:SourceState<S,A>,payment:sui::coin::Coin<sui::sui::SUI>,ctx:&mut TxContext): (Authorization<S,C,A,R>,sui::coin::Coin<C>) {
    agreement::authorize(i,a,s,state,vector[],1,1,vector[],payment,ctx)
 }
