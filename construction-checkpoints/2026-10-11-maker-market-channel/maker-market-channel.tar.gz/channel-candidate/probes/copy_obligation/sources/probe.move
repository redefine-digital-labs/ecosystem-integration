module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public fun duplicate<S,C,A,R>(ticket:Authorization<S,C,A,R>): (Authorization<S,C,A,R>,Authorization<S,C,A,R>) { (copy ticket,ticket) }
