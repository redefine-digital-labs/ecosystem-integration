module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public fun discard<S,A>(state:SourceState<S,A>) {}
