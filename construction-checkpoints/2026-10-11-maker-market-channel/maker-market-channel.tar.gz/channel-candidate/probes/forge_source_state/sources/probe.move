module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public fun forge<S,A>(): SourceState<S,A> {
    SourceState { source: object::id_from_address(@0x1), version: 1, generation: 0, principal: @0x1 }
 }
