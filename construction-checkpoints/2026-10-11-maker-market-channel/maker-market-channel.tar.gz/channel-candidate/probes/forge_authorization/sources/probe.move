module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public fun forge<S,C,A,R>(): Authorization<S,C,A,R> {
    Authorization { instance: object::id_from_address(@0x1), instance_generation: 0,
    agreement: object::id_from_address(@0x2), generation: 0, terms: vector[], actor: @0x3,
    intent: vector[], quantity: 1, expires_epoch: 99 }
 }
