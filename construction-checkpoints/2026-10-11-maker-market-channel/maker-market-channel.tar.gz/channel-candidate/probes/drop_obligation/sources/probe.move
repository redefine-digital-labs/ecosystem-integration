module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public fun discard<S,C,A,R>(ticket: Authorization<S,C,A,R>) {}
