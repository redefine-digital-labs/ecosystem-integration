module foreign::probe;
use soul_channel::agreement::{Self, Authorization, SourceState, Completion, Instance, Agreement};
public struct Other has drop {}
 public fun wrong<S:key,C,A,R>(i:&Instance<C>,a:&mut Agreement<S,C,A,R>,s:&S,
    ticket:Authorization<S,C,A,R>,x:Completion<S,Other>,ctx:&TxContext) {
    agreement::complete(i,a,s,ticket,x,ctx)
 }
