#!/usr/bin/env python3
"""Freeze explicit source/evidence closure; private runtime resources excluded."""
from pathlib import Path
import hashlib, json, sys
ROOT = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest = ROOT/'frozen-manifest.json'
if '--check' in sys.argv:
    frozen = json.loads(manifest.read_text())
    expected = (ROOT/'frozen-manifest.sha256').read_text().split()[0]
    assert sha(manifest) == expected
    for row in frozen['files']:
        p = ROOT/row['path']; assert p.is_file() and not p.is_symlink()
        assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], row['path']
    print(json.dumps({'result':'PASS','manifest_sha256':expected,'counts':frozen['counts']}))
    sys.exit(0)
assert not manifest.exists(), 'Never overwrite a frozen candidate; create a new increment'
result = json.loads((ROOT/'result.json').read_text()); assert result['result']=='PASS'
files=[]
for folder in ['channel','deps','probes']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and 'build' not in p.parts and '.git' not in p.parts:
            assert not p.is_symlink(); files.append(p)
files += list((ROOT/'verification/logs').glob('*.log'))
files += list((ROOT/'verification/production/build/SoulChannelCandidate/bytecode_modules').glob('*.mv'))
excluded_root={'frozen-manifest.json','frozen-manifest.sha256','test-first.log'}
files += [p for p in ROOT.iterdir() if p.is_file() and p.name not in excluded_root]
rows=[]
for p in sorted(set(files)):
    if p.suffix=='.log':
        b=p.read_bytes()
        assert b'secret recovery phrase :' not in b and b'Generated new keypair' not in b
    rows.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size})
frozen={'schema_version':1,'scope':'unactivated Channel optional agreement runtime candidate; explicit review inputs only',
 'files':rows,'counts':{'files':len(rows),'move_sources':sum(x['path'].endswith('.move') for x in rows),
 'channel_production_modules':1,'vm_tests':36,'foreign_refusals':9},
 'excluded':['runs/**','test-first.log','verification/home/**','verification/tests/**','verification/probes/**',
 'channel/build/**','verification/production/** except agreement.mv'],
 'production_artifact':result['production_artifacts'],'initial_private_keystore':'excluded; unused; no signing/submission; existing resources untouched',
 'candidate_policy':'Recommendations requiring review; no production Maker/Market consumer',
 'original_scope':[157,30,1528,15],'originalOwners':'unchanged'}
manifest.write_text(json.dumps(frozen,sort_keys=True,indent=2)+'\n')
(ROOT/'frozen-manifest.sha256').write_text(sha(manifest)+'  frozen-manifest.json\n')
print(json.dumps({'result':'FROZEN','manifest_sha256':sha(manifest),'counts':frozen['counts']}))
