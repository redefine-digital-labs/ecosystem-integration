# Channel runtime terminal independent review handoff

Review complete; candidate acceptance FAIL/activation blocked. Full157 responsibilities/30 duties/1528 queue/15 retained units goal remains ACTIVE. Existing owners, product behavior, scope and original records remain unchanged.

Worktree: `/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity`. Exclusive output: this new `channel-agreement-runtime-readonly-review-v1` directory. Root coordinates CURRENT and overall continuation; this agent did not edit either.

Reviewed freeze `f415bd46c8e6ecbaae8a1e72c5464db276bd50830861bec9c59505fd272beecb`,245 files exact before/after. Fresh pinned CLI/empty keystore/deny-network production build36VM/9precise foreign refusals PASS, sole agreement.mv `c0209050b42986f6b1ee2580aff83f8fbc35b06c77d8bd45f2904ce54491b349` exact. No real keys, initialization, source/permission/chain/remote mutation, signature, commit, push or PR.

Independent combined39 VM tests include two successful undesired-behavior controls: `state → source.rotate → accept` still accepts (R1), and `fulfill/R → source.rotate → complete` still closes (R2). These are precise activation blockers, not grounds to narrow source-current guarantees. Added cross-transaction Scenario replay test proves persisted counters/income and EIntent refusal on a later transaction. Read REPORT and REVIEW.json with exact sources/tests/logs; two counterexample successes mean review FAIL.

Generic snapshot transport/nominal source-module witness origin does not prove real producer current control, protected constructor semantics, canonical payment/supply/income/delivery or live final closure. Actual Maker/Market adapters and original four journeys remain missing. Policy recommendations remain unactivated; aggregate FLOOR splitting effect is documented factually.22/25 external pins unchanged; three Maker module/Terms/Publication metadata differences are attributed by Root to separately reviewed627-op actual activation. Exact expected/observed SHA retained; candidate integrity remains exact.

Next executable step: Root implements NEW candidate version with genuine producer-owned acceptance/authorization/fulfillment/final Channel closure, private/narrow A/R constructors, actual source-current Control/version/generation checks immediately around the protected operations, and canonical original payment/revenue/delivery. Do not expose a transportable stale completion path. Preserve requirements and test R1/R2 refusal plus original regression/payment/generation/exit paths in independent fresh verification before any activation. Do not edit frozen v1 or reactivate this completed verifier for implementation.

Recovery: leave candidate v1 unactivated. There is no on-chain rollback. Handbook v1.0 attachment references unchanged original card/owner mappings. Source-live blockers do not block unrelated authorized root Maker work and do not close the full goal.

The required phase_handoff.py was attempted with this exclusive output path; it refused because it only writes directly under docs/codex/handoffs. Writing there would violate the assigned scope, so this handoff is directly persisted here. Exact diagnostic is in helper-attempt.log; no CURRENT update or out-of-scope write occurred. A next bounded review/fix can use this path as its seed.
