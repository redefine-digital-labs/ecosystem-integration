# Product engineering independent review attachment

This attachment references the unchanged original records/roles in `mirror/original-record-attachment.json`: DOF-008, J27/J31, C09/C12, R5, A04, E05/E06 and existing DEV/BUG/milestone references. No external record edit, reassignment or competing board. Owner/acceptance/operation responsibility remains with original records; this agent is the independent bounded read-only verifier.

User outcome: optional Channel must obtain exact consent and close actual producer authority/supply/payment/delivery. Stage Test; review terminal; candidate acceptance FAIL with activation blockers. Full goal ACTIVE157/30/1528/15 remains unchanged. Handbook v1.0 (2026-10-06), read sections1–4,9,12 and applicable5,6 payment,7,8.3–8.4. Operating Model§8 Plan→Code→Build→Test→Release→Deploy→Operate→Monitor applies; implementation/reproduction are not release/deployment.

Authority: exact freeze f415bd46c8e6ecbaae8a1e72c5464db276bd50830861bec9c59505fd272beecb; sole production agreement.mv c0209050b42986f6b1ee2580aff83f8fbc35b06c77d8bd45f2904ce54491b349. Exclusive review-directory writes. No production/actual source/keys/signatures/network transactions/permission changes/commits/remotes authorized by review.

| Domain | Conclusion/evidence | Remaining owner checks |
| --- | --- | --- |
| Management/product | FAIL for source-current acceptance/final closure; exact independent stale-statement controls | Original product/engineering owners resolve R1/R2 in a new candidate with genuine producer entrypoints |
| Agile/acceptance | Scoped review complete; original four journeys pending | Original product/SENTINEL acceptance retained |
| DevOps/build/recovery | PASS fresh pinned offline build36 VM/nine exact diagnostics; artifact exact; leave candidate unactivated | HARBOR/original release owners: CI/releases/source activation and rollback evidence |
| Payment/funds | PASS generic Coin split, Balance income, paused withdrawal and fixture cap/payment refusal | FAIL/Pending genuine producer canonical quote, original ledger/fees/delivery; actual balance/PTB readback |
| Financial model | Unactivated fixed-per-unit/FLOOR-BPS/epoch recommendations; aggregate-rounding split effect documented | Original product/economic authority decides policy; no price or revenue promise adopted |
| Common security | FAIL R1/R2 source-live requirement; linear abilities/refusal binding PASS | Producer protected A/R constructors, live Control and terminal closure; qualified external audit absent |
| EVM/DeFi | N/A; Sui-only core, no lending/AMM/token/shares model | No new EVM/DeFi roadmap commitment |
| Sui Move | PASS direct defining constructors allocate UIDs; exact typed Coin/ticket, sealed structs, persistent replay across VM transactions | Actual source origins/upgrades/old-callable/PTB/failure readback not tested |
| Governance/upgrades/locks | PASS model exact AdminCap+owner+generation handover; permissionless expiry; independent pause bits | Actual deployed cap custody, all authority paths, free-transfer/A→B→A, upgrade/current issuer, compromise/loss/exit controls |
| Operations/monitor/exit | PASS model paused income exit/revoke/expiry; no universal exit promise | Actual Coin restrictions, monitors/reconciliation/SDK/UI; regulated Coin release tests |

Assets: paid Coins, service Balance, agreements, source rights/supply/delivery and linear statements. Service owner offers/authorizes/pauses/withdraws with bound Cap/current sender; source principal consents/revokes/suspends; source issuer alone should validate actual Control and fulfill canonical business. Proof nominal identity does not audit constructors or grant Source rights. History events are query evidence, not authorization.

Formula: gross=gross_per_unit×quantity checked u128→u64; service=floor(gross×BPS/10000); producer=gross−service. Example splitting q2 versus q1+q1 at per-unit1/BPS5000 changes commission1→0. No new refunds, price caps,50-BPS steps, source supply authority or lock promises. Original additive CEIL/native FLOOR obligations remain authoritative and uncomposed by this candidate.

| Power | Actual model controller | Constraints/exits | Unverified effective deployment |
| --- | --- | --- | --- |
| Service offer/pause/withdraw/handover | Current Instance owner and exact AdminCap | Owner sender; Cap instance; revision; handover generation; withdraw possible while paused | Cap custody, all packaging/upgrade/multisig/timelock paths; loss/compromise drill |
| Accept | Offered principal sender plus A SourceState | Exact terms/CAS/expiry; R1 stale snapshot gap | Genuine current source Control and protected acceptance consumer |
| Agreement revoke/suspend/resume | Consenting principal/agent | CAS; own reason only; terminal cannot resume | Live transfers and actual governance integration |
| Business production/fulfillment | Defining Source module issuer | Exact selected A/R nominal roles and linear values | Constructor/actual source-current/canonical settlement/delivery; R2 stale completion gap |

2026-10-11 Build/Test: mirror verification PASS36/9/exact artifact; independent adversarial combined39 PASS includes two undesired successes proving FAIL; cross-transaction replay guard PASS.22/25 external pins unchanged; three Maker metadata/manifests attributed by Root to separate627-op activation, exact expected/observed SHA retained. Frozen candidate245 files unchanged before/after.

Release/Deploy/Operate/Monitor are pending, not performed. No deployed multisig, timelock, immutable package, asset lock, recovery backdoor or current live chain governance is proven. Existing service pauses and linear obligations do not imply these controls. Review exit: Root repairs R1/R2 plus real producer adapter/payment closure in NEW candidate; original owners remain responsible for policy and journey acceptance. Leave v1 unactivated. This attachment does not authorize activation, publication, spending or irreversible changes.
