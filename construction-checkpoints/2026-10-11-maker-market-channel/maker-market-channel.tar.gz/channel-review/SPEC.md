# Channel runtime independent read-only review v1

Bounded objective: independently review frozen Channel candidate v1 against F09/F11/F16 and D27–D29, reproduce its production build/36 VM tests/nine precise foreign refusals using the pinned CLI without keys or network, and challenge source-current acceptance/final closure. Record exact candidate identity, bindings, economic choices, producer limits, remaining work and handbook attachment. This is not activation approval or full157/30 acceptance.

Candidate manifest SHA256: `f415bd46c8e6ecbaae8a1e72c5464db276bd50830861bec9c59505fd272beecb`; production artifact SHA256: `c0209050b42986f6b1ee2580aff83f8fbc35b06c77d8bd45f2904ce54491b349`.

Exclusive write scope is this new sibling directory. Candidate/actual source, original owners/records/CURRENT, full project goal, keys, retained chain, permission policy and remote state remain unchanged. No signatures, publication, commits, messages to other chats or product policy decisions are authorized by this review.

Method: verify all245 frozen files; copy only the explicit public frozen closure into a fresh mirror; inspect core/tests/probes and frozen documentation; rerun exact verification; add adversarial tests only in a separate review-owned copy; reverify candidate integrity; freeze terminal report and evidence. The existing original record attachment is copied exactly into the mirror and referenced by the review attachment, without external record edits or a new board.
