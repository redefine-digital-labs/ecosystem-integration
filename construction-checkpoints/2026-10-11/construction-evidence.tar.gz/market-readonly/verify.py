from pathlib import Path
import json, hashlib, re, difflib

C=Path(__file__).parent.parent/'independent-market-current-candidate-v1'
R=Path(__file__).parent
O=Path('/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-market')
U=Path('/Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/application-manifest-read-candidate/frozen')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def hashes(root, mapping):
    bad=[]
    for n,h in mapping.items():
        p=root/n
        if not p.is_file() or sha(p)!=h: bad.append(n)
    return {'checked':len(mapping),'mismatches':bad}
E={}; I=read(C/'inputs.json'); F=read(C/'frozen/manifest.json'); V=read(C/'root-market-runtime-verification.json')
E['pins']={'candidate_manifest':sha(C/'frozen/manifest.json'),'candidate_expected':'3225bc37f9812b9b6ef4dd0f4c8521132096b58ab16982e5a5f461fcc2920104','upstream_manifest':sha(U/'manifest.json'),'upstream_expected':I['frozen_manifest_sha256']}
E['upstream']=hashes(U/'inputs',I['frozen_inputs'])
E['old_market']=hashes(O,I['market_baseline'])
E['metadata']={}
for k,n in [('successful_production_result','003-production/result.json'),('successful_market44_result','005-market44/result.json'),('source_preparation','inputs.json'),('alias_repair','round02-source-fix.json'),('player_bridge','fixture-player-bridge.json')]:
    E['metadata'][n]={'expected':F[k],'actual':sha(C/n),'match':F[k]==sha(C/n)}
E['freeze']={}
frozen_inodes=[]
for g,m in F['graphs'].items():
    a=hashes(C/g,m); b=hashes(C/'frozen'/g,m)
    shared=[];nonordinary=[]
    for n in m:
        p=C/g/n;q=C/'frozen'/g/n
        frozen_inodes.append((q.stat().st_dev,q.stat().st_ino))
        if p.is_symlink() or q.is_symlink():nonordinary.append(n)
        if (p.stat().st_dev,p.stat().st_ino)==(q.stat().st_dev,q.stat().st_ino):shared.append(n)
    initial=I['production_inputs' if g=='production-graph' else 'test_inputs']
    reconciled=dict(initial)
    for ledger in ['round02-source-fix.json','fixture-player-bridge.json']:
        for row in read(C/ledger):
            if row['path'].startswith(g+'/'):
                key=row['path'][len(g)+1:]
                assert reconciled[key]==row['old_sha256']
                reconciled[key]=row['new_sha256']
    E['freeze'][g]={'current':a,'frozen':b,'shared_inodes':shared,'nonordinary':nonordinary,'input_ledger_match':m==initial,'initial_ledger_deltas':[n for n,h in m.items() if initial.get(n)!=h],'initial_plus_repair_ledgers_exact':m==reconciled}
    E['freeze'][g]['manifest_exact_file_set']=set(m)=={str(p.relative_to(C/'frozen'/g)) for p in (C/'frozen'/g).rglob('*') if p.is_file()}
E['all_frozen_inodes_unique']=len(frozen_inodes)==len(set(frozen_inodes))
other_inodes={(p.stat().st_dev,p.stat().st_ino) for g,m in F['graphs'].items() for n in m for p in [C/g/n]}
other_inodes|={(p.stat().st_dev,p.stat().st_ino) for n in I['frozen_inputs'] for p in [U/'inputs'/n]}
E['all_frozen_inodes_disjoint_live_and_upstream']=not (set(frozen_inodes)&other_inodes)
E['source_change_ledger']=[{'path':row['path'],'old_utf8_hash_exact':hashlib.sha256(row['old_utf8'].encode()).hexdigest()==row['old_sha256'] if 'old_utf8' in row else None,'new_utf8_hash_exact':hashlib.sha256(row['new_utf8'].encode()).hexdigest()==row['new_sha256'] if 'new_utf8' in row else None,'new_pin_in_initial_ledger':I['production_inputs'].get(row['path'])==row['new_sha256']} for row in I['source_changes']]

old=(O/'move/soulidity_market/sources/market.move').read_text();new=(C/'production-graph/market/sources/market.move').read_text()
def without_imports(s):return re.sub(r'^use .*;\n','',s,flags=re.M)
E['market_source']={'sha_old':sha(O/'move/soulidity_market/sources/market.move'),'sha_new':sha(C/'production-graph/market/sources/market.move'),'all_non_import_bytes_equal':without_imports(old)==without_imports(new),'production_test_graph_exact':new==(C/'test-graph/market/sources/market.move').read_text(),'production_functions':re.findall(r'^(?:public(?:\(package\))? )?fun (\w+)',old.split('/// Exercise the actual private market role')[0],re.M),'diff':''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='canonical-old-Market',tofile='current-Market'))}
prod=old.split('/// Exercise the actual private market role')[0]
E['market_source']['public_production_functions']=re.findall(r'^public fun (\w+)',prod,re.M)
E['market_source']['nominal_provider_changes']={'Control,Product':'soulidity_v1::catalog -> soulidity_maker_manufacturing::maker_catalog','Snapshot,Receipt':'soulidity_application::resale -> soulidity_maker_terms::maker_resale','Account (tests only)':'soulidity_v1::custody -> soulidity_custody::account'}
E['market_source']['nominal_affected_public_functions']=['list_control','control_quote','control_quote_hash','buy_control','rights','settlement','soul_quote','collection_quote']
E['market_source']['nominal_affected_structs']=['Listing.rights','Listing.settlement','ListingDeleted.settlement','SoulQuote.receipt']
E['market_source']['published_compatibility']=False
E['test_source_diffs']={}
for p in (O/'move/soulidity_market/tests').glob('*.move'):
    q=C/'test-graph/market/tests'/p.name
    E['test_source_diffs'][p.name]=''.join(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True)))
E['scope_omissions']={'count':len(I['scope_omissions']),'exact_difference':set(I['frozen_inputs'])-set(I['copied_inputs'])=={x['relative'] for x in I['scope_omissions']},'all_pinned':all(I['frozen_inputs'][x['relative']]==x['sha256'] for x in I['scope_omissions']),'old_market_absent':all(not (C/g/'deps/move/soulidity_v1/sources/market.move').exists() for g in F['graphs']),'core_fixture_files':sorted(p.name for p in (C/'test-graph/deps/move/soulidity_v1/tests').glob('*.move'))}
E['upstream_copy_changes']=[]
for n in I['copied_inputs']:
    p=C/'production-graph/deps'/n
    if p.exists() and sha(p)!=I['copied_inputs'][n]:E['upstream_copy_changes'].append(n)
fixture=C/'production-graph/deps/move/soulidity_v1/tests/fixtures.move'
orig=(U/'inputs/move/soulidity_v1/tests/fixtures.move').read_text()
E['fixture_bridge_diff']=''.join(difflib.unified_diff(orig.splitlines(True),fixture.read_text().splitlines(True)))
E['transports']={'addresses':I['test_addresses'],'distinct_count':len(set(I['test_addresses'].values())),'diffs':{},'all_only_address_sections':True}
for t in I['test_address_transports']:
    a=C/'production-graph'/t['path'];b=C/'test-graph'/t['path'];ta=a.read_text();tb=b.read_text()
    def noaddress(s):return re.sub(r'\[addresses\][\s\S]*?(?=\n\[|\Z)','',s)
    E['transports']['diffs'][t['path']]={'pinned':sha(a)==t['old_sha256'] and sha(b)==t['new_sha256'],'only_address_section':noaddress(ta)==noaddress(tb)}
    E['transports']['all_only_address_sections'] &= noaddress(ta)==noaddress(tb)

def graph(g,dev):
    root=C/g; visiting=[];seen={};bad=[];edges={}
    def walk(p):
        p=p.resolve()
        if p in visiting:bad.append({'cycle':[str(x) for x in visiting]+[str(p)]});return
        if p in seen:return
        if not p.is_file():bad.append({'missing':str(p)});return
        if root not in p.parents:bad.append({'escaped':str(p)});return
        txt=p.read_text();name=re.search(r'^name\s*=\s*"([^"]+)"',txt,re.M)[1];seen[p]=name;visiting.append(p);edges[name]=[]
        section=''
        for line in txt.splitlines():
            if line.startswith('['):section=line
            if section not in (['[dependencies]','[dev-dependencies]'] if dev else ['[dependencies]']):continue
            m=re.search(r'local\s*=\s*"([^"]+)"',line)
            if m:
                if Path(m[1]).is_absolute():bad.append({'absolute_local':str(p),'value':m[1]})
                q=(p.parent/m[1]/'Move.toml').resolve();edges[name].append(str(q.relative_to(root)) if root in q.parents else str(q));walk(q)
        visiting.pop()
    walk(root/'market/Move.toml')
    return {'packages':{str(p.relative_to(root)):n for p,n in seen.items()},'edges':edges,'errors':bad}
E['dag']={g:graph(g,g=='test-graph') for g in F['graphs']}

def mv_identity(p):
    d=p.read_bytes()
    def u(i):
        n=0;s=0
        while True:
            b=d[i];i+=1;n|=(b&127)<<s
            if b<128:return n,i
            s+=7
    pos=9;tables={}
    for _ in range(d[8]):
        k=d[pos];pos+=1;o,pos=u(pos);s,pos=u(pos);tables[k]=(o,s)
    base=pos;ids=[];i=base+tables[7][0];end=i+tables[7][1]
    while i<end:
        n,i=u(i);ids.append(d[i:i+n].decode());i+=n
    handles=[];i=base+tables[1][0];end=i+tables[1][1]
    while i<end:a,i=u(i);n,i=u(i);handles.append((a,n))
    x=base+max(o+s for o,s in tables.values());selfidx,_=u(x);a,n=handles[selfidx]
    ad=d[base+tables[8][0]+32*a:base+tables[8][0]+32*(a+1)]
    return {'address':hex(int.from_bytes(ad,'big')),'module':ids[n],'sha256':sha(p)}
E['runs']={}
pat=re.compile(r'\[\s*(PASS|FAIL)\s*\]\s+([^\s]+)')
oldlog=O/'evidence/extraction-original/market-tests-final.log';oldids={i:s for s,i in pat.findall(oldlog.read_text())}
for n,g in [('003-production','production-graph'),('005-market44','test-graph')]:
    j=read(C/n/'result.json');log=C/n/'raw.log';rec=V[n];b=C/n/'build/build/SoulidityMarket';module_files=list((b/'bytecode_modules').rglob('*.mv'))
    actual_modules={str(p.relative_to(C)):sha(p) for p in module_files}
    snapshots=list((b/'sources').rglob('*.move'));sourcehashes=set(j['source_before'].values())
    mismatch=[str(p.relative_to(C)) for p in snapshots if sha(p) not in sourcehashes]
    package_roots={}
    for manifest,name in E['dag'][g]['packages'].items():package_roots.setdefault(name,[]).append((C/g/manifest).parent)
    package_hashes={}
    for package,roots in package_roots.items():
        index={}
        for root in roots:
            for folder in ['sources','tests']:
                for q in (root/folder).rglob('*.move'):index.setdefault(sha(q),[]).append(q)
        package_hashes[package]=index
    source_locations={};location_bad=[]
    for p in snapshots:
        parts=p.relative_to(b/'sources').parts
        package=parts[1] if parts[0]=='dependencies' else 'SoulidityMarket'
        # The compiler saves a source under its module name; original filenames may differ.
        candidates=package_hashes.get(package,{}).get(sha(p),[])
        source_locations[str(p.relative_to(C))]=[str(q.relative_to(C)) for q in candidates]
        if not candidates:location_bad.append(str(p.relative_to(C)))
    runtime={i:s for s,i in pat.findall(log.read_text())}
    current_hash_bad=hashes(C/g,j['source_after'])
    E['runs'][n]={'command':j['command'],'exit_code':j['exit_code'],'summaries':j['summaries'],'overrides':j['overrides'],'result_pin':sha(C/n/'result.json')==rec['result_sha256'],'log_pin':sha(log)==rec['log_sha256']==j['raw_log_sha256'],'source_before_after_equal':j['source_before']==j['source_after'],'source_snapshot_current_check':current_hash_bad,'installed_guard':hashes(Path('/'),j['installed_before']),'input_drift':j['input_drift'],'installed_drift':j['installed_drift'],'module_count':len(module_files),'module_hash_snapshot_exact':actual_modules==rec['modules'],'generated_locks':hashes(C,rec['generated_locks']),'compiled_source_count':len(snapshots),'compiled_source_unmatched':mismatch,'binary_module_identities':{str(p.relative_to(C)):mv_identity(p) for p in module_files},'identities':runtime,'raw_identity_matches_result':runtime==j['identities'],'raw_identity_matches_old44':runtime==oldids if n=='005-market44' else None,'build_info_sha256':sha(b/'BuildInfo.yaml'),'raw_log_sha256':sha(log)}
    E['runs'][n]['compiled_source_package_locations']=source_locations
    E['runs'][n]['compiled_source_package_location_unmatched']=location_bad
E['old44']={'raw_log_sha256':sha(oldlog),'count':len(oldids),'all_pass':set(oldids.values())=={'PASS'}}
origins={}
for p,m in E['runs']['005-market44']['binary_module_identities'].items():
    parts=p.split('/');package=parts[parts.index('dependencies')+1] if 'dependencies' in parts else 'SoulidityMarket'
    origins.setdefault(package,set()).add(m['address'])
actual=set().union(*origins.values());allocated=set(I['test_addresses'].values())
E['compiled_test_origins']={'package_self_addresses':{p:sorted(v) for p,v in origins.items()},'allocated_original_addresses':len(allocated),'allocated_addresses_present':len(actual&allocated),'allocated_addresses_absent':{n:a for n,a in I['test_addresses'].items() if a not in actual},'actual_addresses_from_bytecode':sorted(actual)}
E['failed_attempts']={}
for n in ['001-production','004-market44']:
    j=read(C/n/'result.json');log=(C/n/'raw.log').read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',log)
    E['failed_attempts'][n]={'exit_code':j['exit_code'],'raw_log_sha256':sha(C/n/'raw.log'),'raw_log_pinned':sha(C/n/'raw.log')==j['raw_log_sha256'],'primary_diagnostics':re.findall(r'^error\[[^\]]+\]:[^\n]+',clean,re.M),'identities_count':len(pat.findall(clean))}
E['fixture_before_production_vs_test']={'production':read(C/'003-production/result.json')['source_before']['deps/move/soulidity_v1/tests/fixtures.move'],'test':read(C/'005-market44/result.json')['source_before']['deps/move/soulidity_v1/tests/fixtures.move'],'current':sha(fixture),'production_current_only_delta':[n for n,h in read(C/'003-production/result.json')['source_before'].items() if sha(C/'production-graph'/n)!=h]}
H=Path('/Users/naoer/Documents/Claude/Projects/soulidity/agent-management')
E['governance']={'original_records':['DOF-001','P01','P09'],'stage':'Code/Build/Test scoped candidate independent evidence review','status':'in-progress; not installed; full goal remains active','handbook_version':'1.0 (2026-10-06)','sections_read':[1,2,3,4,5,6,7,8,9,10,11,12],'applicable_sections':[1,2,3,4,5,6,7,'8.3','8.4',9,10,11,12],'handbook_sha256':sha(H/'PRODUCT_ENGINEERING_HANDBOOK_CN.md'),'operating_model_section':8,'operating_model_sha256':sha(H/'OPERATING_MODEL.md'),'review_template_sha256':sha(H/'templates/product-engineering-review.md'),'release_deploy_operate_monitor':'not performed; current scope/source review and retained local execution evidence only','owner_and_authorization':'existing original record owners and authorization remain unchanged; no external messages/commits/push/PR/deploy/signature/installation'}
(R/'evidence.json').write_text(json.dumps(E,indent=2)+'\n')
print(json.dumps({'pins':E['pins'],'upstream':E['upstream'],'old_market':E['old_market'],'freeze':E['freeze'],'non_import_equal':E['market_source']['all_non_import_bytes_equal'],'production_function_count':len(E['market_source']['production_functions']),'omissions':E['scope_omissions'],'upstream_copy_changes':E['upstream_copy_changes'],'transports_ok':E['transports']['all_only_address_sections'],'dag_errors':{g:x['errors'] for g,x in E['dag'].items()},'runs':{n:{k:v for k,v in r.items() if k not in ['binary_module_identities','identities','command','compiled_source_package_locations']} for n,r in E['runs'].items()},'bridge':E['fixture_before_production_vs_test']},indent=2))
