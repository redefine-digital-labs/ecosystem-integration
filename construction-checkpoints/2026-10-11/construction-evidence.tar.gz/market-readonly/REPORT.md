# Independent current Market: bounded source and retained-execution review

**SOURCE_PASS / BUILD_EVIDENCE_PASS / MARKET44_EVIDENCE_PASS; NOT_INSTALL_READY; full objective remains in progress.** No actionable regression found in this Market nominal-source adaptation. This independent AI review inspected source, hashes, ordinary-file identities, dependency locators, compiled source snapshots, Move bytecode identities and raw logs. Reviewer ran no compiler, Move VM, node, network, RPC or chain transaction. It does not constitute an external audit, installation approval or fresh execution.

Candidate: sibling `independent-market-current-candidate-v1`, frozen manifest SHA-256 `3225bc37f9812b9b6ef4dd0f4c8521132096b58ab16982e5a5f461fcc2920104`. Diagnostic upstream final Application manifest: `010b1ccae2b2f01e5378008abf48c901d3b77b93954bcc79ad4fc5c45dffe129`. Canonical old Market: `/Users/naoer/Documents/Claude/Projects/soulidity-ecosystem/soul-market`. Machine-readable details, diffs and every decoded module identity are in [evidence.json](evidence.json); [verify.py](verify.py) reproduces the read-only checks and writes only this review's evidence.

## Exact source and input checks

- All 1,667 upstream inputs and six canonical old Market source/metadata inputs match their declared hashes. Both graph copies and both frozen graph copies match all 1,614 entries each. The frozen manifest contains exactly 3,228 graph files; every frozen file has a unique inode, and no frozen file aliases its corresponding working input. No symlinks were found in these entries.
- `inputs.json` is the initial preparation ledger. In each graph its initial hashes differ from the final manifest only for the Market import-alias repair and the Core test-only Player bridge. Applying `round02-source-fix.json`, then `fixture-player-bridge.json`, reconciles the exact final graph with no additional difference. All repair/result/lock/metadata pins match. The initial ledger alone is not a final input authority.
- Old Core production `market.move` and 58 Core test files are omitted only from the scoped dependency copies. The omission list is exactly the difference between the upstream and copied input sets, and all 59 omission hashes match the upstream. Core `tests` retains only `fixtures.move` and `storage_fixture.move`; this candidate does not run the whole Core test suite. Original sources and the 181 guarded installed inputs remain hash-exact.
- Relative local dependency traversal is acyclic, stays inside each scoped graph and resolves all locators. The root explicitly pins the framework overrides. Test graph differences are confined to address sections across 21 metadata transports. The 20 allocated Soulidity addresses are distinct.

## Source semantics and nominal compatibility

After removing import lines, **every remaining byte of the current Market source is identical to canonical old Market**. All 44 production function bodies, including all 35 public production functions, the private Collection helper, structs, events, layout text and test-only Market bridges are unchanged. The production and test graph Market source files are byte-identical. The four original test files and their 44 test identities are retained. Test differences are nominal imports and two expected-failure locations moved to the authentic Terms provider; no test body/assertion was weakened.

The production import changes are:

| Existing local name | Old source provider | Current source provider |
| --- | --- | --- |
| `Control`, `Product` | `soulidity_v1::catalog` | `soulidity_maker_manufacturing::maker_catalog` |
| `catalog` functions | `soulidity_v1::catalog` | same thin downstream facade |
| `resale`, `Snapshot`, `Receipt` | `soulidity_application::resale` | `soulidity_maker_terms::maker_resale`, preserving the `resale` alias |
| Test `Account` | `soulidity_v1::custody` | `soulidity_custody::account`; custody functions retain the existing facade |

Nominal origins affect effective public types even though declaration text and function bodies are preserved. Specifically, `list_control`, `control_quote`, `control_quote_hash`, `buy_control` consume the authentic Maker types; `rights`, `settlement`, `soul_quote`, `collection_quote` return authentic Terms values. Embedded `Listing.rights`, `Listing.settlement`, `ListingDeleted.settlement` and `SoulQuote.receipt` also change nominal provider. This is unpublished current-source adaptation, **not old published ABI/type/storage compatibility**.

The initial scoped Core fixture adds a test-only generic role setup. Market constructs its private `MarketAuthority1` / `MarketRevision3` values and passes them to that setup; it binds Config role 3, genuine Maker catalog/release roles, PaidAccess and Collection roles before actual native-binding installation and initial enable. The extra Player helper is a thin delegate to `soulidity_v1::player::create_for_testing` inside the module marked `#[test_only]`. It introduces no production declaration or authority export.

## Preserved duties and limits

| Duty | Source and actual retained-test evidence | Conclusion within this scope |
| --- | --- | --- |
| Actual Market authority and revision | `register` still requires Publisher/UpgradeCap through Config/Admin/revision/commitment registration; all settlements construct current private role values. `core_market_role_does_not_authorize_independent_market` passes. | Preserved; deployed role/Cap custody remains pending. |
| Primary/Secondary/global gates, quote CAS and buyer binding | Existing `assert_secondary_live`, Secondary quote checks, protocol IDs, manifests, revision, expiry and actual buyer bindings remain. Original gate/replay/admin/stale/buyer tests pass. | Preserved; no budget or policy overrides. |
| Real fees and payment | Authentic MakerTerms recomputes receipt amounts and recipients, checks role 3/current revision/Secondary/payment exactness, deposits actual income and pays actual Coin. Gross shares use FLOOR; Collection additions use per-component CEIL. Maker/Item settlement retains actual economics settlement. | Preserved; failed payment and recipient/accounting tests pass. |
| Collection rights | Helper still requires protocol equality, Soul Collection ID equality and actual membership. Current Right holder is re-quoted; snapshot and combined-fee checks remain. | Preserved; no new metadata restrictions or floor-price gate. |
| Whole Soul inventory, grants and Vault | Sales retain manifest/rights checks, `clear_authorizations`, and Vault `prepare_handover` before settlement/transfer. Existing tests verify unmounted Bound assets, Free original IDs, grants, tool money/assets, cancellation and whole sale. The unchanged Vault helper rotates known native-tree scopes with depth 16/node 256 bounds. | Preserved current native behavior; arbitrary protected-source `StandardHandover` closure is pending. |
| Safe exit and terminal cleanup | Seller cancellation retains same asset ID; permissionless cleanup requires terminal state and absent escrow, retains exact event/receipt evidence, and avoids Config gates. Income withdrawal retains Admin/recovery/revenue checks independent of operational pause. | Preserved; original cancel/third-wallet cleanup/disabled-lanes/funds-exit tests pass. |

Unknown source protocols, private content/KMS rights and arbitrary extension obligations are not proven by current native grant/Vault handling. Market remains coupled to the actual selected Core/Application/Collection/Model/Config/Terms types and duties. This pass does not establish full-format independence or arbitrary-source settlement support.

## Retained actual Root execution

| Run | Evidence checked | Result |
| --- | --- | --- |
| `003-production` | exact result/raw-log hashes, default command without overrides, before/after input snapshots, BuildInfo `test_mode: false`, 194 compiled source snapshots and all 194 module hashes, one generated Move.lock | exit 0; production source closure matches current production input |
| `005-market44` | exact result/raw-log hashes, default test command without overrides, before/after snapshots, BuildInfo `test_mode: true`, 348 compiled source snapshots and all 348 module hashes | actual 44 PASS / 0 FAIL; every raw identity/status equals both result.json and canonical old final raw log |

`003-production` ran before the added Player fixture delegate. The only difference between that run's source snapshot and the current production graph is this test-only fixture file. All 194 compiled production source snapshots are exact members of the recorded production source inputs; no production source/module changed. The final test run uses the completed fixture hash and matches current test inputs without differences. All 181 current installed-file guards still match both run snapshots.

Raw bytecode self-address decoding confirms independent Market at `0x10d`, MakerManufacturing at `0x109`, MakerTerms at `0x10c`, Custody at `0x106`, and Core at `0x113`. **18 of the 20 allocated original Soulidity addresses occur in the actual compiled test closure.** `soulidity = 0x101` and `soulidity_maker_soul_adapter = 0x10b` are allocated metadata addresses but absent from compiled modules. Describe this as a 20-distinct-address test graph, not 20 effective compiled package origins. Foreign fixtures, framework and Walrus add separate origins; their full decoded identities remain in evidence.json.

Failed `001-production` alias compilation (`EC03006`) and `004-market44` missing Player fixture (`EC03003`) remain retained and hash-pinned. Neither reached business tests, and neither is a demonstrated business rejection. Later successful results do not erase those preparation failures.

## Existing work-item attachment: DOF-001 / P01 / P09

This report is an evidence attachment for the existing records; it creates no competing task board, changes no Owner/status and sends no external message. Original implementation, integration, release and operation responsibility remains with the existing owners.

- Stage: scoped Code/Build/Test verification. Status: **in progress**. Implemented and verified here: current Market nominal-source adaptation and retained actual local build/44-test evidence. Released/Deployed/Adopted: **not performed**.
- Handbook: version 1.0, updated 2026-10-06; SHA `1972858dffa38006f1d3784bcaca9370c52bdebade730b20bb0294b42125ec95`. Mandatory sections 1–4, 9, 12 read; applicable specialist sections 5–7, 8.3–8.4, 10–11 read. Operating Model section 8 applied; hashes and review-template identity recorded in evidence.json.
- Management/product/Agile: PASS for bounded candidate/source/evidence scope; no parent-goal completion. DevOps Build/Test: PASS for retained exact local execution; Release/Deploy/Operate/Monitor: pending and outside this reviewer execution.
- Payment/accounting and common contract/Sui source checks: PASS for preserved duties and original 44 local scenarios. Full live economic/authority/security assurance: pending. EVM, borrowing/AMM/yield/share-model analysis: N/A to this Market nominal adaptation; no new financial roadmap.
- Governance/locks: actual deployed Publisher/latest UpgradeCap, old/new callable authority, role registration, recovery and chain activation are pending. No multisig/timelock/immutability deployment claim. Sui object coordination is not a governance lock. Deployment authorization is unchanged.
- Release exit conditions remain: coherent original Core/default-budget regressions (upstream actual 1060/1062 leaves two failures), arbitrary protected-source StandardHandover closure, final B0 exact configuration/origins/Publisher/latestCap/consumer combinations, real PTBs/chain readback, SDK/original UI activation and remaining original duties. This scoped Market pass cannot close those checks or authorize installation of diagnostic upstream inputs.
- Recovery: retain canonical old Market and all upstream/frozen evidence; current sources and installed guard inputs were not changed by this reviewer. No chain rollback is asserted.

Review write scope was only this new review directory. No source/CURRENT writes, commits, pushes, PRs, installs, signatures, spending, deployments or VM runs occurred.
