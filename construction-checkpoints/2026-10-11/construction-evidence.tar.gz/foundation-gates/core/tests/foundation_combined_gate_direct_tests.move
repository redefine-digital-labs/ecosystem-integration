#[test_only]
module soulidity_v1::foundation_combined_gate_direct_tests;
use sui::test_scenario::{Self,Scenario};
use sui::clock::{Self,Clock};
use std::bcs;
use soulidity_foundation::economics::{Self,Config,Admin,Authority};
use soulidity_v1::native_binding::{Self,NativeInstaller1,NativeRevision2};
use soulidity_maker_manufacturing::maker_catalog::{CreatorAuthority1,CreatorRevision2,CreatorRevision3};
public struct USD has drop {}
fun setup():(Scenario,Config<USD>,Admin,Clock){
 let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);
 let a:Authority=sc.take_from_sender();let id=native_binding::create_enabled_for_testing<USD>(&a,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(a);sc.next_tx(@0xa);
 let c:Config<USD> =sc.take_shared_by_id(id);let a:Admin=sc.take_from_sender();let clock=clock::create_for_testing(sc.ctx());native_binding::assert_current(&c);(sc,c,a,clock)
}
fun finish(sc:Scenario,c:Config<USD>,a:Admin,clock:Clock){clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.return_to_sender(a);sc.end();}
fun old_live(c:&Config<USD>,revision:u64,expiry:u64,clock:&Clock){economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision3>(c,2);economics::assert_live(c,revision,expiry,clock);economics::assert_primary(c)}
fun new_live(c:&Config<USD>,revision:u64,expiry:u64,clock:&Clock){economics::assert_role_primary_live<USD,CreatorAuthority1,CreatorRevision3>(c,2,revision,expiry,clock)}
fun old_snapshot(c:&Config<USD>,id:ID,revision:u64,hash:vector<u8>){economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision3>(c,2);economics::assert_primary_snapshot(c,id,revision,hash)}
fun new_snapshot(c:&Config<USD>,id:ID,revision:u64,hash:vector<u8>){economics::assert_role_primary_snapshot<USD,CreatorAuthority1,CreatorRevision3>(c,2,id,revision,hash)}
#[test]
fun valid_equivalent_current_native_and_exact_snapshot(){let(sc,c,a,clock)=setup();let before=bcs::to_bytes(&economics::operational_snapshot(&c));old_live(&c,0,0,&clock);new_live(&c,0,0,&clock);old_snapshot(&c,object::id(&c),0,economics::commitment(&c));new_snapshot(&c,object::id(&c),0,economics::commitment(&c));native_binding::assert_current(&c);assert!(before==bcs::to_bytes(&economics::operational_snapshot(&c)),0);finish(sc,c,a,clock)}
#[test]
fun valid_equivalent_at_exact_expiry_and_secondary_off(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_secondary_enabled(&mut c,&mut a,0,cas_hash,false);clock::increment_for_testing(&mut clock,1000);old_live(&c,1,1000,&clock);new_live(&c,1,1000,&clock);old_snapshot(&c,object::id(&c),1,economics::commitment(&c));new_snapshot(&c,object::id(&c),1,economics::commitment(&c));assert!(!economics::secondary_enabled(&c) && economics::primary_enabled(&c),0);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);old_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);new_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_primary_off(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_primary_enabled(&mut c,&mut a,0,cas_hash,false);old_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_primary_off(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_primary_enabled(&mut c,&mut a,0,cas_hash,false);new_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_stale_revision(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,false);old_live(&c,0,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_stale_revision(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,false);new_live(&c,0,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_paused(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,true);old_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_paused(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,true);new_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);old_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);new_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_minimum_release_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::raise_minimum_for_testing(&mut c,3);old_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_minimum_release_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::raise_minimum_for_testing(&mut c,3);new_live(&c,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=3,location=soulidity_foundation::economics)]
fun old_live_expired(){let(sc,mut c,mut a,mut clock)=setup();clock::increment_for_testing(&mut clock,1001);old_live(&c,0,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=3,location=soulidity_foundation::economics)]
fun new_live_expired(){let(sc,mut c,mut a,mut clock)=setup();clock::increment_for_testing(&mut clock,1001);new_live(&c,0,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=3,location=soulidity_foundation::economics)]
fun old_live_primary_off_and_expired(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_primary_enabled(&mut c,&mut a,0,cas_hash,false);clock::increment_for_testing(&mut clock,1001);old_live(&c,1,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=3,location=soulidity_foundation::economics)]
fun new_live_primary_off_and_expired(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_primary_enabled(&mut c,&mut a,0,cas_hash,false);clock::increment_for_testing(&mut clock,1001);new_live(&c,1,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_stale_and_expired(){let(sc,mut c,mut a,mut clock)=setup();clock::increment_for_testing(&mut clock,1001);old_live(&c,1,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_stale_and_expired(){let(sc,mut c,mut a,mut clock)=setup();clock::increment_for_testing(&mut clock,1001);new_live(&c,1,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_disabled_and_expired(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);clock::increment_for_testing(&mut clock,1001);old_live(&c,1,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_disabled_and_expired(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);clock::increment_for_testing(&mut clock,1001);new_live(&c,1,1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun old_live_old_role_marker(){let(sc,mut c,mut a,mut clock)=setup();economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);economics::assert_live(&c,economics::revision(&c),1000,&clock);economics::assert_primary(&c);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun new_live_old_role_marker(){let(sc,mut c,mut a,mut clock)=setup();economics::assert_role_primary_live<USD,CreatorAuthority1,CreatorRevision2>(&c,2,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun old_live_old_role_and_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);economics::assert_live(&c,economics::revision(&c),1000,&clock);economics::assert_primary(&c);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun new_live_old_role_and_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);economics::assert_role_primary_live<USD,CreatorAuthority1,CreatorRevision2>(&c,2,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun old_live_old_role_and_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);economics::assert_live(&c,economics::revision(&c),1000,&clock);economics::assert_primary(&c);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun new_live_old_role_and_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);economics::assert_role_primary_live<USD,CreatorAuthority1,CreatorRevision2>(&c,2,economics::revision(&c),1000,&clock);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);old_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);new_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_primary_off(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_primary_enabled(&mut c,&mut a,0,cas_hash,false);old_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_primary_off(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_primary_enabled(&mut c,&mut a,0,cas_hash,false);new_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_stale_revision(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,false);old_snapshot(&c,object::id(&c),0,economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_stale_revision(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,false);new_snapshot(&c,object::id(&c),0,economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_paused(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,true);old_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_paused(){let(sc,mut c,mut a,mut clock)=setup();economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,true);new_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);old_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);new_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_minimum_release_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::raise_minimum_for_testing(&mut c,3);old_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_minimum_release_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::raise_minimum_for_testing(&mut c,3);new_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_wrong_config(){let(sc,mut c,mut a,mut clock)=setup();old_snapshot(&c,object::id_from_address(@0xdead),0,economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_wrong_config(){let(sc,mut c,mut a,mut clock)=setup();new_snapshot(&c,object::id_from_address(@0xdead),0,economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_wrong_commitment(){let(sc,mut c,mut a,mut clock)=setup();old_snapshot(&c,object::id(&c),0,vector[0]);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_wrong_commitment(){let(sc,mut c,mut a,mut clock)=setup();new_snapshot(&c,object::id(&c),0,vector[0]);finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun old_snapshot_old_role_marker(){let(sc,mut c,mut a,mut clock)=setup();economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);economics::assert_primary_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun new_snapshot_old_role_marker(){let(sc,mut c,mut a,mut clock)=setup();economics::assert_role_primary_snapshot<USD,CreatorAuthority1,CreatorRevision2>(&c,2,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun old_snapshot_old_role_and_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);economics::assert_primary_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun new_snapshot_old_role_and_disabled(){let(sc,mut c,mut a,mut clock)=setup();let cas_hash=economics::commitment(&c);economics::set_enabled(&mut c,&mut a,0,cas_hash,false);economics::assert_role_primary_snapshot<USD,CreatorAuthority1,CreatorRevision2>(&c,2,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun old_snapshot_old_role_and_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);economics::assert_primary_snapshot(&c,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=2,location=soulidity_foundation::package_roles)]
fun new_snapshot_old_role_and_callable_drift(){let(sc,mut c,mut a,mut clock)=setup();economics::drift_callable_for_testing(&mut c);economics::assert_role_primary_snapshot<USD,CreatorAuthority1,CreatorRevision2>(&c,2,object::id(&c),economics::revision(&c),economics::commitment(&c));finish(sc,c,a,clock)}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_live_missing_native_binding(){let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);let authority:Authority=sc.take_from_sender();let id=native_binding::create_config_for_testing<USD>(&authority,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(authority);sc.next_tx(@0xa);let c:Config<USD> =sc.take_shared_by_id(id);let clock=clock::create_for_testing(sc.ctx());economics::assert_role_types<USD,NativeInstaller1,NativeRevision2>(&c,0);economics::assert_live(&c,0,1000,&clock);economics::assert_primary(&c);clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.end();}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_live_missing_native_binding(){let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);let authority:Authority=sc.take_from_sender();let id=native_binding::create_config_for_testing<USD>(&authority,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(authority);sc.next_tx(@0xa);let c:Config<USD> =sc.take_shared_by_id(id);let clock=clock::create_for_testing(sc.ctx());economics::assert_role_primary_live<USD,NativeInstaller1,NativeRevision2>(&c,0,0,1000,&clock);clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.end();}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun old_snapshot_missing_native_binding(){let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);let authority:Authority=sc.take_from_sender();let id=native_binding::create_config_for_testing<USD>(&authority,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(authority);sc.next_tx(@0xa);let c:Config<USD> =sc.take_shared_by_id(id);let clock=clock::create_for_testing(sc.ctx());economics::assert_role_types<USD,NativeInstaller1,NativeRevision2>(&c,0);economics::assert_primary_snapshot(&c,object::id(&c),0,economics::commitment(&c));clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.end();}

#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]
fun new_snapshot_missing_native_binding(){let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);let authority:Authority=sc.take_from_sender();let id=native_binding::create_config_for_testing<USD>(&authority,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(authority);sc.next_tx(@0xa);let c:Config<USD> =sc.take_shared_by_id(id);let clock=clock::create_for_testing(sc.ctx());economics::assert_role_primary_snapshot<USD,NativeInstaller1,NativeRevision2>(&c,0,object::id(&c),0,economics::commitment(&c));clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.end();}
