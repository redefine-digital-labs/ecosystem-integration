1. 固定输入/tool并复制Core，保存 transport mapping 与before证据。
2. 增加单一 test_only direct模块；成对旧链/组合入口运行，首轮构建错误仅修测试代码。
3. 检查精确身份数量、全输入与production/original tests无漂移；保留结果和未覆盖项。

Round 1: test-only syntax fixes needed (generic >= token, missing bcs import, end() return needs semicolon); zero source drift. Round 2 repeats unchanged test matrix after these corrections.

Round 2: compiler borrow order rejects computing CAS commitment after &mut c argument. Snapshot CAS before mutation in test-only code. Round 3 is final authorized attempt.

Round 3: 54/54 VM PASS; frozen/Core/installed drift and new-input maps empty; original production/test bytes exact. Scope closed, no further run.
