# Foundation combined gate direct verification

目标：给冻结 source-admission 候选的两个组合入口补真实 VM 直达验证；比较角色优先旧链与组合接受域及精确首错。

范围：只在本目录复制 Core 并新增 test_only 模块；生产源码与59原测试保持 byte exact。真实 Config/Admin/native Catalog 用现有 fixture，角色使用实际 Maker/Native types，Clock 用框架测试 API。fixture 不构成 production Publisher/UpgradeCap/部署证明。

约束：manifest08460d6f/1667；固定Sui SHA2561d7baa；readonly frozen/local deps；sandbox deny network、global ~/.move、frozen/driver source writes；private MOVE_HOME。无安装/commit/节点/钱包/预算覆盖/实际CURRENT修改。

验收：合法 current snapshot/expiry边界及可构造负例，成对精确 abort_code+location；保留 raw/result/输入前后与hash；生产与59测试无漂移；最多3轮且2轮无进展停。native内部/Origin双无效不能独立构造时明示未覆盖。不宣称整体安装就绪。

手册：v1.0 §§1–4,7,8.1,8.3,8.4,9,12。阶段Test；原父任务Owner/验收边界不变。此附件为已授权本地重构验证，不创建新看板。
