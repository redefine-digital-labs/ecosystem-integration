# Foundation combined gate direct verification report

结论：冻结候选两个组合 API 的新增直达 VM 测试 **54/54 PASS**，含2个合法等价测试、26组独立旧链/组合负例。第1–2轮仅 driver 编译错误；第3轮真实VM通过。没有生产修改或安装。此结果不表示整个候选可安装，不处理父任务原11 OOG问题。

## 已验证

- 真实 economics Config/Admin、真实 native_binding Catalog/currentNative，真实 CreatorAuthority1/CreatorRevision3/旧Revision2；框架测试Clock。Fixture复用已有 test_only 初始化，其成立范围为未发布本地VM，不证明生产Publisher/UpgradeCap/部署权限。
- 合法当前 Config、exact snapshot、Clock=0 expiry=0、Clock=1000 expiry=1000；Secondary关闭不阻止Primary；前后 OperationalSnapshot BCS相同。
- live旧链：assert_role_types → assert_live → assert_primary。最终Primary检查将旧链接受域与组合API对齐；单独 assert_live 本身不检查Primary。
- snapshot旧链：assert_role_types → assert_primary_snapshot。
- 每个负例独立构造fixture，分别直达旧链和组合。disabled、Primary off、paused、stale revision、wrong expected config ID、wrong commitment、Config callable/minimum release drift、expired、old role marker、missing native binding。
- 精确首错：旧Maker marker+disabled或callable drift均 package_roles::2；Primary off+expired均 economics::3；stale revision+expired、disabled+expired均 economics::1。没有泛expected_failure、catch或把异常替换为统一失败。

## 未覆盖与限制

- wrong-config覆盖的是错误expected ID（@0xdead），并非第二个真实同币种Config实例。
- missing-native覆盖真实无Catalog Config，但未独立构造「enabled/recovery/role合法而Native Catalog内部错误」；现有公开fixture无Catalog内部变更接口。未新增生产或冒充authority的测试钩子。
- 未覆盖真实Producer Origin Snapshot与Config同时无效时实际Maker消费入口的首错。此次API直达测试不生成或伪造生产Origin authority，也未把手工编排调用称作真实消费路径。
- economics::1被多个检查共用，因此精确模块/code可比较，但无法区分同code内部assert；role::2和expiry::3冲突例提供可辨识顺序。
- 54测试是有界构造验证，不是穷尽、外部审计、全Core重跑或真实链升级验证。父任务默认预算失败继续存在。

## 锁定输入与证据

- Frozen manifest SHA256：08460d6f00b97aecafb994008f78fdade449643d1d37ed400edf22e556aec045，1667 inputs。
- Sui SHA256：1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3。
- 固定readonly local deps；sandbox deny network/global ~/.move/frozen/Core写；private MOVE_HOME；无预算override。
- round-1/2/3：完整 raw.log、before.json、result.json、driver.move；每轮前后冻结1667输入、复制Core和实际181文件guard均无漂移。
- 所有既有 Core sources与60个testfiles均 byte exact（含父任务要求保护的59正文）；仅Move.toml/lock transport路径改写，记录在transport.json。新的单一test_only模块独立加入tests目录。
- 最终 driver SHA256：5aa9d0716d76af232c59666e0f920a994fd213e3ae6eab7f213b0666577ebc3e。
- 最终 raw SHA256：e5f7a6c7b4bd3b0d75d3f50cb7fcdfa47c51d13e68590680a0df1b4a57724c75。

## 产品工程评审附件（复用父任务）

手册v1.0，已读§§1–4,7,8.1/8.3/8.4,9,12；当前stage=Test，status=本局部验证完成；Owner/产品里程碑/完整目标/Release权限均沿用父任务。退出条件：新增矩阵54PASS及锁定输入无漂移，已满足。

共用合约安全/Sui时间、权限角色、对象身份、局部组合：通过上述有界矩阵；实际升级/治理权、外部审计/完整Release：待核验并由父任务现有责任人承接。支付/舍入/金融模型：本轮不改变也未重新证明。Ethereum/网络监控/部署恢复：本轮不适用（本地test-only）。回滚：删除此隔离driver即可，实际源码不依赖driver。无CURRENT修改、commit、网络、节点、钱包、外部消息或安装。
