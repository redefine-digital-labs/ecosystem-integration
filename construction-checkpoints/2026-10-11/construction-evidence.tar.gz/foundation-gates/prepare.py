from pathlib import Path
import hashlib, json, re, shutil
ROOT=Path(__file__).resolve().parent
FROZEN=Path('/Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/source-admission-budget-candidate/frozen/inputs')
MANIFEST=FROZEN.parent/'manifest.json'
SUI=Path('/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity/output/contract-rebuild/local-ptb-2026-10-08/tooling/sui')
CORE=ROOT/'core'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
all_hash=lambda tree:{str(p.relative_to(tree)):sha(p) for p in tree.rglob('*') if p.is_file()}
expected=json.loads(MANIFEST.read_text())['all_inputs']
assert sha(MANIFEST)=='08460d6f00b97aecafb994008f78fdade449643d1d37ed400edf22e556aec045'
assert len(expected)==1667 and all_hash(FROZEN)==expected
assert sha(SUI)=='1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3'
source=FROZEN/'move/soulidity_v1'
assert not CORE.exists()
shutil.copytree(source,CORE)
transport=[]
for name in ['Move.toml','Move.lock']:
 p=CORE/name;old=p.read_text();p.chmod(p.stat().st_mode|0o200);redirects=[]
 def move(m):
  if Path(m[1]).is_absolute():return m[0]
  target=(source/m[1]).resolve();assert (target/'Move.toml').is_file();redirects.append({'old':m[1],'new':str(target)})
  return 'local = "'+str(target)+'"'
 p.write_text(re.sub(r'local\s*=\s*"([^\"]+)"',move,old))
 transport.append({'file':name,'original_sha256':hashlib.sha256(old.encode()).hexdigest(),'transport_sha256':sha(p),'redirects':redirects,'original_utf8':old,'transport_utf8':p.read_text()})
(ROOT/'transport.json').write_text(json.dumps(transport,indent=2)+'\n')
assert all(sha(CORE/p.relative_to(source))==sha(p) for p in source.rglob('*') if p.is_file() and p.name not in ['Move.toml','Move.lock'])
text='''#[test_only]
module soulidity_v1::foundation_combined_gate_direct_tests;
use sui::test_scenario::{Self,Scenario};
use sui::clock::{Self,Clock};
use soulidity_foundation::economics::{Self,Config,Admin,Authority};
use soulidity_v1::native_binding::{Self,NativeInstaller1,NativeRevision2};
use soulidity_maker_manufacturing::maker_catalog::{CreatorAuthority1,CreatorRevision2,CreatorRevision3};
public struct USD has drop {}
fun setup():(Scenario,Config<USD>,Admin,Clock){
 let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);
 let a:Authority=sc.take_from_sender();let id=native_binding::create_enabled_for_testing<USD>(&a,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(a);sc.next_tx(@0xa);
 let c:Config<USD>=sc.take_shared_by_id(id);let a:Admin=sc.take_from_sender();let clock=clock::create_for_testing(sc.ctx());native_binding::assert_current(&c);(sc,c,a,clock)
}
fun finish(sc:Scenario,c:Config<USD>,a:Admin,clock:Clock){clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.return_to_sender(a);sc.end()}
fun old_live(c:&Config<USD>,revision:u64,expiry:u64,clock:&Clock){economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision3>(c,2);economics::assert_live(c,revision,expiry,clock);economics::assert_primary(c)}
fun new_live(c:&Config<USD>,revision:u64,expiry:u64,clock:&Clock){economics::assert_role_primary_live<USD,CreatorAuthority1,CreatorRevision3>(c,2,revision,expiry,clock)}
fun old_snapshot(c:&Config<USD>,id:ID,revision:u64,hash:vector<u8>){economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision3>(c,2);economics::assert_primary_snapshot(c,id,revision,hash)}
fun new_snapshot(c:&Config<USD>,id:ID,revision:u64,hash:vector<u8>){economics::assert_role_primary_snapshot<USD,CreatorAuthority1,CreatorRevision3>(c,2,id,revision,hash)}
#[test]
fun valid_equivalent_current_native_and_exact_snapshot(){let(sc,c,a,clock)=setup();let before=bcs::to_bytes(&economics::operational_snapshot(&c));old_live(&c,0,0,&clock);new_live(&c,0,0,&clock);old_snapshot(&c,object::id(&c),0,economics::commitment(&c));new_snapshot(&c,object::id(&c),0,economics::commitment(&c));native_binding::assert_current(&c);assert!(before==bcs::to_bytes(&economics::operational_snapshot(&c)),0);finish(sc,c,a,clock)}
#[test]
fun valid_equivalent_at_exact_expiry_and_secondary_off(){let(sc,mut c,mut a,mut clock)=setup();economics::set_secondary_enabled(&mut c,&mut a,0,economics::commitment(&c),false);clock::increment_for_testing(&mut clock,1000);old_live(&c,1,1000,&clock);new_live(&c,1,1000,&clock);old_snapshot(&c,object::id(&c),1,economics::commitment(&c));new_snapshot(&c,object::id(&c),1,economics::commitment(&c));assert!(!economics::secondary_enabled(&c) && economics::primary_enabled(&c),0);finish(sc,c,a,clock)}
'''
cases=[]
for api in ['live','snapshot']:
 for label,mutation,revision,idexpr,hashexpr,expiry,code,location in [
 ('disabled','economics::set_enabled(&mut c,&mut a,0,economics::commitment(&c),false);','economics::revision(&c)','object::id(&c)','economics::commitment(&c)','1000',1,'economics'),
 ('primary_off','economics::set_primary_enabled(&mut c,&mut a,0,economics::commitment(&c),false);','economics::revision(&c)','object::id(&c)','economics::commitment(&c)','1000',1,'economics'),
 ('stale_revision','economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,false);','0','object::id(&c)','economics::commitment(&c)','1000',1,'economics'),
 ('paused','economics::configure(&mut c,&mut a,0,1000,250,0,@0xf,true);','economics::revision(&c)','object::id(&c)','economics::commitment(&c)','1000',1,'economics'),
 ('callable_drift','economics::drift_callable_for_testing(&mut c);','economics::revision(&c)','object::id(&c)','economics::commitment(&c)','1000',1,'economics'),
 ('minimum_release_drift','economics::raise_minimum_for_testing(&mut c,3);','economics::revision(&c)','object::id(&c)','economics::commitment(&c)','1000',1,'economics')]:
  cases.append((api,label,mutation,revision,idexpr,hashexpr,expiry,code,location,False))
 if api=='live':
  for label,mutation,revision,expiry,code in [('expired','clock::increment_for_testing(&mut clock,1001);','0','1000',3),('primary_off_and_expired','economics::set_primary_enabled(&mut c,&mut a,0,economics::commitment(&c),false);clock::increment_for_testing(&mut clock,1001);','1','1000',3),('stale_and_expired','clock::increment_for_testing(&mut clock,1001);','1','1000',1),('disabled_and_expired','economics::set_enabled(&mut c,&mut a,0,economics::commitment(&c),false);clock::increment_for_testing(&mut clock,1001);','1','1000',1)]:
   cases.append((api,label,mutation,revision,'object::id(&c)','economics::commitment(&c)',expiry,code,'economics',False))
 else:
  cases += [(api,'wrong_config','','0','object::id_from_address(@0xdead)','economics::commitment(&c)','1000',1,'economics',False),(api,'wrong_commitment','','0','object::id(&c)','vector[0]','1000',1,'economics',False)]
 for label,mutation in [('old_role_marker',''),('old_role_and_disabled','economics::set_enabled(&mut c,&mut a,0,economics::commitment(&c),false);'),('old_role_and_callable_drift','economics::drift_callable_for_testing(&mut c);')]:
  cases.append((api,label,mutation,'economics::revision(&c)','object::id(&c)','economics::commitment(&c)','1000',2,'package_roles',True))
for api,label,mutation,revision,idexpr,hash,expiry,code,location,wrong_role in cases:
 for mode in ['old','new']:
  if wrong_role:
   if mode=='old':call='economics::assert_role_types<USD,CreatorAuthority1,CreatorRevision2>(&c,2);'+('economics::assert_live(&c,'+revision+','+expiry+',&clock);economics::assert_primary(&c);' if api=='live' else 'economics::assert_primary_snapshot(&c,'+idexpr+','+revision+','+hash+');')
   else:call='economics::assert_role_primary_'+api+'<USD,CreatorAuthority1,CreatorRevision2>(&c,2,'+(revision+','+expiry+',&clock' if api=='live' else idexpr+','+revision+','+hash)+');'
  else:call=mode+'_'+api+'(&c,'+(revision+','+expiry+',&clock' if api=='live' else idexpr+','+revision+','+hash)+');'
  text+='\n#[test,expected_failure(abort_code='+str(code)+',location=soulidity_foundation::'+location+')]\nfun '+mode+'_'+api+'_'+label+'(){let(sc,mut c,mut a,mut clock)=setup();'+mutation+call+'finish(sc,c,a,clock)}\n'
for api in ['live','snapshot']:
 for mode in ['old','new']:
  call=('economics::assert_role_types<USD,NativeInstaller1,NativeRevision2>(&c,0);'+('economics::assert_live(&c,0,1000,&clock);economics::assert_primary(&c);' if api=='live' else 'economics::assert_primary_snapshot(&c,object::id(&c),0,economics::commitment(&c));')) if mode=='old' else 'economics::assert_role_primary_'+api+'<USD,NativeInstaller1,NativeRevision2>(&c,0,'+('0,1000,&clock' if api=='live' else 'object::id(&c),0,economics::commitment(&c)')+');'
  text+='\n#[test,expected_failure(abort_code=1,location=soulidity_foundation::economics)]\nfun '+mode+'_'+api+'_missing_native_binding(){let mut sc=test_scenario::begin(@0xa);economics::init_for_testing(sc.ctx());sc.next_tx(@0xa);let authority:Authority=sc.take_from_sender();let id=native_binding::create_config_for_testing<USD>(&authority,1000,250,0,@0xf,sc.ctx());sc.return_to_sender(authority);sc.next_tx(@0xa);let c:Config<USD>=sc.take_shared_by_id(id);let clock=clock::create_for_testing(sc.ctx());'+call+'clock::destroy_for_testing(clock);test_scenario::return_shared(c);sc.end()}\n'
text=text.replace('use sui::clock::{Self,Clock};','use sui::clock::{Self,Clock};\nuse std::bcs;').replace('Config<USD>=','Config<USD> =').replace('sc.end()}','sc.end();}')
text=re.sub(r'economics::(set_enabled|set_primary_enabled|set_secondary_enabled)\(&mut c,&mut a,0,economics::commitment\(&c\),false\);',r'let cas_hash=economics::commitment(&c);economics::\1(&mut c,&mut a,0,cas_hash,false);',text)
(CORE/'tests/foundation_combined_gate_direct_tests.move').write_text(text)
(ROOT/'case-matrix.json').write_text(json.dumps({'positive':2,'paired_negative':len(cases)+2,'expected_tests':2+2*(len(cases)+2),'legacy_live':'assert_role_types -> assert_live -> assert_primary (includes existing Primary guard)','legacy_snapshot':'assert_role_types -> assert_primary_snapshot','cases':cases,'uncovered':['Native Catalog internals independently invalid while genuine enabled Config passes recovery/role (no public mutation fixture)','Actual producer Origin Snapshot and Config simultaneously invalid at real Maker consumption entry']},indent=2)+'\n')
