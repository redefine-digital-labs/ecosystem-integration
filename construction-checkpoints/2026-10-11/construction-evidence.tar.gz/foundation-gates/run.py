from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,sys
ROOT=Path(__file__).resolve().parent
CORE=ROOT/'core'
FROZEN=Path('/Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/source-admission-budget-candidate/frozen/inputs')
SUI=Path('/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity/output/contract-rebuild/local-ptb-2026-10-08/tooling/sui')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
all_hash=lambda tree:{str(p.relative_to(tree)):sha(p) for p in tree.rglob('*') if p.is_file()}
round=int(sys.argv[1]);assert 1<=round<=3
OUT=ROOT/('round-'+str(round));OUT.mkdir(exist_ok=False)
guard=json.loads((ROOT.parent/'pack-budget-root-review-v1/installed-181-before.json').read_text())['inputs']
assert all(sha(Path(p))==h for p,h in guard.items())
manifest=FROZEN.parent/'manifest.json';expected=json.loads(manifest.read_text())['all_inputs']
assert sha(manifest)=='08460d6f00b97aecafb994008f78fdade449643d1d37ed400edf22e556aec045'
assert len(expected)==1667 and all_hash(FROZEN)==expected
assert sha(SUI)=='1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3'
command=[str(SUI),'move','test','foundation_combined_gate_direct_tests','--path',str(CORE),'--install-dir',str(OUT/'build')]
policy=f'(version 1) (allow default) (deny network*) (deny file-write* (subpath "/Users/naoer/.move")) (deny file-write* (subpath "{FROZEN}")) (deny file-write* (subpath "{CORE}"))'
execution=['/usr/bin/sandbox-exec','-p',policy,*command]
before={'scope':'test-only copied Core direct combined gates; no production install; default limits','round':round,'command':command,'execution':execution,'MOVE_HOME':str(OUT/'tool-cache'),'frozen_before':all_hash(FROZEN),'core_before':all_hash(CORE),'installed_before':guard,'manifest_sha256':sha(manifest),'tool_sha256':sha(SUI),'overrides':[],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'before.json').write_text(json.dumps(before,indent=2)+'\n')
with (OUT/'raw.log').open('wb') as log:p=subprocess.run(execution,cwd=CORE,env={**os.environ,'MOVE_HOME':before['MOVE_HOME']},stdout=log,stderr=subprocess.STDOUT)
raw=re.sub(r'\x1b\[[0-9;]*m','',(OUT/'raw.log').read_text())
after={'frozen':all_hash(FROZEN),'core':all_hash(CORE),'installed':{p:sha(Path(p)) for p in guard}}
drift={key:{p:[h,after[key].get(p)] for p,h in before[key+'_before'].items() if after[key].get(p)!=h} for key in after}
new={key:{p:h for p,h in after[key].items() if p not in before[key+'_before']} for key in after}
identities={i:s for s,i in re.findall(r'\[\s*(PASS|FAIL|TIMEOUT)\s*\]\s+(\S+)',raw)}
original={str(p.relative_to(FROZEN/'move/soulidity_v1')):sha(p) for p in (FROZEN/'move/soulidity_v1').rglob('*') if p.is_file() and p.name not in ['Move.toml','Move.lock']}
result={'exit_code':p.returncode,'command':command,'tool_sha256':sha(SUI),'manifest_sha256':sha(manifest),'source_after':after,'drift':drift,'new_inputs':new,'identities':identities,'summaries':re.findall(r'Test result[^\n]*',raw),'raw_log_sha256':sha(OUT/'raw.log'),'original_core_byte_exact':all(sha(CORE/f)==h for f,h in original.items()),'original_test_file_count':len(list((FROZEN/'move/soulidity_v1/tests').glob('*.move'))),'driver_sha256':sha(CORE/'tests/foundation_combined_gate_direct_tests.move'),'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_installed':False}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['exit_code','drift','new_inputs','summaries','original_core_byte_exact','original_test_file_count']}))
