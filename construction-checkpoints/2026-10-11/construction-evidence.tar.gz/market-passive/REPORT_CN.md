# 独立 Market 的被动扩展兼容验收

本轮完成实际候选源码适配、独立生产构建、原 Market 44/44，以及真实独立 Market 入口的被动兼容 6/6 和标准示例 5/5。仍为 NOT_INSTALL_READY：本证据来自 Application010b/Market3225 图；不能与后续 SourceAdmission08460 图的 Core1061/1062 拼成同一合格目标。

## 已验证行为

| Soul 情形 | 取消 | 成交 | 权属边界 |
|---|---|---|---|
| 原基础 Soul | PASS | PASS | 原 Root ID、Origin、Free ID、Bound 数量及真实授权交接断言保留 |
| 新增内部被动 DOF | PASS | PASS | 实际附属对象随整颗 Soul 交付 |
| 钱包外部 Attribute + Relation | PASS | PASS | 外部对象留在卖方钱包；Soul ID 关联不自动转让对象或授予权限 |

驱动直接调用 `soulidity_market::market`，由独立 Market 私有角色的测试桥初始化实际 Config。每条可选扩展分支持有同一真实 Config，并以 assert11 验证前后 commitment 相等。没有导出实际 commitment 值；此结果属于运行时相等断言。

加入扩展前后以相同 Market 生产根重建：194/194 `.mv` 原字节一致；生成 Move.lock 原字节一致；3228 个冻结生产/测试图文件零变化。Market manifest 未加入被动包。强迫修改源码、配置或制品次数为 0；实际发布次数为 0。本次没有安装或部署。

## 真实失败与修正

003 驱动最初沿较早历史 fixture 漏配 250BPS，6 项均被 MakerTerms abort2 拒绝；004 修复费率后重复归还/获取同笔交易的 Shared Config，6 项遇 ScenarioEmptyInventory3。005 改为持有一次真实 Config 输入，6 项全部通过。这两次是驱动配置/输入错误；完整 raw、历史正文、差异账均保留，不能把它们描述为通过。

## 精确材料与剩余范围

- `independent-market-passive-equivalence.json`：6 项真实身份、194 模块逐字节哈希、锁与冻结图验证。
- `runs/001-independent-market-production`：实际独立生产构建。
- `runs/002-passive-standard-tests`：标准示例 5/5。
- `runs/005-independent-market-six-vectors-single-input`：独立业务 6/6。
- `../independent-market-passive-review-v1/REPORT_CN.md`：只读复核本轮6+5及194原字节/锁/完整冻结图，SCOPED_PASS。
- `../independent-market-current-review-v1/REPORT.md`：只读核验原 Market44、生产44函数正文及名义类型变化；20 地址分配中实际编译使用18个。

只证明未知被动扩展不迫使当前市场变化，不证明任意受保护来源可成交。Bound 验证为 count=1，并非独立 Bound ID 比较；原 Root/Free ID、Origin、授权断言已保留。Application/版税/Config/Collection/授权清理等现有消费仍有真实业务依赖；资金、转移限制、私密交接、可撤销资格必须分别适配。最终一致图回归、完整 StandardHandover 义务、SDK/原 UI、PTB、真实 origins/角色注册与发布仍待验收。

原 DOF-001/P01/P09、Owner、状态与产品路线保留。手册 v1.0：§§1–4、5、6、7、8.3–8.4、9、12；Operating Model §8。本轮 Code/Build/Test 范围证据，未执行 Release/Deploy/Operate/Monitor；没有新增部署权限或自动化完成声明。
