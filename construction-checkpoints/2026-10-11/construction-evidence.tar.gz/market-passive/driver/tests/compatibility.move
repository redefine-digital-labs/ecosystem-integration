#[test_only]
module market_b0_driver::compatibility;
use sui::test_scenario::{Self, Scenario};
use sui::clock;
use sui::coin;
use soulidity_v1::fixtures::{Self, USD};
use soulidity_market::market::{Self, Listing};
use soulidity_foundation::economics::{Self as economics, Config, Admin};
use soulidity_application::character;
use soulidity_standard::soul::{Self as standard, Soul, Origin};
use passive_example::passive::{Self, Attribute, Relation};
public struct Harness { sc: Scenario, soul: ID, listing: ID, origin: Origin, mode: u8, free: ID, attribute: Option<ID>, relation: Option<ID> }
fun listed(mode: u8): Harness {
    let mut sc = market::setup_for_testing(0, 0, 0, 0, 0, 0); let sid = fixtures::mint(&mut sc, 231, 0);
    sc.next_tx(@0xa); let mut cfg: Config<USD> = sc.take_shared(); let mut admin: Admin = sc.take_from_sender();
    economics::configure(&mut cfg, &mut admin, 0, 1000, 250, 0, @0xf, false);
    test_scenario::return_shared(cfg); sc.return_to_sender(admin);
    sc.next_tx(@0xb); let mut root: Soul = sc.take_from_sender_by_id(sid); let origin = standard::origin(&root);
    let free = character::free_id(&character::binding(&root, b"free").destroy_some()).destroy_some();
    let grant_clock = clock::create_for_testing(sc.ctx());
    let revision = character::revision(&root); character::grant(&mut root, @0x8, 1, option::some(1000), revision, option::none(), &grant_clock, sc.ctx());
    clock::destroy_for_testing(grant_clock); assert!(character::grant_count(&root) == 1, 11);
    let cfg:Config<USD> = sc.take_shared();let frozen_config=economics::commitment(&cfg);
    let mut attribute = option::none(); let mut relation = option::none();
    if (mode == 1) {
        let a = passive::new_attribute(b"new passive appearance", sc.ctx()); attribute = option::some(object::id(&a));
        let revision = standard::revision(&root); passive::attach(&mut root, a, b"appearance", revision);
    } else if (mode == 2) {
        let bytes = std::bcs::to_bytes(&root); let a = passive::new_attribute(b"external experience", sc.ctx());
        let r = passive::relate(&root, &a, sc.ctx()); attribute = option::some(object::id(&a)); relation = option::some(object::id(&r));
        assert!(passive::matches(&r, &root, &a) && std::bcs::to_bytes(&root) == bytes, 0);
        transfer::public_transfer(a, @0xb); transfer::public_transfer(r, @0xb);
    };
    assert!(economics::commitment(&cfg)==frozen_config,11); let clock = clock::create_for_testing(sc.ctx());
    let expected = character::revision(&root); let manifest = character::manifest_hash(&root);
    let lid = market::list_soul(root, &cfg, 101, 1000, expected, manifest, 1, &clock, sc.ctx());
    clock::destroy_for_testing(clock); test_scenario::return_shared(cfg);
    Harness { sc, soul: sid, listing: lid, origin, mode, free, attribute, relation }
}
fun assert_root(h: &Harness, root: &Soul) {
    assert!(object::id(root) == h.soul && standard::origin(root) == h.origin, 1);
    assert!(character::bound_count(root) == 1 && character::free_id(&character::binding(root, b"free").destroy_some()) == option::some(h.free), 2);
    if (h.mode == 1) {
        assert!(object::id(passive::attached(root, b"appearance")) == *h.attribute.borrow(), 3);
        assert!(passive::text(passive::attached(root, b"appearance")) == b"new passive appearance", 4);
    };
}
fun cancelled(mode: u8) {
    let mut h = listed(mode); h.sc.next_tx(@0xb);
    let mut l: Listing<Soul, USD> = h.sc.take_shared_by_id(h.listing);
    market::cancel(&mut l, 0, h.sc.ctx()); assert!(market::status(&l) == 2, 5); test_scenario::return_shared(l);
    h.sc.next_tx(@0xb); let root: Soul = h.sc.take_from_sender_by_id(h.soul); assert_root(&h, &root); assert!(character::grant_count(&root) == 1, 12);
    if (mode == 2) {
        let a: Attribute = h.sc.take_from_sender_by_id(*h.attribute.borrow()); let r: Relation = h.sc.take_from_sender_by_id(*h.relation.borrow());
        assert!(passive::matches(&r, &root, &a), 6); h.sc.return_to_sender(a); h.sc.return_to_sender(r);
    };
    h.sc.return_to_sender(root); let Harness { sc, soul: _, listing: _, origin: _, mode: _, free: _, attribute: _, relation: _ } = h; sc.end();
}
fun sold(mode: u8) {
    let mut h = listed(mode); h.sc.next_tx(@0xc);
    let mut l: Listing<Soul, USD> = h.sc.take_shared_by_id(h.listing); let mut cfg: Config<USD> = h.sc.take_shared();
    let clock = clock::create_for_testing(h.sc.ctx()); let manifest = market::manifest_hash(&l);
    let quote = market::soul_quote_hash(&l, &cfg, @0xc); let payment = coin::mint_for_testing<USD>(101, h.sc.ctx());
    market::buy_soul(&mut l, &mut cfg, 0, manifest, quote, 1, fixtures::h(232), payment, &clock, h.sc.ctx());
    assert!(market::status(&l) == 1 && market::buyer(&l) == option::some(@0xc), 7);
    clock::destroy_for_testing(clock); test_scenario::return_shared(l); test_scenario::return_shared(cfg);
    h.sc.next_tx(@0xc); let root: Soul = h.sc.take_from_sender_by_id(h.soul); assert_root(&h, &root);
    assert!(character::grant_count(&root) == 0 && character::generation(&root) == 1, 8);
    if (mode == 2) {
        assert!(h.sc.ids_for_sender<Attribute>().is_empty() && h.sc.ids_for_sender<Relation>().is_empty(), 9);
    };
    h.sc.return_to_sender(root);
    if (mode == 2) {
        h.sc.next_tx(@0xb); let a: Attribute = h.sc.take_from_sender_by_id(*h.attribute.borrow()); let r: Relation = h.sc.take_from_sender_by_id(*h.relation.borrow());
        assert!(passive::related_soul(&r) == h.soul && passive::related_attribute(&r) == object::id(&a), 10);
        h.sc.return_to_sender(a); h.sc.return_to_sender(r);
    };
    let Harness { sc, soul: _, listing: _, origin: _, mode: _, free: _, attribute: _, relation: _ } = h; sc.end();
}
#[test] fun baseline_cancel() { cancelled(0) }
#[test] fun baseline_sale() { sold(0) }
#[test] fun passive_extension_cancel() { cancelled(1) }
#[test] fun passive_extension_sale() { sold(1) }
#[test] fun external_relation_cancel() { cancelled(2) }
#[test] fun external_relation_sale() { sold(2) }
