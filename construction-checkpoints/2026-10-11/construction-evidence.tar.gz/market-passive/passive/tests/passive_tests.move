#[test_only]
module passive_example::passive_tests;
use std::string;
use sui::test_scenario::{Self, Scenario};
use soulidity_standard::soul::{Self, Soul};
use passive_example::passive::{Self, Attribute, Relation};
public struct SoulProducer has drop {}
public struct Source has key, store { id: UID }
fun create(ctx: &mut TxContext): Soul {
    let source = Source { id: object::new(ctx) };
    let root = soul::new_for_testing(SoulProducer {}, &source, 1,
        vector::tabulate!(32, |_| 7), string::utf8(b"passive-test"), ctx);
    transfer::public_transfer(source, ctx.sender()); root
}
fun finish(root: Soul, mut sc: Scenario) {
    transfer::public_transfer(root, sc.ctx().sender()); sc.end();
}
#[test]
fun passive_attachment_and_removal_preserve_both_ids_and_origin() {
    let mut sc = test_scenario::begin(@0xa); let mut root = create(sc.ctx());
    let id = object::id(&root); let origin = soul::origin(&root);
    let a = passive::new_attribute(b"skin", sc.ctx()); let aid = object::id(&a);
    passive::attach(&mut root, a, b"visual", 0);
    assert!(object::id(&root) == id && soul::origin(&root) == origin, 0);
    assert!(object::id(passive::attached(&root, b"visual")) == aid, 1);
    let d = soul::module_page(&root, 0, 1)[0];
    assert!(!soul::handover_required(&d) && soul::removable(&d), 2);
    let a = passive::detach(&mut root, b"visual", 1);
    assert!(object::id(&a) == aid && passive::text(&a) == b"skin" && soul::module_count(&root) == 0, 3);
    transfer::public_transfer(a, @0xa); finish(root, sc)
}
#[test]
fun external_relation_leaves_root_bytes_and_revision_unchanged() {
    let mut sc = test_scenario::begin(@0xa); let root = create(sc.ctx());
    let before = std::bcs::to_bytes(&root);
    let a = passive::new_attribute(b"experience", sc.ctx());
    let r = passive::relate(&root, &a, sc.ctx());
    assert!(passive::matches(&r, &root, &a), 0);
    assert!(std::bcs::to_bytes(&root) == before && soul::revision(&root) == 0, 1);
    transfer::public_transfer(r, @0xa); transfer::public_transfer(a, @0xa); finish(root, sc)
}
#[test]
fun another_root_or_attribute_does_not_match_reference() {
    let mut sc = test_scenario::begin(@0xa); let root = create(sc.ctx()); let other = create(sc.ctx());
    let a = passive::new_attribute(b"one", sc.ctx()); let b = passive::new_attribute(b"two", sc.ctx());
    let r = passive::relate(&root, &a, sc.ctx());
    assert!(!passive::matches(&r, &other, &a) && !passive::matches(&r, &root, &b), 0);
    transfer::public_transfer(r, @0xa); transfer::public_transfer(a, @0xa);
    transfer::public_transfer(b, @0xa); transfer::public_transfer(other, @0xa); finish(root, sc)
}
#[test]
fun independent_attribute_transfer_does_not_transfer_soul_or_relation() {
    let mut sc = test_scenario::begin(@0xa); let root = create(sc.ctx()); let sid = object::id(&root);
    let a = passive::new_attribute(b"independent", sc.ctx()); let aid = object::id(&a);
    let r = passive::relate(&root, &a, sc.ctx()); let rid = object::id(&r);
    transfer::public_transfer(a, @0xb); transfer::public_transfer(r, @0xa); transfer::public_transfer(root, @0xa);
    sc.next_tx(@0xb); let a: Attribute = sc.take_from_sender_by_id(aid);
    assert!(sc.ids_for_sender<Soul>().is_empty() && sc.ids_for_sender<Relation>().is_empty(), 0); sc.return_to_sender(a);
    sc.next_tx(@0xa); let root: Soul = sc.take_from_sender_by_id(sid); let r: Relation = sc.take_from_sender_by_id(rid);
    assert!(passive::related_soul(&r) == sid && passive::related_attribute(&r) == aid && soul::revision(&root) == 0, 1);
    sc.return_to_sender(r); sc.return_to_sender(root); sc.end();
}
#[test, expected_failure(abort_code=1, location=soulidity_standard::soul)]
fun stale_attach_does_not_bypass_root_cas() {
    let mut sc = test_scenario::begin(@0xa); let mut root = create(sc.ctx());
    let a = passive::new_attribute(b"one", sc.ctx()); passive::attach(&mut root, a, b"visual", 0);
    let b = passive::new_attribute(b"two", sc.ctx()); passive::attach(&mut root, b, b"other", 0);
    finish(root, sc)
}
