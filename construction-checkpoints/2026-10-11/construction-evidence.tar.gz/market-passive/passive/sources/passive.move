/// Passive data example. Neither metadata nor an ID relation grants a permission.
module passive_example::passive;
use std::hash;
use soulidity_standard::soul::{Self, Soul};
public struct AttributeWitness has drop {}
public struct Attribute has key, store { id: UID, text: vector<u8> }
/// A declaration linking actual referenced objects, not ownership or a license.
public struct Relation has key, store { id: UID, soul: ID, attribute: ID }
public fun new_attribute(text: vector<u8>, ctx: &mut TxContext): Attribute {
    Attribute { id: object::new(ctx), text }
}
public fun text(a: &Attribute): vector<u8> { a.text }
public fun relate(s: &Soul, a: &Attribute, ctx: &mut TxContext): Relation {
    Relation { id: object::new(ctx), soul: object::id(s), attribute: object::id(a) }
}
public fun related_soul(r: &Relation): ID { r.soul }
public fun related_attribute(r: &Relation): ID { r.attribute }
public fun matches(r: &Relation, s: &Soul, a: &Attribute): bool {
    r.soul == object::id(s) && r.attribute == object::id(a)
}
public fun attach(s: &mut Soul, a: Attribute, name: vector<u8>, expected: u64) {
    let semantic = hash::sha3_256(a.text);
    soul::install(s, AttributeWitness {}, name, a, 1, true, semantic, expected)
}
public fun attached(s: &Soul, name: vector<u8>): &Attribute {
    soul::borrow_module<AttributeWitness, Attribute>(s, name)
}
public fun detach(s: &mut Soul, name: vector<u8>, expected: u64): Attribute {
    soul::uninstall<AttributeWitness, Attribute>(s, name, expected)
}
