# Published Source lookup candidate: NOT_INSTALL_READY

Two bounded source rounds preserve accepted/rejected business domain and public ABI/storage; default negative11 stillFAIL. Actual sources were not installed. Full parent goal remainsACTIVE; local Source equivalence is not full ecosystem completion.

Frozen inputs: `/Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/published-source-lookup-candidate-v1/frozen/inputs`; manifest SHA256 `ad70e19cd71102d7ca2ace85abea6f0ed9a7cf7b645074a7ec2e311f530ff24f`;1667 independent ordinary inputs/1664code+metadata/3docs, fixeddeps1343 exact to upstream08460d6f. Sole delta maker_catalog.move b7a8cf96913bb07d5cb686e4377f66a1ae2ad96b912a65379dbd4a703ac58484 →91cb0342a61fba9af11c9b2a0d7c98cf65751b7722b2063bf2ba319c1d902a3d. Other production sources, Core sources, every743 test source including fixeddeps unchanged. Original60Core testfiles and historical buy_choice/positive10/negative11 are byteexact to pinned upstream, including expected maker_catalog abort6 and loops10/11. No new or removed test identity.

| Evidence | Actual result |
| --- | --- |
| Round1 Pack57 default |56PASS/1FAIL|
| Round2 Pack57 default statistics |56PASS/1FAIL|
| Independent wholeCore1062 run006 |1061PASS/1FAIL; exact identity/status match upstream|
| Independent production run007 |exit0 PASS|
| Maker49 run008 |49PASS; exact27manufacturing+22open-service identity/status|

Public ABI source: maker_catalog134 production public/package declarations plus43test_only public declarations unchanged;30 public struct declarations/layouts unchanged. Only new function is private published_definition. No nominal type/ability/object-layout/entrypoint/dependency change, no Core delegate. Other production bytes unchanged. Exact declarations in public-abi.json/preservation-ledger.json; raw logs and .mv hashes retained.

Semantics: reverse scan returns first match from end, identical to original forward scan's last match, including hypothetical duplicate hashes. Unknown hash or emptydefinitions abort maker_catalog EDefinition5; invalidVersion stillEVersion2 first. Hash remains pure policy::definition_hash (BCS+sha). Publication validate/validate_added_definitions reject duplicateDefinitionKey; no new uniqueness assumptions or hash-length checks.

issue_internal borrows immutableVersion and copies only selectedDefinition/royalty/beneficiary/marketOption/primaryOption; lookup precedes SupplyKey/issuedCount/ECap6 and writes; Option.destroy_some stays after supply write before unchanged policy::source/privateproducer/components authority. authorize_complete borrowsVersion until its original cap assertion, before mutatingattempt/counts. ensure_access_value copies onlymode/hash before originalclaim branch. All existing Config/funds/fees/supply/source/revision/actor/target/receipt gates and order relative to those calls remain. Resource exhaustion location can change, as intended; business abort order is unchanged from pinned084 upstream.

preview_source remains read-only metadata: noissuedCount check or exhaustedmetadata rejection. Actualpositive10 calls issued_count after10 issuances, which calls preview_source; itPASSes. Unknownhash/duplicate/error-order equivalence is source proof, not new direct forgedPublication/multi-invalid VMtest. No skippedPolicyProducer or cachedConfig validation.

VM statistics at identical defaults: positive10 upstream49999999824387 → round1 49999999818499 → final49999999813976, total10411reportedunits lower. Negative11 remains50000000000000 saturated. These are VMreportedunits, not realchainGas or per-operation instruction counts; cost data for all57 retained in costs.json.

Final negative stack: sui.dynamic_field::hash_type_and_key → dynamic_object_field::borrow → character::state_root_visual → state_scene → state_target → state_fresh_issuance_target → state_assert_fresh_issuance → assert_fresh_issuance → issuer::enhance_prepare → enhance_pack_for_testing → historicalbuy_choice → originalnegative11. Sourcepreview has completed before this failure. Exact failing iterationUNKNOWN; no marker/loop inference. Stop after2source rounds because next failure is unchanged Applicationvisual read and no furtherMakerlookup/copy delta on this realpurchasechain is evidenced. No thirdround, broader permissions/funds/runtime rewrite or test/budget waiver.

Fixed CLI SHA1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3; sandbox deniesnetwork, global ~/.move writes, frozen/read-only inputs and installedmove/docs/primary project writes. Everyrun source/locks/generatedinputs/upstream/installedguard no drift; privateMOVE_HOME; no cache seed/network/tool/defaultbudget/loop overrides. Runs004/005 share early buildcontext and remain observation-only; final acceptance uses independent006/007/008 install-dirs.

Handbook1.0 and OPERATING_MODEL§8 tracked in REVIEW.md as existing construction attachment. Implemented/local; verifiedpartial; unreleased/undeployed. Parent independent review remains required. Recovery: ignore diagnosticcandidate and retain upstream/actualsources; no install/CURRENT/commit/push/PR/network/node/wallet/signatures/goal completion.
