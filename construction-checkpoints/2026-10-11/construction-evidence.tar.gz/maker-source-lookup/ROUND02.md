# Round2: remaining fullVersion copies on exact journey

Round1 default Pack57 remains56PASS/1FAIL. Statistics positive10 Gas49999999818499 vs upstream49999999824387: reduction5888 VMunits. Negative11 saturated50000000000000; final stack policy.source Definitionhash instead of assert_producer. Exact original iterationUNKNOWN.

Measured static chain enhance_pack→begin_session_value→authorize_complete copied entireVersion for policyhash/cap. Replace with immutable borrowedVersion, last used before record_attempt mutatesProduct. No guard/field/order changes. Adjacent original Maker access setup ensure_access_value also copiedVersion for mode/hash; copy only mode/hash before mutatingclaim, retaining original branch and checks. No other access/settlement copies changed; no scope expansion to funding orConfig. Round2 remains same private/read fields and unnecessaryVersioncopy scope.
