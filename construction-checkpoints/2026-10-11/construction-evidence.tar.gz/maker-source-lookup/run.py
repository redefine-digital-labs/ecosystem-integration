from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,sys
R=Path(__file__).resolve().parent
S=R/'stage' if (R/'stage').exists() else R/'frozen/inputs'
U=R.parent/'source-admission-budget-candidate/frozen/inputs'
A=Path('/Users/naoer/.codex/worktrees/soul-dof-v1-rebuild/soulidity')
CLI=A/'output/contract-rebuild/local-ptb-2026-10-08/tooling/sui'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=lambda p:{str(x.relative_to(p)):sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
assert sha(CLI)=='1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3'
expected=json.loads((R/'upstream-before.json').read_text()); assert manifest(U)==expected
installed=json.loads((R/'installed-before.json').read_text());assert all(sha(Path(p))==h for p,h in installed.items())
label,package,mode=sys.argv[1:4];extras=sys.argv[4:]
assert mode in ['test','build'] and extras in [[],['soulidity_v1::pack_soul_tests'],['soulidity_v1::pack_soul_tests','--statistics']]
out=R/'runs'/label;out.mkdir(parents=True,exist_ok=False)
cmd=[str(CLI),'move',mode,'--path',str(S/'move'/package),'--install-dir',str(out/'build'),*extras]
policy=f'(version 1) (allow default) (deny network*) (deny file-write* (subpath "/Users/naoer/.move")) (deny file-write* (subpath "{U}")) (deny file-write* (subpath "{S}")) (deny file-write* (subpath "{A}/move")) (deny file-write* (subpath "{A}/docs")) (deny file-write* (subpath "/Users/naoer/Documents/Claude/Projects/soulidity"))'
execution=['/usr/bin/sandbox-exec','-p',policy,*cmd]
before={'command':cmd,'execution':execution,'tool_sha256':sha(CLI),'source_before':manifest(S),'upstream_verified':len(expected),'installed_before':installed,'overrides':[],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'publishedSource private lookup default budget unchanged tests'}
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
 process=subprocess.run(execution,cwd=S,env={**os.environ,'MOVE_HOME':str(R/'tool-cache')},stdout=log,stderr=subprocess.STDOUT)
after=manifest(S);assert manifest(U)==expected
raw=re.sub(r'\x1b\[[0-9;]*m','',(out/'raw.log').read_text());ident={i:s for s,i in re.findall(r'\[\s*(PASS|FAIL|TIMEOUT)\s*\]\s+(\S+)',raw)}
result={**before,'exit_code':process.returncode,'source_after':after,'source_drift':{p:[h,after.get(p)] for p,h in before['source_before'].items() if after.get(p)!=h},'new_inputs':{p:h for p,h in after.items() if p not in before['source_before']},'installed_drift':{p:[h,sha(Path(p))] for p,h in installed.items() if sha(Path(p))!=h},'upstream_after_verified':len(expected),'raw_log_sha256':sha(out/'raw.log'),'identities':ident,'summaries':re.findall(r'Test result[^\n]*',raw),'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_installed':False,'whole_product_complete':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['exit_code','source_drift','new_inputs','installed_drift','summaries']}))
