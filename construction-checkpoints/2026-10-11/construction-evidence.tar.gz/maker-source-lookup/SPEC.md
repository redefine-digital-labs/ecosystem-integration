# Published Source lookup bounded candidate

Existing full-product goal remains ACTIVE. Existing construction phase only; no new board or CURRENT change. Handbook1.0 §§1–5,7,8.1/8.3/8.4,9,11,12 and OPERATING_MODEL §8 apply. Stage=Plan/Code, status=local candidate.

## Outcome
Repair measured cost of actual published Source preview/issuance in immutable Maker publication, preserving historical buy_choice, positive10 and negative11 bodies and all1062 Core identities. Upstream manifest08460d6f00b97aecafb994008f78fdade449643d1d37ed400edf22e556aec045 /1667inputs is diagnostic authority.

## Scope and invariants
Only manufacturing maker_catalog.move private read lookup and unnecessary Version copy. No Core delegate needed. Private reverse lookup must select greatest matching index, abort EDefinition5 if absent; preview remains metadata even when supply exhausted. No supplied hash validation is added. issue_internal retains EVersion2 then lookup EDefinition5 then SupplyKey/issued/ECap6 then supply write then actual PolicyProducer source/components authority. BorrowVersion copies only selectedDefinition and settlement terms; market/primary Option extraction stays after supply mutation to preserve order. No validation cache, producer skip, fund/supply gate changes.

## Acceptance and stop
Same fixed CLI SHA1d7baa7c7314113671415acfa20279b1eedb6ae6d04f286988a00da285e769c3, privateMOVE_HOME, network/global ~/.move/frozen/installed write denial, fixeddeps1343. Default Pack57 first. On improvement run wholeCore1062 unchanged, production and Maker49. Retain raw logs/all identities/source hashes/delta/public ABI/layouts. Maximum3 substantive rounds; stop after2 no-progress rounds. Never weaken negatives/loops/default budgets. Record if stillFAIL. No actual install/CURRENT/Git/network/node/wallet/signature/goal completion.

## Source implication before code
Original forward do_ref overwrites found at each match, therefore chooses largest index. Reverse scan firstmatch has identical chosenDefinition even if duplicate hashes/collision; hash uses pure BCS+sha and has no business abort. Publication constructor validate rejects duplicateDefinitionKey and total fragments>500, but algorithm does not rely on uniqueness. FullVersion includes scene/outputs/alldefinitions; issue_internal only uses chosenDefinition,royalty,beneficiary,market,primary. Borrow ends before p.issued mutation. PublicSource witness/metadata validation remains called after lookup as before. Resource exhaustion location may change, as intended; business abort order/domain remain.
