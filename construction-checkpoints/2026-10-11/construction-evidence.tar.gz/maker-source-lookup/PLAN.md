# Plan

1. Pin/copy upstream1667 independently; establish semantics and exact source diff.
2. Round1: private reverse lookup, borrowVersion and copy selectedDefinition+terms only. Pack57 default fixed CLI.
3. If improved: wholeCore1062, production and Maker49 default; exact test source/identity and ABI/layout checks. Up to3 substantive rounds total,2 no-progress stop.
4. Freeze final ordinary files/source delta, raw logs and hashes; report precise accepted domain, errors and remaining FAIL. Durable handoff via helper dry-run inside candidate only. No installation.

Round1:56/57; positiveVMunits improvement5888; negativeOOG in finalSourcehash. Round2 removes authorize_complete fullVersioncopy on every real purchase and ensure_access_value mode/hashcopy on Makeraccess startup.
