# Soulidity Phase Handoff: published-source-lookup-candidate-v1

## Snapshot

- Created: 2026-10-11T08:33:53+03:00
- Phase: published-source-lookup-candidate-v1
- Status: in-progress
- Goal: Repair evidence-backed actual published Source lookup/fullVersion-copy cost without altering domain, tests or budgets
- Worktree: `/Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/published-source-lookup-candidate-v1`
- Branch: `not queried under candidate boundary`
- Commit: `not queried; actual CURRENT retained`
- Working tree: not queried; source guards verified unchanged
- Handoff: `HANDOFF.md`

## Outcome

Local two-round candidate; defaultPack56/57, wholeCore1061/1062, production/Maker49PASS. Sourcepreview completes; originalnegative11 stillOOG in unchangedApplicationvisualread. NOT_INSTALL_READY; fullgoalACTIVE.

## Scope and non-goals

### In scope

- MakerManufacturing private reverse Definition lookup and unnecessaryVersion copies only

### Intentionally not done

- No install/CURRENT/Git/network/node/wallet/signatures/budget/test/permissions/funds changes

## Durable decisions

- No durable decisions recorded for this boundary.

## Changed paths and assets

### Changed paths

- /Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/published-source-lookup-candidate-v1/frozen/inputs/move/soulidity_maker_manufacturing/sources/maker_catalog.move

### Image and binary assets

- No image or binary assets recorded.

### Relevant commits

- No additional commit references recorded.

## Verification

- Manifestad70e19cd71102d7ca2ace85abea6f0ed9a7cf7b645074a7ec2e311f530ff24f;1667inputs/fixed1343/alltestsbyteexact;134productionpublic/package+30struct unchanged
- wholeCore1061/1062 and Pack56/57 identities/status exact upstream;productionexit0;Maker49PASS

## Risks and recovery

### Risks or blockers

- Originalnegative11 stillVMOOG before expectedabort6; exactiterationUNKNOWN; Applicationvisualread now failing

### Recovery or rollback points

- Ignore isolatedcandidate;08460d6fupstream/actualinstalledsources unchanged

### Working-tree evidence

```text
No Git queried; actual CURRENT and installedsource SHA guards unchanged. Candidate-only write scope.
```

## Exact next action

Parent independently reviews freeze /Users/naoer/.codex/worktrees/owned-creation-construction/soulidity/output/published-source-lookup-candidate-v1/frozen/inputs. Do not install or waive negative11. Any further repair must use new bounded scope evidenced by final Applicationvisualread stack and preserve original10/11/defaultCLI.
