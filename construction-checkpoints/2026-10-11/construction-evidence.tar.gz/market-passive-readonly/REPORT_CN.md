# 独立 Market 被动扩展：独立只读核验

**SCOPED_SOURCE_PASS / RETAINED_BUILD_EVIDENCE_PASS / SIX_VECTOR_EVIDENCE_PASS / ZERO_FORCED_MARKET_CHANGE_PASS；NOT_INSTALL_READY。** 本复核未发现该有限范围中的新增回归。核验的是已存源码、历史正文、输入快照、制品原字节、raw/result 与哈希，不是重新执行。复核者没有运行编译器、Move VM、网络、节点、RPC、链交易或部署；内部 AI 复核不等于外部审计。

证据图限定为 Application `010b1ccae2b2f01e5378008abf48c901d3b77b93954bcc79ad4fc5c45dffe129` 与独立 Market 冻结 manifest `3225bc37f9812b9b6ef4dd0f4c8521132096b58ab16982e5a5f461fcc2920104`。不与 SourceAdmission08460 的 Core1061/1062 图拼接成 whole-target PASS。

## 精确范围与留存运行

| 留存运行 | 独立核验结果 | 结论 |
| --- | --- | --- |
| Market 原 `003-production` 与扩展 `001-independent-market-production` | 两者 exit 0、BuildInfo `test_mode: false`；各194源码快照均属于冻结输入 | 生产构建证据 PASS |
| `002-passive-standard-tests` | raw身份与result完全一致，5 PASS / 0 FAIL，exit 0 | 标准示例证据 PASS |
| `003-independent-market-six-vectors` | raw身份与result一致，0 PASS / 6 FAIL，exit 1；六项均 MakerTerms `maker_resale` abort2 | 保留的真实失败 |
| `004-independent-market-six-vectors-fixed` | raw身份与result一致，0 PASS / 6 FAIL，exit 1；六项均 `sui::test_scenario` abort3 | 保留的真实失败 |
| `005-independent-market-six-vectors-single-input` | raw身份与result一致，6 PASS / 0 FAIL，exit 0；当前驱动正文与编译源码快照逐字节一致 | 六向量证据 PASS |
| Market 原 `005-market44` | 44个raw身份/status与result完全一致，44 PASS；结果哈希仍等于冻结manifest pin | 原44证据保持，源码语义详见既有独立复核 |

每个运行的 raw hash、result hash、before hash、编译模块 hash 和 BuildInfo hash记录在 [evidence.json](evidence.json)。所有 before.json 均与 result 对应初始字段相等；同轮 before/after 输入相等，记录的 drift/new_inputs 均为空。固定工具当前 SHA 与七份运行记录一致，保留命令没有预算、深度、节点等 override，执行记录明确禁网络。复核没有借此声称自己重新运行过这些命令。

## 六向量与实际边界

驱动直接导入 `soulidity_market::market` 并调用实际 `list_soul/cancel/soul_quote_hash/buy_soul`。`market::setup_for_testing` 明确是 `#[test_only]`，在 Market 模块内构造其私有角色值 `MarketAuthority1{}` / `MarketRevision3{}`，绑定真实 Config。生产 `register` 的 Publisher + UpgradeCap 要求保留；测试桥不证明真实链生产权限已经建立。

| 模式 | 取消 | 成交 | 被核验断言 |
| --- | --- | --- | --- |
| baseline（0） | PASS | PASS | Root ID、Origin、Bound数量1、原 Free ID；取消保留授权，成交清理授权并轮换generation |
| 内部被动 DOF（1） | PASS | PASS | 上述基线，且实际 Attribute ID和内容在返回/交付的Soul内可读取 |
| 钱包外部 Attribute + Relation（2） | PASS | PASS | 上述基线；关联不改Root BCS，成交买方无外部对象，卖方仍持有同ID Attribute/Relation |

原最终成功基线的所有上述断言保留。六向量中的 Bound 断言是数量，不是逐个 Bound 对象 ID 的重新比较；原44整体库存职责的证据仍由既有独立 Market 复核承接，不能夸大六向量独有覆盖。

`listed` 在分支前一次取得真实 `Config<USD>`，保存 `economics::commitment(&cfg)`，可选分支之后以 assert11 比较同一次持有的 Config。三种模式均走这条路径，取消/成交共六向量。实际 commitment 数值未导出，结论是运行时相等断言，不能虚构已导出的配置值或声称所有交易阶段配置不变。

## 零强迫修改证据

原 `Market003-production` 与扩展后的 `driver001` 使用相同 Market 生产根。独立读取各194个 `.mv`，相对路径集合、SHA和原字节全部相等；没有地址或字节 normalize。生成 `Move.lock` 原字节相等，SHA均为 `bb62b211f2f6cafee970d2cdc42ff1ec4d02ff6d532c475d7489cba86e67f742`。其中 Market 生产模块 SHA为 `930c57abdfaf320df4012e7511664273e8249257f708f45f91fd4e0e6a20050d`。等价账两套194模块映射与实际文件完全一致。

冻结两图各1614个文件，共3228个输入，所有文件当前哈希与 manifest相等；对应工作图同样零漂移，文件集合精确。源码、已有锁、部署配置/地址分配metadata不曾因该被动扩展改变。Market manifest未加入被动包。181个安装输入guard对每份留存运行均与现状相等。范围内 Market 强迫源码/配置/制品修改次数0；实际安装、发布、部署次数0。

被动运行的 `source_before/source_after` 是3227条，具体为3222个冻结编译输入加5个外部驱动/被动输入，省略冻结图中6个AGENTS/CURRENT/PROJECT_MEMORY文档；本复核另行核验完整3228条 manifest，不能把3227运行快照描述成完整冻结图。001/002/003快照的driver正文对应historical003，004对应historical004，005对应当前正文；历史与当前的差异仅这份驱动，精确历史 pin全部可回溯。原生产003还保留Player测试桥添加前fixture哈希，仅此已知测试文件差异，由`fixture-player-bridge.json`精确解释，194生产源码快照无不匹配。

## 历史差异没有消失

`driver-source-transport.json` 的原正文 `d63418…` 到historical003 `cb6a98…`，独立重建后精确只含 Core→独立 Market import与默认fixture→Market私有角色fixture两项改写。003漏配真实250BPS，六项在MakerTerms实际费率守卫abort2，并非扩展被拒绝或成功。

`driver-fee-fixture-correction.json` 的historical004 `842275…` 精确等于旧最终成功正文 `b78ea9…` 加上述namespace/fixture改写与Config前后比较；原250BPS、Config revision1、Free ID和授权断言全部保留。004在同笔交易归还后再次取得Shared Config，六项报ScenarioEmptyInventory abort3，属于测试输入错误，不能标成PASS。

`driver-single-config-input-correction.json` 的当前正文 `c5bccd…` 精确只移除分支前Config归还和分支后Config重复取得，继续持有一次Config与assert11。未改变业务guard、Market输入或原行为断言。005六项才全部通过。详细差异、完整哈希与失败诊断计数保留于evidence。

## 既有记录附件与剩余检查

这是原 DOF-001 / P01 / P09 的证据附件，不新建任务板、不改Owner/status/CURRENT。手册v1.0（2026-10-06，SHA `1972858dffa38006f1d3784bcaca9370c52bdebade730b20bb0294b42125ec95`）适用§§1–4、5、6、7、8.3–8.4、9、12；Operating Model §8。Code/Build/Test局部验证通过；Release/Deploy/Operate/Monitor未执行。EVM、借贷/AMM/收益模型不适用，本轮没有新增金融路线或治理锁声明。

未知被动对象不强迫当前Market改变的有限命题已获支持。任意受保护Source、完整StandardHandover、私密内容/KMS/可撤销资格、最终一致图回归、默认预算失败收口、真实origins/Publisher/latestCap/角色注册、SDK/原UI和真实PTB仍待验收。实际链Gas、链部署、生产授权和用户旅程不能由VM测试producer或模块字节等价推导。继续保持NOT_INSTALL_READY，父目标未完成。

本复核只写当前新复核目录的verify.py/evidence.json/REPORT_CN.md/review.json；未改源码、CURRENT、已有records，未commit/push/PR。恢复依据是保留原冻结输入、历史失败与候选，不存在本轮链状态回滚。
