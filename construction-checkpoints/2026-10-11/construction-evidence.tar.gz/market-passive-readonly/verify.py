from pathlib import Path
import json, hashlib, re, difflib

R = Path(__file__).resolve().parent
B = R.parent
C = B / 'independent-market-current-candidate-v1'
D = B / 'independent-market-passive-driver-v2'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def check_map(mapping):
    return {'checked': len(mapping), 'mismatches': [n for n, h in mapping.items() if not Path(n).is_file() or sha(Path(n)) != h]}
def diff(a, b):
    return ''.join(difflib.unified_diff(a.read_text().splitlines(True), b.read_text().splitlines(True), fromfile=str(a), tofile=str(b)))
def modules(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*.mv'))}
def identities(raw):
    return {name: status for status, name in re.findall(r'\[\s*(PASS|FAIL)\s*\]\s+([^\s]+::[^\s]+)', raw)}

E = {'scope': 'Independent retained-evidence review only; no compiler/VM/network/node. Writes only this new review directory.', 'pins': {}}
F = read(C/'frozen/manifest.json'); Q = read(D/'independent-market-passive-equivalence.json')
E['pins']['frozen_manifest'] = {'actual': sha(C/'frozen/manifest.json'), 'expected': '3225bc37f9812b9b6ef4dd0f4c8521132096b58ab16982e5a5f461fcc2920104'}
E['freeze'] = {}
expected_source_hashes = {}
for g, m in F['graphs'].items():
    for sub in ['frozen/', '']:
        root=C/sub/g
        mapping={str(root/n): h for n, h in m.items()}
        result=check_map(mapping)
        result['exact_file_set'] = set(m) == {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
        E['freeze'][sub+g] = result
    for n,h in m.items(): expected_source_hashes[str(C/'frozen'/g/n)] = h
E['frozen_file_count'] = len(expected_source_hashes)

E['runs'] = {}
all_run_dirs = sorted((D/'runs').iterdir()) + [C/'003-production', C/'005-market44']
for run in all_run_dirs:
    r=read(run/'result.json'); raw=(run/'raw.log').read_text()
    rows=identities(raw)
    recorded=r['identities']
    source_root=C/('production-graph' if run.name=='003-production' else 'test-graph')
    resolved_before={str(Path(n) if Path(n).is_absolute() else source_root/n):h for n,h in r['source_before'].items()}
    current=check_map(resolved_before)
    guard=check_map(r['installed_before'])
    bytecode={str(p.relative_to(run)): sha(p) for p in sorted((run/'build').rglob('*.mv'))}
    cm=r.get('compiled_modules')
    allowed={h for n,h in expected_source_hashes.items() if n.endswith('.move')}
    allowed.update(sha(p) for p in (D/'passive').rglob('*.move'))
    history={'003-independent-market-six-vectors':D/'historical-driver-003.move','004-independent-market-six-vectors-fixed':D/'historical-driver-004.move'}
    driver=history.get(run.name,D/'driver/tests/compatibility.move')
    allowed.add(sha(driver))
    reconciled=dict(resolved_before)
    if run.parent==D/'runs':
        prior_driver=D/('historical-driver-004.move' if run.name.startswith('004-') else 'driver/tests/compatibility.move' if run.name.startswith('005-') else 'historical-driver-003.move')
        reconciled[str(D/'driver/tests/compatibility.move')]=sha(prior_driver)
        historical_snapshots_exact=all(sha(prior_driver)==h if n==str(D/'driver/tests/compatibility.move') else Path(n).is_file() and sha(Path(n))==h for n,h in resolved_before.items())
    else:
        historical_snapshots_exact=not current['mismatches']
        if run.name=='003-production':
            bridge=read(C/'fixture-player-bridge.json')
            row=next(x for x in bridge if x['path']=='production-graph/deps/move/soulidity_v1/tests/fixtures.move')
            fp=str(C/'production-graph/deps/move/soulidity_v1/tests/fixtures.move')
            historical_snapshots_exact=current['mismatches']==[fp] and resolved_before[fp]==row['old_sha256'] and sha(Path(fp))==row['new_sha256']
    # Earlier production was before the test-only Player bridge. Its production snapshots
    # never contain this fixture; existing current-review separately covers that history.
    snapshots=list((run/'build').rglob('sources/**/*.move'))
    bi=list((run/'build').rglob('BuildInfo.yaml'))
    E['runs'][str(run.relative_to(B))]={
        'result_sha256':sha(run/'result.json'), 'raw_sha256':sha(run/'raw.log'),
        'raw_hash_matches_record':sha(run/'raw.log')==r['raw_log_sha256'],
        'before_sha256':sha(run/'before.json') if (run/'before.json').exists() else None,
        'before_json_exact_result_subset': all(r.get(k)==v for k,v in read(run/'before.json').items()) if (run/'before.json').exists() else None,
        'exit_code':r['exit_code'], 'command':r['command'], 'overrides':r['overrides'],
        'sandbox_denies_network': any('deny network*' in str(x) for x in r['execution']),
        'raw_identities':rows, 'result_identities_equal_raw':rows==recorded,
        'summaries':r['summaries'], 'source_before_count':len(r['source_before']),
        'before_after_exact':r['source_before']==r['source_after'],
        'current_recorded_inputs':current, 'current_installed_guard':guard,
        'historical_input_snapshots_reconciled_exact':historical_snapshots_exact,
        'recorded_drift':r.get('source_drift',r.get('input_drift')),
        'recorded_new_inputs':r['new_inputs'], 'recorded_installed_drift':r['installed_drift'],
        'compiled_module_count':len(bytecode), 'compiled_record_exact':bytecode==cm if cm is not None else None,
        'compiled_source_count':len(snapshots),
        'compiled_source_unmatched':[str(p.relative_to(run)) for p in snapshots if sha(p) not in allowed],
        'driver_compiled_source_exact':all(sha(p)==sha(driver) for p in snapshots if p.name=='compatibility.move'),
        'build_info':{str(p.relative_to(run)): {'sha256':sha(p),'test_mode':re.search(r'test_mode: (\w+)',p.read_text()).group(1)} for p in bi},
        'compiled_modules':bytecode,
        'actual_installed':r['actual_installed'],
        'tool_current_hash_matches':Path(r['command'][0]).is_file() and sha(Path(r['command'][0]))==r['tool_sha256'],
    }
    if run.parent==D/'runs':
        frozen_recorded={n:h for n,h in r['source_before'].items() if n.startswith(str(C/'frozen'))}
        E['runs'][str(run.relative_to(B))]['frozen_snapshot_omissions'] = sorted(set(expected_source_hashes)-set(frozen_recorded))
        E['runs'][str(run.relative_to(B))]['nonfrozen_snapshot'] = {n:h for n,h in r['source_before'].items() if n not in expected_source_hashes}
    if run.name.startswith('003-independent'):
        E['runs'][str(run.relative_to(B))]['abort2_terms_occurrences']=raw.count('aborted with code 2 originating in the module soulidity_maker_terms::maker_resale')
    if run.name.startswith('004-independent'):
        E['runs'][str(run.relative_to(B))]['abort3_scenario_occurrences']=raw.count('aborted with code 3 originating in the module sui::test_scenario')

oldroot=C/'003-production/build/build/SoulidityMarket/bytecode_modules'
newroot=D/'runs/001-independent-market-production/build/build/SoulidityMarket/bytecode_modules'
old=modules(oldroot);new=modules(newroot)
E['production_literal_bytes']={'old_count':len(old),'new_count':len(new),'exact_paths_and_hashes':old==new,'actual_byte_differences':[n for n in old.keys()|new.keys() if not (oldroot/n).is_file() or not (newroot/n).is_file() or (oldroot/n).read_bytes()!=(newroot/n).read_bytes()], 'old_modules':old, 'new_modules':new,'ledger_old_exact':old==Q['market003_actual_modules'],'ledger_new_exact':new==Q['market001_actual_modules']}
l1=C/'003-production/build/Move.lock';l2=D/'runs/001-independent-market-production/build/Move.lock'
E['production_generated_lock']={'old':sha(l1),'new':sha(l2),'literal_bytes_equal':l1.read_bytes()==l2.read_bytes(),'ledger_exact':Q['generated_lock_hashes']=={str(l1.relative_to(B)):sha(l1),str(l2.relative_to(B)):sha(l2)}}

T=read(D/'driver-source-transport.json');H=read(D/'driver-fee-fixture-correction.json');S=read(D/'driver-single-config-input-correction.json')
original=Path(T['original_path']);final_original=Path(H['historical_final_source']);h3=D/'historical-driver-003.move';h4=D/'historical-driver-004.move';current=D/'driver/tests/compatibility.move'
transport=original.read_text().replace('use soulidity_v1::market::{Self, Listing};','use soulidity_market::market::{Self, Listing};').replace('fixtures::setup(0, 0, 0, 0, 0, 0)','market::setup_for_testing(0, 0, 0, 0, 0, 0)')
single=h4.read_text().replace('let cfg:Config<USD> = sc.take_shared();let frozen_config=economics::commitment(&cfg);test_scenario::return_shared(cfg);','let cfg:Config<USD> = sc.take_shared();let frozen_config=economics::commitment(&cfg);').replace('let cfg: Config<USD> = sc.take_shared(); assert!(economics::commitment(&cfg)==frozen_config,11);','assert!(economics::commitment(&cfg)==frozen_config,11);')
E['history']={'original_sha_exact':sha(original)==T['original_sha256'],'namespace_fixture_transport_only':transport==h3.read_text(),'historical003_sha_exact':sha(h3)==T['current_sha256']==H['old_failed_driver_sha256'],'original_final_sha_exact':sha(final_original)==H['historical_final_sha256'],'historical004_sha_exact':sha(h4)==H['new_sha256']==S['old_sha256'],'current_sha_exact':sha(current)==S['new_sha256'],'single_input_changes_only':single==current.read_text(),'diff003_to004':diff(h3,h4),'diff_original_final_to004':diff(final_original,h4),'diff004_to005':diff(h4,current)}
fee_transport=final_original.read_text().replace('use soulidity_v1::market::{Self, Listing};','use soulidity_market::market::{Self, Listing};').replace('fixtures::setup(0, 0, 0, 0, 0, 0)','market::setup_for_testing(0, 0, 0, 0, 0, 0)').replace('clock::destroy_for_testing(grant_clock); assert!(character::grant_count(&root) == 1, 11);','clock::destroy_for_testing(grant_clock); assert!(character::grant_count(&root) == 1, 11);\n    let cfg:Config<USD> = sc.take_shared();let frozen_config=economics::commitment(&cfg);test_scenario::return_shared(cfg);').replace('let cfg: Config<USD> = sc.take_shared(); let clock = clock::create_for_testing(sc.ctx());','let cfg: Config<USD> = sc.take_shared(); assert!(economics::commitment(&cfg)==frozen_config,11); let clock = clock::create_for_testing(sc.ctx());')
E['history']['final_original_plus_exact_transport_and_config_assertion_only']=fee_transport==h4.read_text()
E['pins']['candidate_result_manifest_pins']={'003-production':sha(C/'003-production/result.json')==F['successful_production_result'],'005-market44':sha(C/'005-market44/result.json')==F['successful_market44_result']}
E['pins']['review_inputs']={str(p.relative_to(B)):sha(p) for p in [D/'REPORT_CN.md',D/'SPEC.md',D/'driver-source-transport.json',D/'driver-fee-fixture-correction.json',D/'driver-single-config-input-correction.json',D/'independent-market-passive-equivalence.json',B/'independent-market-current-review-v1/REPORT.md',B/'independent-market-current-review-v1/evidence.json']}
root=current.read_text();market=(C/'frozen/test-graph/market/sources/market.move').read_text()
E['source_semantics']={
    'driver_sha256':sha(current),'passive_sha256':sha(D/'passive/sources/passive.move'),
    'independent_market_import': 'use soulidity_market::market::{Self, Listing};' in root,
    'six_test_names':re.findall(r'#\[test\] fun (\w+)\(',root),
    'private_role_test_setup': '#[test_only]\npublic fun setup_for_testing' in market and 'fixed_fee,MarketAuthority1{},MarketRevision3{})' in market,
    'same_held_config_runtime_assert11': 'let cfg:Config<USD> = sc.take_shared();let frozen_config=economics::commitment(&cfg);' in root and 'assert!(economics::commitment(&cfg)==frozen_config,11);' in root and 'let cfg: Config<USD> = sc.take_shared(); assert!(economics::commitment' not in root,
    'actual_commitment_values_exported':False,
    'root_id_origin_assert': 'object::id(root) == h.soul && standard::origin(root) == h.origin' in root,
    'bound_count_free_original_id_assert': 'character::bound_count(root) == 1 && character::free_id(&character::binding(root, b"free").destroy_some()) == option::some(h.free)' in root,
    'cancel_grant_preserved_assert': 'character::grant_count(&root) == 1, 12' in root,
    'sale_grant_cleanup_generation_assert': 'character::grant_count(&root) == 0 && character::generation(&root) == 1' in root,
    'buyer_has_no_external_objects_assert': 'h.sc.ids_for_sender<Attribute>().is_empty() && h.sc.ids_for_sender<Relation>().is_empty()' in root,
    'seller_retains_external_objects': 'h.sc.next_tx(@0xb); let a: Attribute = h.sc.take_from_sender_by_id(*h.attribute.borrow()); let r: Relation' in root,
    'market_manifest_has_passive_dependency': 'passive' in (C/'frozen/production-graph/market/Move.toml').read_text().lower(),
}
main=Path('/Users/naoer/Documents/Claude/Projects/soulidity/agent-management')
E['handbook']={'version':'1.0','applicable_sections':['1–4','5','6','7','8.3','8.4','9','12'],'handbook_sha256':sha(main/'PRODUCT_ENGINEERING_HANDBOOK_CN.md'),'operating_model_sha256':sha(main/'OPERATING_MODEL.md'),'operating_model_section':8,'existing_record_attachment':'DOF-001 / P01 / P09; no existing record/status/Owner edited'}
E['boundary']={'upstream':'Application010b; independentMarket3225','source_admission08460_core1061_whole_target_merge':False,'arbitrary_protected_source_compatibility_proven':False,'complete_standard_handover_proven':False,'realchain_production_authority_proven_by_vm_fixture':False,'gas_ui_sdk_ptb_chain_release_installation_proven':False,'reviewer_runtime_count':0,'write_scope':str(R)}
(R/'evidence.json').write_text(json.dumps(E,indent=2)+'\n')
print(json.dumps({'freeze':E['freeze'],'frozen_file_count':E['frozen_file_count'],'runs':{k:{n:v[n] for n in ['exit_code','raw_hash_matches_record','result_identities_equal_raw','current_recorded_inputs','current_installed_guard','compiled_source_count','compiled_source_unmatched','compiled_record_exact']} for k,v in E['runs'].items()},'production_equal':old==new,'lock_equal':E['production_generated_lock']['literal_bytes_equal'],'history':{k:v for k,v in E['history'].items() if not k.startswith('diff')},'source_semantics':E['source_semantics']},indent=2))
