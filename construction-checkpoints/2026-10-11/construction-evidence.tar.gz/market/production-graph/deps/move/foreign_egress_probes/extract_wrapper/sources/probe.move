module probe::probe;
public fun extract(h:soulidity_custody::account::AccountHandover):soulidity_standard::soul::Handover{let soulidity_custody::account::AccountHandover{account:_,kiosk:_,actor:_,operation:_,source:_,inner}=h;inner}
