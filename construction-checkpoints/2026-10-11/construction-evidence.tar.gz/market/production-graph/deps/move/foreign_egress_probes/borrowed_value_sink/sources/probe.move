module probe::probe;
public fun finish(h:&mut soulidity_custody::account::AccountHandover):sui::object::ID{soulidity_standard::soul::finish_handover(*soulidity_custody::account::handover_mut(h),@0xb)}
