module probe::probe;
public fun forge():soulidity_application::character::ApplicationWitness{soulidity_application::character::ApplicationWitness{}}
