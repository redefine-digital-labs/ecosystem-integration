module probe::probe;
public struct Store has key,store{id:sui::object::UID,h:soulidity_custody::account::AccountHandover}
