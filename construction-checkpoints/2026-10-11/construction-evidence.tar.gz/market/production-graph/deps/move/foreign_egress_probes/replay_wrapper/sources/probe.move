module probe::probe;
public fun replay(k:&mut sui::kiosk::Kiosk,a:&mut soulidity_custody::account::Account,h:soulidity_custody::account::AccountHandover,ctx:&sui::tx_context::TxContext){
 soulidity_application::character::finish_account_deposit(k,a,h,ctx);
 soulidity_application::character::finish_account_deposit(k,a,h,ctx);
}
