module probe::probe;
public fun borrow(h:&mut soulidity_custody::account::AccountHandover):&mut soulidity_standard::soul::Handover{soulidity_custody::account::handover_mut(h)}
