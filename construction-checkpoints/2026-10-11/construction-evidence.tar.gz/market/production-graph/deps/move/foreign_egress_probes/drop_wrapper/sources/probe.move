module probe::probe;
public fun discard(h:soulidity_custody::account::AccountHandover){}
