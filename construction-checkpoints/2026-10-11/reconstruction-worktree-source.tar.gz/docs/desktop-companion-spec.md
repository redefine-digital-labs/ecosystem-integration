# Desktop Companion — Soulidity Desktop Persona Manager

---

## Goal

构建桌面形象管理应用，将 Soulidity Soul 生态延伸到桌面端。核心能力：根据 LLM CLI（Claude Code / Codex）的运行状态实时切换桌面形象动画，形象资产从 Soul 市场下载并通过链上访问控制保护，桌面端自带 Sui agent 地址参与 Soul 交互。

## Scope

### Phase 1 — Companion Shell（已完成）

1. **统一状态协议** — `~/.soulidity/agent-status.json` 文件监听 + Claude Code / Codex 适配器
2. **悬浮球 Electron 应用** — FloatingBall 透明悬浮窗口 + MainWindow 管理窗口
3. **Sprite Sheet 渲染** — Canvas API 逐帧动画，接入本地默认 persona 和 CLI 状态驱动
4. **桌面 Agent 钱包** — 每设备一个 Ed25519 agent 地址，显示于 MainWindow / SettingsTab
5. **情绪系统（基础）** — 4 态 emotion（idle/busy/done/night）+ CLI 6 态映射，后端 LLM 生成互动语

### Phase 1.5 — 被动检测与 Mood 升级（已完成，OpenCode 适配待补）

1. **AgentMonitor 被动检测** — 进程探测（pgrep）+ JSONL 会话日志监听，无 hook 也能感知 CLI 状态
2. **12 Mood 系统** — CLI 6 态 + 上下文规则映射，替代当前 4 emotion
3. **双窗口模型** — MainWindow（library / market / settings / agent 管理）+ OverlayWindow
4. **OpenCode 适配器** — `soulidity-opencode-plugin.ts`

### Phase 2 — Soul Integration

1. **SoulMetadata 扩展** — 独立共享对象 `SoulMetadata` 保存 active sprite / voice binding，扩展 JSON 配置放 `ext` table
2. **SoulAssets 内容层** — Move 模块，与 Skills 同构（`Table<String, vector<AssetSlot>>`）
3. **ContentAccessList** — Move 模块，独立于 grant 的内容访问权售卖机制
4. **账号与内容联动** — Privy 钱包 + 桌面 agent 地址绑定、市场下载、受保护内容访问
5. **Soul 抽取铸造** — 从本地 LLM 对话日志提取人格特征，引导用户铸造 Soul

### 不做（预留）

- Live2D 高级渲染格式
- 语音系统（预录音频 + TTS 实时合成）
- 桌面端聊天面板 / LLM 对话能力 / LLM Key 配置（已清理）

---

## Locked Decisions

| 决策 | 结论 | 原因 |
|------|------|------|
| 桌面运行时 | Electron（Desktop-Claw fork） | 不保留 Tauri 并行方案 |
| 钱包存储 | Electron `safeStorage` API（OS keychain 加密） | Phase 1 JSON → Phase 1.5 迁移到 safeStorage |
| 地址推导 | `keypair.toSuiAddress()` / Sui SDK 语义 | 不手写 SHA-256/blake2b |
| 状态协议 | 6 态文件协议 `~/.soulidity/agent-status.json` | 统一 CLI 适配 |
| 检测策略 | Phase 1 仅 Hooks 主动上报；Phase 1.5 追加 AgentMonitor 被动检测 | 分阶段交付 |
| 情绪系统 | Phase 1: 4 态 emotion + CLI 6 态映射；Phase 1.5: 12 mood | 分阶段交付 |
| Sprite 渲染 | 原生 Canvas API + requestAnimationFrame | 不引入 Phaser/Pixi |
| 依赖位置 | Phase 1 所有桌面依赖放 `apps/desktop/package.json` | 不放 `packages/backend` |
| 后端架构 | 纯 IPC（无 HTTP 服务器） | Phase 1.5 从 Fastify 迁移；无端口冲突、打包更简单、调用链更短 |
| Agent 检测 | 声明式 `AGENT_CONFIGS`（claude-code / codex / opencode） | 每个 agent 声明 processPatterns + logPaths + filePatterns |
| 文件监听 | chokidar（替代 fs.watch） | 跨平台可靠、内置 awaitWriteFinish 防抖 |
| 配置存储 | `electron-store`（替代手写 JSON 读写） | 原子写入、schema 验证、迁移支持 |
| 自动更新 | `electron-updater` + GitHub Releases | autoDownload=false，用户手动触发 |
| 自定义协议 | `soulidity://` deep link | settings / install-sprite 入口 |
| 单实例锁 | `requestSingleInstanceLock` | 防双开，deep link 转发到已有实例 |

---

## Architecture

### Tech Stack

Electron, React, electron-vite, pnpm workspace, chokidar, Canvas API, `@mysten/sui`, `electron-store`, `electron-updater`（纯 IPC 架构，无 HTTP 后端）

### Workspace Layout

```
desktop/                          # Desktop-Claw-based pnpm workspace
├── apps/desktop/
│   ├── src/main/                 # Electron main process
│   │   ├── index.ts              # lifecycle, IPC handlers, window management
│   │   ├── status-watcher.ts     # ~/.soulidity/ file watcher + dedup
│   │   ├── agent-monitor.ts      # 被动检测 (ProcessProbe + LogWatcher + HookDetector)
│   │   └── agent-wallet.ts       # Ed25519 keypair + safeStorage
│   ├── src/preload/              # IPC bridge
│   ├── src/renderer/
│   │   ├── components/
│   │   │   ├── FloatingBall/     # overlay sprite + task tooltip/toast/drop/output interaction
│   │   │   ├── MainWindow/       # 三 tab 管理面板 (Settings/Library/Agent)
│   │   │   └── SpriteRenderer.tsx # Canvas sprite sheet animation
│   │   └── hooks/
│   │       ├── useCliStatus.ts   # CLI status subscription
│   │       ├── useMood.ts        # IPC mood snapshot polling
│   │       └── useMoodResolver.ts # drag state override
│   └── resources/
│       ├── hooks/                # CLI adapter scripts
│       └── default-persona/      # bundled sprite assets
├── packages/backend/             # Service 层（纯 IPC，无 HTTP 服务器）
│   └── src/
│       ├── memory/               # MoodService, GreetingService, MemoryService
│       ├── llm/                  # LLM client (greeting/memory 用)
│       └── paths.ts              # 数据目录管理
└── packages/shared/              # shared types
    └── src/types/
        ├── cli-status.ts         # 6 态 + source + opencode
        ├── emotion.ts            # Mood (12 态), MoodSnapshot, EmotionState (legacy)
        └── pet.ts                # PetTaskSummary, PetAgentEvent, PetUpdateStatus
```

### Window Model

```
Electron Main Process
├── window lifecycle (FloatingBall + MainWindow)
├── status watcher (hooks 层)
├── wallet IPC
└── config management

FloatingBall Window（透明悬浮 companion）
├── transparent, frameless, alwaysOnTop, skipTaskbar
├── 尺寸：随 sprite 配置动态调整（默认资源约 200x230）
├── 位置：记忆上次位置（config.json → ballPosition）
├── 内容：Canvas sprite 动画 + 任务 tooltip / toast / update bubble + 原生右键菜单
└── 点击穿透：轮询光标位置，球区域内接收事件

MainWindow（设置面板）
├── agent wallet 地址显示（只读 + 复制）
├── library / settings / agent 三 tab
└── account linking / CLI monitor / persona 管理
```

### Interaction

| 操作 | 行为 |
|------|------|
| 拖拽 | 移动位置，松手保存 |
| Hover（有活跃任务） | 显示任务 tooltip（agent、会话、当前动作、工作目录摘要） |
| 文件拖入 | 打开任务说明面板，提交后显示 live output，可取消 |
| 右键 | 原生上下文菜单：Settings / Hide Character / Check for Updates / Quit |
| 状态变化 | 切换 sprite 动画 + CSS halo 呼吸效果 |
| 无活跃 session | 显示 idle 动画 |

### Local Storage

```
data/                             # userData/data/ (prod) or desktop/data/ (dev)
├── config.json                   # ballPosition, general settings
├── persona/                      # SOUL.md, USER.md, CONTEXT.md
├── memory/                       # conversation archives, greeting cache
├── db/                           # local state
└── files/                        # user files

userData/state/
├── agent_keypair.json            # 公开 metadata（address/publicKey/createdAt）
└── agent_secret.enc              # private key，经 Electron safeStorage 加密
```

---

## Module Specifications

### Module 1 — Hooks 主动上报层

**文件结构：**
```
~/.soulidity/
├── agent-status.json          # 当前唯一 source of truth（Electron watcher 监听）
└── sessions/
    └── {session_id}.json      # 预留：按 session 拆文件的扩展目录
```

**状态模型：**
```typescript
interface AgentStatusFile {
  version: 1
  lastUpdated: number
  sessions: Record<string, AgentSession>
}

interface AgentSession {
  sessionId: string
  clientType: 'claude-code' | 'codex' | 'opencode' | 'custom'
  status: 'idle' | 'thinking' | 'working' | 'needs-attention' | 'completed' | 'error'
  workingDirectory?: string
  sessionTitle?: string
  currentAction?: {
    tool?: string
    details?: string
    timestamp: number
  }
  needsAttention?: string
  startedAt: number
  lastUpdated: number
  endedAt?: number
}
```

**适配器：**

`soulidity-claude-hook.cjs` — 6 种 Claude Code hook 事件：

| Hook Event | → Status |
|------------|----------|
| `SessionStart` | `idle` |
| `UserPromptSubmit` | `working` |
| `PreToolUse` | `working` + currentAction |
| `PostToolUse` | `working`（清除 currentAction） |
| `Stop` | `completed` |
| `SessionEnd` | `idle` |

- stdin 接收 JSON，原子写入（temp + rename）
- 检测 attention tools（AskUserQuestion、ExitPlanMode）→ `needs-attention`
- 24h 自动清理过期 session

`soulidity-codex-hook.cjs` — Codex `notify` 事件：

| Event Type | → Status |
|------------|----------|
| `agent-turn-complete` | `completed` |

**Electron 主进程侧（status-watcher.ts）：**
- watch `~/.soulidity/`，启动时先读一次当前状态
- debounce 后解析 JSON，广播 `agent-status-changed` 到所有窗口
- 容忍原子写入过程中的短暂半成品文件

### Module 2 — Mood 与 Pet 反馈系统（当前实现）

**12 态 Mood + 任务驱动反馈：**

后端 `MoodService` 输出 `MoodSnapshot`，前端通过 `useMood.ts` 订阅；宠物层额外消费 `PetTaskSummary`、`PetAgentEvent`、`PetUpdateStatus`，把 CLI / task / updater 状态统一编排成 companion 反馈。

| 层级 | 当前实现 |
|---|---|
| Mood | `idle / happy / love / excited / celebrate / sleepy / snoring / working / angry / surprised / shy / dragging` |
| Sprite | 由 `MOOD_TO_SPRITE` 映射到 sprite 动画；`dragging` 优先请求独立动画 |
| Task 反馈 | hover task tooltip、完成/报错/attention toast、update bubble、文件拖拽任务面板 |

**关键规则：**
- CLI / AgentMonitor 的 6 态文件协议仍是基础 source of truth
- `derivePetAgentEvents()` 把 session 变化归一成 `agent-active / agent-idle / task-complete / task-error / needs-attention`
- 宠物窗口保留原生右键菜单，任务状态优先于旧陪伴型随机冒泡
- 启动问候、自动 idle 气泡、`ChatBubble` 主反馈链已从当前实现中移除

### Module 3 — Sprite Sheet 渲染

**配置：**
```typescript
interface SpriteSheetConfig {
  src: string
  frameWidth: number
  frameHeight: number
  columns: number
  animations: {
    [stateName: string]: {
      frames: number[]
      fps: number
      loop: boolean
    }
  }
}
```

**SpriteRenderer：** React 组件，Canvas API 逐帧渲染。接收 `config`、`animation`（状态名）、`width`、`height`。

**默认 persona（乌萨奇）：** 4096x3584 PNG，8 列 x 7 行，512x512 帧，共 56 帧。

| 行 | 帧范围 | 动画名 |
|----|--------|--------|
| 0 | 0-7 | idle |
| 1 | 8-15 | thinking |
| 2 | 16-23 | completed |
| 3 | 24-31 | working |
| 4 | 32-39 | needs-attention |
| 5 | 40-47 | error |
| 6 | 48-55 | dragging |

`SpriteRenderer` 当前支持“可选 dragging 动画”策略：若 persona 提供 `dragging` 帧段则优先播放；若未提供则运行时自动 fallback 到 `idle`。

CSS halo 当前通过 `data-mood` 属性驱动。

### Module 4 — Agent 钱包

```ts
interface AgentKeypairInfo {
  address: string     // Sui address (0x...)
  publicKey: string   // hex-encoded
  createdAt: number
}
```

- Sui SDK `toSuiAddress()` 推导地址
- 公开 metadata 写入 `userData/state/agent_keypair.json`
- private key 写入 `userData/state/agent_secret.enc`，由 Electron `safeStorage` 加密
- 每台设备一个 agent 地址
- MainWindow / SettingsTab 显示地址（可复制）

### Module 5 — 主进程服务层（纯 IPC）

纯 IPC 架构，无 HTTP 服务器。Services 运行在 Electron 主进程，渲染进程通过 `contextBridge` IPC 通道调用。

**IPC 通道（替代原 Fastify 路由）：**

| IPC channel | 功能 |
|---|---|
| `mood:get` | 返回当前 MoodSnapshot |
| `mood:interact` | 用户互动信号 |
| `mood:drag-start` / `mood:drag-end` | 拖拽状态 |
| `persona:get` | 返回 SOUL.md / USER.md / CONTEXT.md |
| `task:execute` / `task:cancel` | 从宠物窗口发起或取消 CLI 任务 |
| `updater:status` | 返回当前更新状态快照 |
| `contextmenu:show` / `pet:hide` | 原生右键菜单与隐藏宠物 |
| `agent-event` / `update-status` / `task:output` / `task:complete` | main → renderer 推送事件 |

**后端服务：**
- `MoodService` — 12 mood 状态机，1 分钟 tick，跨小时边界检测
- `TaskExecutor` — spawn claude/codex CLI，逐 chunk 推送任务输出
- `Updater` — GitHub Releases 更新检查 / 下载 / 安装状态管理
- `MemoryService` — 对话归档、日级压缩、sealDay

### Module 6 — Soul Metadata 扩展（Phase 2）

Soul 链上不再把 persona metadata 挂在 `Soul` 本体；改为独立共享对象 `SoulMetadata`。

```typescript
interface SoulMetadata {
  version: 1
  persona?: {
    format: 'sprite-sheet' | 'live2d'
    moodMap: {
      idle: string; happy: string; love: string
      excited: string; celebrate: string
      sleepy: string; snoring: string
      working: string
      angry: string; surprised: string; shy: string
      dragging: string
    }
    publicAssets?: SpriteSheetAsset
    protectedAssets?: { assetName: string; versionIndex: number }
  }
  voice?: { /* 预留 */ }
  extra?: Record<string, unknown>
}
```

**桌面端下载流程：** 读 mirrored `metadataOnChainId + activeSprite* + spriteConfigJson/spriteMoodMapJson` → public 直接下载 active asset version / owner_only 与 allowlist 走链上访问控制 → 存入本地。

### Module 7 — SoulAssets 内容层（Phase 2）

与 `skills.move` 同构设计。

```move
public struct AssetSlot has copy, drop, store {
    blob_object_id: ID,
    is_public: bool,
    deleted: bool,
    asset_type: u8,     // 0=sprite, 1=live2d, 2=audio
    created_at_ms: u64,
}

public struct SoulAssets has key {
    id: UID,
    soul_id: ID,
    assets: table::Table<String, vector<AssetSlot>>,
    asset_count: u64,
}
```

**API Routes：**

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/souls/[id]/assets` | GET | 列出资产 |
| `/api/souls/[id]/assets/[assetName]/versions/[versionIndex]/access` | GET | Human 访问 |
| `/api/agent/souls/[id]/assets/[assetName]/versions/[versionIndex]/access` | GET | Agent 访问 |
| `/api/souls/[id]/assets/append` | POST | 上传新版本 |
| `/api/souls/[id]/assets/[assetName]/versions/[versionIndex]/delete` | POST | 软删除 |

### Module 8 — ContentAccessList（Phase 2）

独立于 grant 体系，但每条 entry 都绑定创建时的 Soul ownership epoch。Soul 转手后，旧 entry 保留用于审计，但访问判定自动失效；买家需要在新 owner epoch 下重新购买或由新 owner 重新授权。

```move
public struct ContentAccessList has key {
    id: UID,
    soul_id: ID,
    creator: address,
    price_atomic: u64,
    default_scope_mask: u64,
    default_access_duration_ms: Option<u64>,  // None = lifetime
    entries: table::Table<address, ContentAccessEntry>,
    entry_count: u64,
}

public struct ContentAccessEntry has store {
    scope_mask: u64,
    price_paid_atomic: u64,
    granted_at_ms: u64,
    expires_at_ms: Option<u64>,
    ownership_epoch_snapshot: u64,
}
```

**访问判定优先级：**
1. viewer 是 owner → `seal_approve_*_read_owner`
2. viewer 有 active grant → `seal_approve_*_read_granted_agent`
3. viewer 在 ContentAccessList → `seal_approve_*_allowlisted`
4. 均不满足 → 403

**购买约束（2026-04-23 审计后强化）：**
- `purchase_content_access` 要求 `price_atomic > 0`；免费 access 只能走 owner 直调 `add_access`
- 要求 `state.access_list_id == object::id(access_list)` 双向匹配
- `default_scope_mask` 必须是 `SCOPE_SEAL|MEMORY|SKILLS|ASSETS`（1/2/4/8）的非零子集
- `default_access_duration_ms` 决定 `record_purchase` 写入的 `expires_at_ms`；owner 可通过 `set_content_access_duration` 随时更新，只影响后续购买
- `has_access` 同时校验 `expires_at_ms` 与 `ownership_epoch_snapshot == SoulState.ownership_epoch`；过期或旧 owner epoch 的地址都返回无权限

### Module 9 — 双钱包与 Agent 身份（Phase 2）

| 场景 | 钱包 |
|------|------|
| 购买 Soul / 内容 / 铸造 | Privy 钱包 |
| 接收 grant / 读写 memory/skills | Agent 地址 |
| 下载已购形象（allowlist） | Privy 钱包地址 |

**登录绑定：** 浏览器登录 → 桌面端上报 agent_address → `POST /api/desktop/me/agent` → 关联到 Member

### Module 10 — Soul 抽取铸造（Phase 2）

从本地 LLM 对话日志中提取人格特征，引导用户构建 Soul 并铸造上链。

---

## Web Desktop API Routes（Phase 1 集成，位于 `web/app/api/desktop/*`）

### Prisma Models

`DesktopProfile`, `DesktopCatalogEntry`, `DesktopDeviceSession` — 详见 `prisma/schema.prisma`。

### API Endpoints

| Endpoint | Method | Auth | Purpose |
|----------|--------|------|---------|
| `/api/desktop/me` | GET | Human | profile + active persona |
| `/api/desktop/me/active-persona` | PUT | Human | 切换 active persona |
| `/api/desktop/catalog` | GET | Anonymous | 分页 catalog |
| `/api/desktop/catalog/[id]` | GET | Anonymous | persona manifest + 下载信息 |
| `/api/desktop/device/start` | POST | Anonymous | 创建设备绑定 session |
| `/api/desktop/device/poll` | POST | Anonymous | 轮询绑定状态 |
| `/api/desktop/device/complete` | POST | Human | 确认设备绑定 |

### 支撑库

| 文件 | 功能 |
|------|------|
| `web/lib/desktop/profile.ts` | getDesktopMe, setDesktopActivePersona |
| `web/lib/desktop/device-session.ts` | start/poll/complete DesktopDeviceSession |
| `web/lib/desktop/repository.ts` | listDesktopCatalogItems, findDesktopPersonaManifestById |
| `web/lib/types/desktop.ts` | Desktop API response types |

---

## Data Flow

### 创作者发布形象资产（Phase 2）

```
绘制 sprite sheet
  → 上传 Walrus（加密或公开）
  → 把 sprite.config / sprite.mood_map JSON 直接编码进 mint PTB
  → mint Soul + share `SoulMetadata`
  → 可选：设定内容访问价格
  → marketplace 展示
```

### 买家购买与使用

```
浏览 marketplace → 预览公开形象
  → purchase_content_access() 链上 USDC 付款
  → 地址加入 ContentAccessList
  → web 端可查看已购内容

桌面端：
  → 登录 → 浏览已购形象
  → 下载解密到本地 → 选择 active persona → 悬浮窗口展示
  → file watcher 监听 CLI 状态 → 状态变化 → sprite 切换动画帧
```

### Agent 授权

```
用户有 Soul → web 端给桌面 agent 地址 issue grant
  → 桌面端 agent 通过 grant 访问 memory/skills
  → 未来：agent 自主读写
```

---

## Constraints

- Desktop-Claw Electron workspace 为基础扩展，不保留 Tauri
- Move 新增模块不修改现有 Soul/SoulState 核心字段（除 `assets_id: Option<ID>`）
- SoulAssets 与 Skills 同构，复用 event parsing、mirror、repository 模式
- ContentAccessList 独立于 grant 体系，但 entry 受 `ownership_epoch_snapshot` 约束；Soul 转手后旧 access row 保留但不再授权
- 适配器脚本保持极简（单文件 Node.js，零依赖）
- Soul 抽取只提取统计和风格特征，不上传原始对话内容
- 所有链上操作 DB 同步走 post-TX direct write 模式

## Acceptance Criteria

### Phase 1

1. Claude Code hook 安装后，悬浮窗口形象随 CLI 状态实时切换（idle / working / completed）
2. Codex hook 安装后，agent-turn-complete 反映在悬浮窗口
3. FloatingBall 渲染乌萨奇 sprite 动画（不是 emoji）
4. 宠物窗口保留原生右键菜单，菜单项为 `Settings / Hide Character / Check for Updates / Quit`
5. 7 个 Web Desktop API 端点可用且有相关测试
6. Agent 钱包首次启动自动生成，地址显示在 MainWindow / SettingsTab

### Phase 1.5

7. AgentMonitor 无 hook 检测：未安装 hook 时，通过进程探测 + JSONL 日志解析仍可感知 agent 状态
8. 多 agent 并行：同时运行多个 CLI（如 Claude Code + Codex）时，事件正确聚合
9. 12 mood 系统替代 4 emotion，旧 greeting / auto-bubble 主反馈链退出宠物窗口
10. MainWindow + OverlayWindow 双窗口模型
11. Electron `safeStorage` 私钥加密存储
12. 宠物窗口支持任务 tooltip、完成/报错/attention toast、更新气泡、文件拖拽任务面板、live output
13. 自定义 sprite 支持可选 `dragging` 动画；缺失时自动 fallback 到 `idle`

### Phase 2

12. 从 marketplace 浏览并下载 sprite sheet 格式的 Soul 形象到桌面端
13. 创作者上传形象资产到 SoulAssets（public 或 private）
14. 买家通过 purchase_content_access 付款后可解密下载 private 形象
15. creator/owner 可通过 add_access 手动添加到 ContentAccessList
16. Soul owner 给桌面 agent 地址 issue grant 后，agent 可访问 Soul 内容
17. Soul 抽取：从本地 Claude Code / Codex 对话日志提取人格特征，生成 SoulProfile，引导铸造上链

### 通用

18. `sui move test --path move/soulidity` 通过
19. `pnpm --dir desktop typecheck` 通过
20. `pnpm --dir desktop build` 通过
21. `npm test` 相关测试通过
22. `npm --prefix web run typecheck` 通过
23. `npm --prefix web run build` 通过

---

## Implementation Status

### Phase 1 — Complete

以下为初版 shell 落地项；已被 Phase 1.5 替代或清理的旧入口不再在此处重复标记为“当前实现”。

- [x] Desktop-Claw fork + Soulidity branding
- [x] `desktop/packages/shared/src/types/cli-status.ts`
- [x] `desktop/apps/desktop/src/main/status-watcher.ts`
- [x] `desktop/apps/desktop/resources/hooks/soulidity-claude-hook.cjs`
- [x] `desktop/apps/desktop/resources/hooks/soulidity-codex-hook.cjs`
- [x] 默认 persona 资源（乌萨奇 sprite bundle）
- [x] `SpriteRenderer.tsx` — Canvas sprite sheet 渲染
- [x] `useCliStatus.ts` — CLI status subscription
- [x] Agent wallet（Ed25519 keypair, JSON storage）
- [x] 初版 `FloatingBall` shell（透明窗口、拖拽、CLI 状态驱动）
- [x] Web Desktop API：profile / catalog / device start / poll / complete
- [x] Desktop 相关测试文件
- [x] CI/CD release workflow（`.github/workflows/desktop-release.yml`）

### Phase 1 — Drift Cleaned

以下代码已从仓库移除，不再扩展：

- [x] ~~ChatPanel / CalendarView / DayDetailView~~ — 删除
- [x] ~~QuickInput~~ — 删除
- [x] ~~ClawProfile~~ — 删除（仅 ChatPanel 使用）
- [x] ~~useClawSocket~~ — 删除
- [x] ~~ChatBubble/~~ — 删除（宠物主反馈改为 task-driven tooltip / toast / update bubble）
- [x] ~~llm-config.ts~~ — 删除（SettingsPanel 不再配置 LLM）
- [x] ~~gateway/ws.ts~~ — 删除（WebSocket 聊天）
- [x] ~~gateway/calendar.ts~~ — 删除（日历查询）
- [x] ~~task-coordinator/~~ — 删除（聊天任务队列）
- [x] ~~panel window creation~~ — 删除（三窗口 → 两窗口）
- [x] ~~QuickInput IPC~~ — 删除（toggle / reposition）
- [x] ~~file drop → panel IPC~~ — 删除

### Phase 1 — Known Gaps

- [x] ~~`keytar` 私钥存储未接入~~ — Phase 1.5 改用 Electron `safeStorage` API 实现 OS keychain 加密（`agent-wallet.ts`）
- [x] ~~Agent 钱包地址尚未从 SettingsPanel 链到 web 端账号绑定~~ — 设备绑定全链路：`POST /api/desktop/device/start`（含 agentAddress）→ Desktop 显示 userCode → Web `/desktop/link` 页面输入确认 → `DesktopProfile.agentAddress` 写入

### Phase 1.5 — Complete

- [x] `desktop/apps/desktop/src/main/agent-monitor.ts` — ProcessProbe（pgrep 5s 轮询）+ HookDetector（检测已安装 hook 避免重复）
- [x] `desktop/apps/desktop/src/main/status-watcher.ts` — `deduplicateSessions()` hook/monitor 去重
- [x] `desktop/packages/shared/src/types/cli-status.ts` — `source` 字段 + `opencode` clientType
- [x] `desktop/packages/shared/src/types/emotion.ts` — `Mood`（12 态）+ `MoodSnapshot` + `MOOD_TO_SPRITE` + `MOOD_PARAMS`
- [x] `desktop/packages/backend/src/memory/mood.ts` — `resolveMood()` 纯函数，12 mood 优先级推导 + 话术池
- [x] `desktop/packages/backend/src/memory/mood-service.ts` — `MoodService` 替代 `EmotionService`
- [x] `desktop/packages/backend/src/gateway/emotion.ts` — `GET /emotion` 返回 `MoodSnapshot`，新增 drag-start/drag-end
- [x] `desktop/apps/desktop/src/renderer/hooks/useMood.ts` — 替代 `useClawEmotion`
- [x] `desktop/apps/desktop/src/renderer/hooks/useMoodResolver.ts` — drag 状态前端 override
- [x] `FloatingBall` — `data-mood` 驱动 12 mood halo 动画
- [x] `desktop/packages/shared/src/types/pet.ts` — `PetTaskSummary` / `PetAgentEvent` / `PetUpdateStatus`
- [x] `desktop/apps/desktop/src/main/index.ts` — 保留原生宠物右键菜单，新增 `agent-event` / `update-status` 广播与 task / updater IPC
- [x] `desktop/apps/desktop/src/preload/index.ts` — 暴露 `hidePet()` / `onAgentEvent()` / `onUpdateStatus()` / task stream API
- [x] `FloatingBall` — hover task tooltip、完成/报错/attention toast、update bubble、文件拖拽任务面板、live output
- [x] `MainWindow` — 三 tab（Settings / Library / Agent）替代 SettingsPanel
- [x] `agent-wallet.ts` — `safeStorage` 加密私钥 + Phase 1 JSON 自动迁移
- [x] ~~`useClawEmotion.ts`~~ — 删除（被 `useMood.ts` 替代）
- [x] ~~`SettingsPanel/`~~ — 删除（迁入 `MainWindow/SettingsTab`）
- [x] ~~启动 greeting / 自动 idle 气泡链路~~ — 删除（宠物反馈改为任务优先）
- [x] 设备绑定全链路：Prisma `agentAddress` 字段 + Web API start/complete + Web `/desktop/link` 页面 + Desktop SettingsTab Link Account + IPC 代理
- [x] Fastify → 纯 IPC 迁移：删除 Fastify HTTP 后端，所有 Service 通过 IPC 直调；删除 `gateway/`, `security/request-auth.ts`, `backend-client.ts`；删除 `fastify`, `@fastify/websocket`, `ws` 依赖
- [x] 声明式 `AGENT_CONFIGS`：3 agent（claude-code / codex / opencode），每个声明 processPatterns + logPaths + filePatterns
- [x] chokidar 替代 fs.watch：`status-watcher.ts` 使用 chokidar + awaitWriteFinish
- [x] `electron-store` 替代手写 config：`readConfig/writeConfig` → `store.get/set`
- [x] System Tray：托盘图标 + Show/Hide/Settings/Check for Updates/Quit 菜单
- [x] 单实例锁：`requestSingleInstanceLock` + deep link 转发
- [x] `soulidity://` 自定义协议：macOS `open-url` + Windows `second-instance` 双路径
- [x] 窗口自适应尺寸：`resize-pet-window` IPC，FloatingBall 根据 sprite 配置动态调整
- [x] `task-executor.ts`：spawn claude/codex CLI，stream-json 输出 → IPC 逐 chunk 推送
- [x] `electron-updater` 自动更新：check/download/install IPC + GitHub Releases publish config
- [x] `cache-manager.ts`：sprite/persona 本地缓存（cache/get/has/prune/stats/list）
- [x] `SpriteRenderer.tsx` + 默认 persona — `dragging` 动画接线完成；无第七行 persona 自动 fallback 到 `idle`

### Phase 1.5 — Known Gaps

- [ ] `soulidity-opencode-plugin.ts`（OpenCode 适配器，待 OpenCode 稳定后实现）

### Phase 2 — Already Landed In Move / Web Layer

- [x] Move contracts：`move/soulidity/sources/assets.move`, `content_access.move`
- [x] Prisma schema：`SoulAssetVersionRecord`, `ContentAccessRecord`
- [x] Mirror functions：`web/lib/soulidity/mirror/upsert-asset.ts`, `upsert-content-access.ts`
- [x] Event extraction：asset append / asset delete / content access created
- [x] TX builders：`web/lib/soulidity/tx/content-access.ts`, `publish.ts`
- [x] API routes：assets, access-list, human + agent access
- [x] Seal crypto：`generateAssetDocumentIdForVersion`
- [x] Move protocol tests：SoulAssets + ContentAccessList
- [x] Soul metadata parsing + desktop catalog / bundle / download flow

### Phase 2 — Desktop Consumption Still Pending
- [ ] 账号绑定（desktop agent → web account）
- [ ] Soul extraction：local session scanner
- [ ] Soul extraction：profile analyzer
- [ ] Soul extraction：mint flow UI

---

## Dead Code（保留但未激活）

以下后端模块在聊天链路移除后不再有活跃调用路径，但仍保留在代码中。它们是 Desktop-Claw 上游的核心功能，Phase 1.5 或 Phase 2 可能复用：

- `agent/` — Agent reasoning loop, skill management, prompt assembly
- `memory/interpret-service.ts` — 对话 interpret buffer（`feedInterpretBuffer` 不再被调用，`flushInterpretBuffer` 在 sealDay 中为 no-op）
- `memory/capsule-compiler.ts` — 日记胶囊编译
- `llm/` — LLM client（仍被 greeting-service 和 memory-service 活跃使用）

---

## Reference

- [Desktop-Claw](https://github.com/DjTaNg-404/Desktop-Claw) — Electron companion shell 上游
- [Confirmo](https://confirmo.app) — 桌面宠物参考：12 mood 系统、AgentMonitor 双层检测、JSONL 日志解析、celebrate 编排
- `desktop/docs/` — Desktop-Claw 上游产品策略和情绪设计文档
