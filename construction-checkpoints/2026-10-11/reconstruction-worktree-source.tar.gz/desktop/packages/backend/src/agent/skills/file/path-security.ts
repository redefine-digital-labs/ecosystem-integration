import { resolve, normalize, relative, isAbsolute, sep, dirname, delimiter } from 'path'
import { realpathSync, existsSync } from 'fs'
import { homedir } from 'os'

/** 按平台返回敏感路径前缀（绝对禁止访问） */
function getSensitivePrefixes(): string[] {
  const home = homedir()
  const common = [
    resolve(home, '.ssh'),
    resolve(home, '.gnupg'),
    resolve(home, '.aws'),
  ]
  if (process.platform === 'win32') {
    return [
      ...common,
      resolve('C:\\Windows'),
      resolve('C:\\Program Files'),
      resolve('C:\\Program Files (x86)'),
    ]
  }
  return [...common, '/etc', '/var', '/usr', '/System', '/private']
}

const SENSITIVE_PREFIXES = getSensitivePrefixes()

/**
 * 校验路径是否在允许的根目录内，阻止路径穿越和敏感路径访问。
 *
 * @param targetPath 用户请求访问的路径
 * @param allowedRoots 允许的根目录列表
 * @returns { valid, resolved, error }
 */
export function validatePath(
  targetPath: string,
  allowedRoots: string[]
): { valid: boolean; resolved: string; error?: string } {
  // 1. 解析为绝对路径并规范化
  const resolved = normalize(resolve(targetPath))

  // 2. 检查敏感路径
  for (const prefix of SENSITIVE_PREFIXES) {
    if (resolved.startsWith(prefix + sep) || resolved === prefix) {
      return { valid: false, resolved, error: `禁止访问敏感路径: ${prefix}` }
    }
  }

  // 3. 检查是否在 allowedRoots 内
  if (allowedRoots.length === 0) {
    return { valid: false, resolved, error: '未设置允许的文件访问目录（allowedRoots）' }
  }

  const inAllowed = allowedRoots.some((root) => {
    const normalizedRoot = normalize(resolve(root))
    const rel = relative(normalizedRoot, resolved)
    // rel 不能以 .. 开头（穿越），且不能是绝对路径（跨驱动器）
    return !rel.startsWith('..') && !isAbsolute(rel)
  })

  if (!inAllowed) {
    return { valid: false, resolved, error: `路径不在允许范围内: ${resolved}` }
  }

  // 4. 如果文件/目录已存在，通过 realpath 检测符号链接逃逸
  try {
    const real = realpathSync(resolved)
    const realInAllowed = allowedRoots.some((root) => {
      const normalizedRoot = normalize(resolve(root))
      const rel = relative(normalizedRoot, real)
      return !rel.startsWith('..') && !isAbsolute(rel)
    })
    if (!realInAllowed) {
      return { valid: false, resolved: real, error: `符号链接指向允许范围之外: ${real}` }
    }
    return { valid: true, resolved: real }
  } catch {
    // 文件不存在 — 向上找最近存在的祖先目录，解析其真实路径
    let ancestor = resolved
    while (ancestor !== dirname(ancestor)) {
      ancestor = dirname(ancestor)
      if (existsSync(ancestor)) {
        const realAncestor = realpathSync(ancestor)
        const ancestorInAllowed = allowedRoots.some((root) => {
          const normalizedRoot = normalize(resolve(root))
          const rel = relative(normalizedRoot, realAncestor)
          return !rel.startsWith('..') && !isAbsolute(rel)
        })
        if (!ancestorInAllowed) {
          return { valid: false, resolved, error: `父目录符号链接指向允许范围之外: ${realAncestor}` }
        }
        return { valid: true, resolved }
      }
    }
    return { valid: false, resolved, error: '无法验证路径: 找不到存在的祖先目录' }
  }
}

/**
 * 从 config 加载 allowedRoots，MVP 默认允许访问 ~/Desktop, ~/Documents, ~/Downloads 和数据目录
 */
export function getDefaultAllowedRoots(): string[] {
  const home = homedir()
  const roots = [
    resolve(home, 'Desktop'),
    resolve(home, 'Documents'),
    resolve(home, 'Downloads'),
  ]

  // 数据目录：优先从环境变量获取（子进程由 skill-manager 注入 DATA_DIR）
  if (process.env.DATA_DIR) {
    roots.push(resolve(process.env.DATA_DIR))
  } else {
    try {
      const { getDataDir } = require('../../../paths')
      roots.push(resolve(getDataDir()))
    } catch {
      // fallback: 脚本独立运行时无法 import paths.ts
      const fallback = resolve(process.cwd(), 'data')
      if (existsSync(fallback)) roots.push(resolve(fallback))
    }
  }

  // 运行时追加的额外允许目录（拖入文件等场景，由 skill-manager 注入）
  if (process.env.ADDITIONAL_ALLOWED_ROOTS) {
    for (const r of process.env.ADDITIONAL_ALLOWED_ROOTS.split(delimiter)) {
      if (r) roots.push(resolve(r))
    }
  }

  return roots
}
